"""
v3 策略参数校准（backtesting.py optimize + IS/OOS 自动划分 + 达标自动启用）——仅真实数据

流程（IS/OOS 按回测范围自动划分，IS 70% / OOS 30%）：
  1) 真实数据：编目优先 → 不足自动拉取 OKX（>300根自动翻页）；没有合成数据
  2) 基线：v3 默认参数 vs 买入持有
  3) IS 3折稳健寻优（每折净收益取中位数，≥2折有效才参选；单段明星组合=过拟合高发）
     → 冠军回完整 IS 确认 ≥8 笔 → OOS 验证（只碰一次，保持样本外纯度）
  4) OOS 诊断：全部组合 OOS 收益分布 + 零成本对照（区分"无毛优势 / 费用吃掉 / 寻优欠佳"）
  5) 守门启用：OOS 收益>0 且 交易数≥5 且 不差于默认参数 OOS
     → 写入 configs/params_live.json，此后回测自动采用最新参数
  6) 报告落盘 reports/backtesting/optimize_report.json

用法：
  python backtests/optimize_strategy.py --bars 3000
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pandas as pd
from loguru import logger

from backtests.run_backtest import _load_cfg, load_real_or_exit
from eth_hft.strategy.micro_scalper_bs import RegimeAdaptiveBS, FlowRegimeAdaptiveBS, set_flow_source

STRATEGY_CLS = RegimeAdaptiveBS  # --flow 时替换为流量闸门版（模块级，optimize 线程池可见）

PARAMS_FILE = Path("configs/params_live.json")


# --------------------------------------------------------------------------- #
# 数据（仅真实）
# --------------------------------------------------------------------------- #
# --------------------------------------------------------------------------- #
# 回测辅助
# --------------------------------------------------------------------------- #
def make_bt(data: pd.DataFrame, cash: float, commission: float, margin: float):
    import backtesting

    return backtesting.lib.FractionalBacktest(
        data, STRATEGY_CLS,
        fractional_unit=1 / 1e8, cash=cash, commission=commission, margin=margin,
        exclusive_orders=True, finalize_trades=True,
    )


V3_COMMON = dict(use_cost_gate=True, min_edge_bps=1.5, commission_bps=3.0,
                 spread_bps=0.8, slippage_bps=0.6, buffer_bps=1.0)


def run_v3(data: pd.DataFrame, cash=50.0, commission=0.0003, margin=0.01, **params):
    kwargs = dict(V3_COMMON)
    kwargs.update(params)
    return make_bt(data, cash, commission, margin).run(**kwargs)


def run_buy_hold(data: pd.DataFrame, cash: float = 50.0) -> dict:
    ret = float(data["Close"].iloc[-1] / data["Close"].iloc[0] - 1.0) * 100
    return {"trades": 1, "win_rate_pct": None, "return_pct": round(ret, 4),
            "fees": None, "profit_factor": None, "sharpe": None, "sqn": None,
            "max_dd_pct": None, "exposure_pct": 100.0}


def snapshot(stats) -> dict:
    def g(k):
        v = stats.get(k)
        try:
            f = float(v)
            return None if f != f else round(f, 4)
        except Exception:
            return None
    return {
        "trades": int(stats["# Trades"]),
        "win_rate_pct": g("Win Rate [%]"),
        "return_pct": g("Return [%]"),
        "fees": g("Commissions [$]"),
        "profit_factor": g("Profit Factor"),
        "sharpe": g("Sharpe Ratio"),
        "sqn": g("SQN"),
        "max_dd_pct": g("Max. Drawdown [%]"),
        "exposure_pct": g("Exposure Time [%]"),
    }


# 稀疏化网格：vr_lo/vr_hi（状态门宽窄）与 z_in（偏离强度）是"交易频率"的直接旋钮。
# 2026-09 实证（2万根）：1m 双向换手在成本结构下毛优势≈0、费用吃掉全部——必须让
# 寻优能选出"少而精"的参数（更极端的 VR 门/更高的 z 阈 → 更低换手）
GRID = dict(
    fast=[15], slow=[60], stop_atr=[2.5], trail_atr=[1.5],
    cooldown_bars=[30], z_in=[2.0], mr_stop_atr=[2.5],
    vr_lo=[0.7, 0.9], vr_hi=[1.1, 1.4],
    # 持仓周期（bar）：1m 下 15/45 ≈ 15/45 分钟——太短费用占比高、太长敞口反转风险，平衡点寻优
    max_hold_bars=[15, 45],
    # ===== 每笔经济学（2万根实证：毛优势+1.36% 被 9.45U 费用吞没 → 必须"少而厚"）=====
    capture_mult=[1.0, 2.0, 3.0],   # 入场门槛：预期捕捉 ≥ N×往返成本(8.4bps) → 8/17/25bps
    flow_gate=[0.0],                # 流量闸门（默认不启用；--flow 时被 [0,1,1.5] 覆盖）
    mr_sl_mult=[0.8, 1.3],          # MR 风险腿：0.8×dev（R:R>1）vs 1.3×dev（旧行为）
    mr_tp_mult=[1.0, 1.5],          # MR 目标腿：吃回归过头 1.5×dev
    atr_floor_bps=[1.0, 6.0],       # momo 环境闸门：ATR<6bps 的时段禁止追趋势
    # 单边模式：2026-09 两万根 OOS 方向归因——多头腿两套参数均正(+2.65U/56.5%)，
    # 空头腿均负(-2.34U/46.8%) → 让 OOS 验证裁决是否砍掉空头
    side_mode=["both", "long"],
)
GRID_KEEP = ("fast", "slow", "stop_atr", "trail_atr", "cooldown_bars", "z_in",
             "mr_stop_atr", "vr_lo", "vr_hi", "max_hold_bars",
             "capture_mult", "mr_sl_mult", "mr_tp_mult", "atr_floor_bps", "side_mode", "flow_gate")
INVALID = -9e9  # 淘汰哨兵分


def fold_score(stats: pd.Series) -> float:
    """折内得分：交易数 <3 直接淘汰（折长仅为 IS/3，门槛相应放宽），否则取净收益 Return[%]。
    不用 SQN：其 √N 项奖励高频换手，在"高频无毛优势"下恰是病根；目标直接对准净盈利。"""
    try:
        if int(stats.get("# Trades", 0)) < 3:
            return INVALID
    except Exception:
        return INVALID
    try:
        f = float(stats.get("Return [%]"))
        return f if f == f else INVALID
    except Exception:
        return INVALID


def oos_objective(stats: pd.Series) -> float:
    """OOS 诊断目标：Return[%]（仅生成诊断热图，回答'数据不足还是无优势'，不参与参数选择）"""
    try:
        f = float(stats.get("Return [%]"))
        return f if f == f else -1e9
    except Exception:
        return -1e9


def robust_select(fold_scores: list[pd.Series], min_valid_folds: int = 2) -> pd.Series:
    """多折稳健择优：≥min_valid_folds 折有效（非淘汰哨兵/NaN）才参选，
    得分 = 有效折得分的中位数。

    单段 argmax(SQN) 的"明星组合"往往靠一段行情的运气，多折中位数强制
    参数在多段时间都过得去，显著降低过拟合冠军概率。
    """
    table = pd.concat(fold_scores, axis=1)
    valid = table > INVALID + 1
    med = table.where(valid).median(axis=1)  # 中位数只统计有效折
    med[valid.sum(axis=1) < min_valid_folds] = np.nan  # 有效折不足 → 不参选
    med.name = "score"
    return med


def dim_breakdown(heatmap: pd.Series) -> dict:
    """热图按每个参数维度分组：均值与正占比 → 直接看到正收益组合集中在哪组参数。"""
    out = {}
    for name in heatmap.index.names:
        g = heatmap.groupby(level=name)
        d = {}
        for k, v in g:
            m = float(v.mean())
            d[str(k)] = {"mean": None if m != m else round(m, 3),
                         "pos_pct": round(float((v > 0).mean() * 100), 1)}
        out[name] = d
    return out


def direction_split(trades_df: pd.DataFrame) -> dict:
    """OOS 方向归因：多头/空头的笔数与毛利（PnL+手续费）。回答"+毛优势是哪边贡献的"。"""
    if trades_df is None or len(trades_df) == 0:
        return {}
    out = {}
    for side, mask in (("long", trades_df["Size"] > 0), ("short", trades_df["Size"] < 0)):
        t = trades_df[mask]
        gross = float((t["PnL"] + t["Commission"]).sum()) if len(t) else 0.0
        wins = int((t["PnL"] > 0).sum()) if len(t) else 0
        out[side] = {"trades": int(len(t)), "gross_usdt": round(gross, 4),
                     "win_rate": round(wins / len(t) * 100, 1) if len(t) else None}
    return out


def params_from_key(key, names) -> dict:
    INT_KEYS = ("fast", "slow", "cooldown_bars", "max_hold_bars")

    return {n: (int(v) if n in INT_KEYS else (v if isinstance(v, str) else float(v)))
            for n, v in zip(names, key) if n in GRID_KEEP}


# --------------------------------------------------------------------------- #
# 主流程
# --------------------------------------------------------------------------- #
def main(bars: int = 3000, catalog_path: str | None = None, tf: str = "1m", use_flow: bool = False):
    cfg = _load_cfg()
    catalog_path = catalog_path or cfg.get("data_root", "data/catalog")
    equity = float(cfg.get("account", {}).get("equity_usdt", 50.0))
    risk_usdt = float(cfg.get("position", {}).get("risk_budget_usdt", 0.2))
    max_lev = int(cfg.get("position", {}).get("max_leverage", 100))
    commission = 0.0003
    margin = 1.0 / max(1, max_lev)

    def vr_state_dist(df: pd.DataFrame) -> dict:
        """与策略完全同款的滚动 VR 状态分布（解释'为什么不交易'）"""
        c = df["Close"]
        r1 = c.diff()
        rk = c.diff(30)
        vr = (rk.rolling(240).var() / (30 * r1.rolling(240).var())).replace([np.inf, -np.inf], np.nan).dropna()
        if vr.empty:
            return {}
        return {
            "vr_p10": round(float(vr.quantile(0.1)), 3), "vr_p50": round(float(vr.quantile(0.5)), 3),
            "vr_p90": round(float(vr.quantile(0.9)), 3),
            "pct_trend(VR>1.1)": round(float((vr >= 1.1).mean() * 100), 1),
            "pct_mr(VR<0.9)": round(float((vr <= 0.9).mean() * 100), 1),
            "pct_chop(不交易)": round(float(((vr > 0.9) & (vr < 1.1)).mean() * 100), 1),
        }

    data = load_real_or_exit(bars, catalog_path, tf)
    logger.info(f"真实数据 {len(data)} 根（周期 {tf}）：{data.index.min()} -> {data.index.max()}")

    global STRATEGY_CLS
    if use_flow:
        from eth_hft.data.flow import load_or_fetch_flow
        flow_df = load_or_fetch_flow(data.index)
        set_flow_source(flow_df)
        STRATEGY_CLS = FlowRegimeAdaptiveBS  # 模块级类：optimize 池可 pickle
        cov = float(flow_df["coverage_pct"].iloc[0]) if "coverage_pct" in flow_df else -1.0
        GRID["flow_gate"] = [0.0, 1.0, 1.5]  # 闸门三档入寻优（0=对照）
        logger.info(f"流量闸门启用: taker覆盖 {cov}%，网格 {GRID['flow_gate']}")
    else:
        set_flow_source(None)
        STRATEGY_CLS = RegimeAdaptiveBS

    # ---- IS/OOS 自动划分（由回测范围决定，70/30）----
    split = int(len(data) * 0.7)
    is_df, oos_df = data.iloc[:split], data.iloc[split:]
    logger.info(f"IS/OOS 自动划分：IS {len(is_df)} 根（寻优） | OOS {len(oos_df)} 根（验证）")
    state_dist = {"IS": vr_state_dist(is_df), "OOS": vr_state_dist(oos_df)}
    logger.info(f"行情状态分布: {state_dist}")

    # ---- 基线 ----
    base = {}
    s_def = run_v3(data, equity, commission, margin, risk_usdt=risk_usdt)
    base["v3_状态自适应(默认参数)"] = snapshot(s_def)
    base["买入持有(基准)"] = run_buy_hold(data, equity)
    for k, v in base.items():
        logger.info(f"基线 {k}: {v}")

    # ---- IS 多折稳健寻优（3 折中位数 SQN，防单段过拟合冠军）----
    n_folds = 3
    bounds = [round(len(is_df) * i / n_folds) for i in range(n_folds + 1)]
    folds = [is_df.iloc[bounds[i]:bounds[i + 1]] for i in range(n_folds)]
    import itertools
    n_combos = len(list(itertools.product(*GRID.values())))
    logger.info(f"IS {len(is_df)} 根 → {n_folds} 折（每折 ~{len(folds[0])} 根）稳健寻优 {n_combos} 组合")
    fold_scores: list[pd.Series] = []
    for k, f_df in enumerate(folds):
        bt_f = make_bt(f_df, equity, commission, margin)
        _, hm = bt_f.optimize(
            **GRID, risk_usdt=[risk_usdt], **V3_COMMON,
            maximize=fold_score,
            constraint=lambda p: p.fast < p.slow,
            return_heatmap=True,
        )
        fold_scores.append(hm)
        logger.info(f"  折{k + 1}: 有效组合 {int((hm > INVALID + 1).sum())}/{len(hm)}")
    robust_table = robust_select(fold_scores, min_valid_folds=2)

    opt_params, stats_is = {}, None
    top10 = pd.DataFrame()
    if robust_table.notna().any():
        # 依稳健分降序取前5，回到完整 IS 确认交易数 ≥8（仅 IS 内信息，不碰 OOS）
        cand = robust_table.dropna().sort_values(ascending=False)
        names = list(robust_table.index.names)
        for key in list(cand.index[:5]):
            params = params_from_key(key, names)
            st_full = run_v3(is_df, equity, commission, margin, risk_usdt=risk_usdt, **params)
            if int(st_full["# Trades"]) >= 8:
                opt_params, stats_is = params, st_full
                logger.info(f"IS 稳健冠军: {opt_params} | 稳健分(折间中位数净收益%)={cand.iloc[0]:.2f}")
                logger.info(f"IS 冠军统计: {snapshot(st_full)}")
                break
        t = robust_table.dropna().sort_values(ascending=False).head(10)
        top10 = pd.DataFrame({"params": [str(dict(zip(names, key))) for key in t.index],
                              "score_median": t.values})
        if opt_params == {}:
            logger.warning("稳健前5名在完整 IS 上均未达 8 笔，视为样本不足")
    else:
        logger.warning("IS 样本过少：无组合通过多折稳健门槛（每折≥3笔且≥2折有效），跳过寻优，仅评估默认参数")
    if stats_is is None:
        stats_is = s_def  # 兜底展示：默认参数全样本统计

    # ---- OOS 验证（默认参数 vs IS稳健冠军，冠军只碰一次 OOS）----
    oos = {}
    s_oos_def = run_v3(oos_df, equity, commission, margin, risk_usdt=risk_usdt)
    oos["v3_状态自适应(默认参数)"] = snapshot(s_oos_def)
    oos["买入持有(基准)"] = run_buy_hold(oos_df, equity)
    # 零成本对照：手续费/滑点全免、关闭成本门槛 → 回答"亏损=费用还是信号"
    # 毛收益≈0 ⇒ 信号无毛优势（换信号/换周期）；毛收益明显>0 ⇒ 优势被成本吃掉（降换手）
    s_gross = run_v3(oos_df, equity, commission=0.0, margin=margin,
                     risk_usdt=risk_usdt, use_cost_gate=False)
    oos["v3_零成本对照(默认参数)"] = snapshot(s_gross)
    logger.info(f"OOS 零成本对照(默认参数): {oos['v3_零成本对照(默认参数)']}")
    s_oos_best = run_v3(oos_df, equity, commission, margin, risk_usdt=risk_usdt, **opt_params)
    oos["v3_状态自适应(IS稳健冠军)"] = snapshot(s_oos_best) if opt_params else oos["v3_状态自适应(默认参数)"]
    for k, v in oos.items():
        logger.info(f"OOS {k}: {v}")

    # ---- 方向归因：+毛优势是多头还是空头贡献的（决定是否改单边）----
    oos_direction = {"默认参数": direction_split(s_oos_def["_trades"])}
    if opt_params:
        oos_direction["IS冠军"] = direction_split(s_oos_best["_trades"])
    logger.info(f"OOS 方向归因: {oos_direction}")

    # ---- 冠军每笔经济学 + maker 执行情景 ----
    # taker(0.03%/边) 下净亏但毛利为正时，唯一剩余杠杆=挂单成交(maker 0.02%/边，省点差滑点)。
    # 回测无法模拟排队成交（maker 假设偏乐观），结论仅供模拟盘验证参考。
    champion_econ, maker_scenarios = {}, {}
    if opt_params:
        try:
            d_champ = oos_direction.get("IS冠军") or {}
            gross_u = sum((d_champ.get(s, {}) or {}).get("gross_usdt", 0) or 0 for s in ("long", "short"))
            fees_u = float(s_oos_best.get("Commissions [$]", 0) or 0)  # 原始 stats 键（非 snapshot）
            n_t = int(s_oos_best["# Trades"])
            champion_econ = {
                "trades": n_t,
                "gross_usdt": round(gross_u, 4), "fees_usdt": round(fees_u, 4),
                "net_usdt": round(gross_u - fees_u, 4),
                "cost_to_gross_ratio": round(fees_u / gross_u, 2) if gross_u > 0 else None,
                "note": "净利=毛利-费用；cost_to_gross_ratio>1 即费用吞没毛优势",
            }
            logger.info(f"冠军每笔经济学: {champion_econ}")
        except Exception as e:
            logger.warning(f"冠军每笔经济学计算失败（不影响主流程）: {e}")
        for tag, comm, extra in (("maker费率_同参数", 0.0002, {}),
                                 ("maker费率_capture3(最厚偏离)", 0.0002, {"capture_mult": 3.0})):
            try:
                st_m = run_v3(oos_df, equity, comm, margin, risk_usdt=risk_usdt, **{**opt_params, **extra})
                maker_scenarios[tag] = snapshot(st_m)
                logger.info(f"OOS maker情景 {tag}: {maker_scenarios[tag]}")
            except Exception as e:
                logger.warning(f"maker情景 {tag} 失败: {e}")

    # ---- OOS 诊断：全部组合的 OOS 收益分布（区分"参数没选好"vs"该时段无优势"）----
    oos_diag = {}
    try:
        bt_oos = make_bt(oos_df, equity, commission, margin)
        _, hm_oos = bt_oos.optimize(
            **GRID, risk_usdt=[risk_usdt], **V3_COMMON,
            maximize=oos_objective,
            constraint=lambda p: p.fast < p.slow,
            return_heatmap=True,
        )
        def _r(x):  # NaN -> None（合法 JSON）
            f = float(x)
            return None if f != f else round(f, 3)
        oos_diag = {
            "total_combos": int(len(hm_oos)),
            "positive_combos": int((hm_oos > 0).sum()),
            "by_param": dim_breakdown(hm_oos),
            "return_p10": _r(hm_oos.quantile(0.1)),
            "return_p50": _r(hm_oos.quantile(0.5)),
            "return_p90": _r(hm_oos.quantile(0.9)),
            "note": "诊断字段：全部参数组合在 OOS 的收益分布，不参与启用判定",
        }
        logger.info(f"OOS 诊断: {oos_diag['positive_combos']}/{oos_diag['total_combos']} 组合收益>0 "
                    f"| p10/p50/p90 = {oos_diag['return_p10']}/{oos_diag['return_p50']}/{oos_diag['return_p90']}%")
    except Exception as e:
        logger.warning(f"OOS 诊断失败（不影响主流程）: {e}")

    # ---- 守门自动启用（参数调优后自动采用最新参数）----
    oos_best = oos["v3_状态自适应(IS稳健冠军)"]
    oos_def = oos["v3_状态自适应(默认参数)"]
    adopted, reason = False, ""
    if not opt_params:
        reason = "未启用：IS 样本不足无法寻优（先补齐真实数据，建议 --bars 5000 以上）"
    else:
        ok_ret = (oos_best["return_pct"] or -1e9) > 0
        ok_n = oos_best["trades"] >= 5
        ok_vs_def = (oos_best["return_pct"] or -1e9) >= (oos_def["return_pct"] or -1e9)
        if ok_ret and ok_n and ok_vs_def:
            payload = {
                "params": opt_params,
                "timeframe": tf,
                "updated_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M"),
                "data_range": f"{data.index.min()} -> {data.index.max()}",
                "bars": len(data),
                "oos_return_pct": oos_best["return_pct"],
                "oos_trades": oos_best["trades"],
                "is_oos_split": f"{split}/{len(data) - split}",
                "note": "由 optimize_strategy.py 自动写入：OOS 验证达标后启用；回测自动加载",
            }
            PARAMS_FILE.parent.mkdir(parents=True, exist_ok=True)
            PARAMS_FILE.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            adopted, reason = True, "OOS 达标（收益>0、交易≥5、不差于默认参数）→ 已写入 configs/params_live.json"
        elif not ok_ret:
            pos = oos_diag.get("positive_combos")
            gross = (oos.get("v3_零成本对照(默认参数)") or {}).get("return_pct") or 0.0
            if gross > 0:
                reason = (f"未启用：OOS 净收益 ≤ 0，但零成本对照毛收益 +{gross}% —— 有毛优势但被交易成本吃掉"
                          "（换手过高）；本次已启用稀疏化网格（VR阈值/z_in 参与寻优），建议补更多数据后重跑")
            elif pos:
                reason = (f"未启用：IS 稳健冠军 OOS 收益 ≤ 0（OOS 上 {pos} 个组合为正：优势区域存在但该参数"
                          "未捕捉到）；保守起见沿用原参数")
            else:
                reason = ("未启用：OOS 收益 ≤ 0，且全部参数组合与零成本对照均为负 → 信号在该时段无毛优势"
                          "（非寻优/费用问题）；1m 双向高频在此成本结构下难以盈利，建议转向 5m/15m 更大周期"
                          "或更稀疏的事件型入场，并持续补数据观察")
        elif not ok_n:
            reason = f"未启用：OOS 交易数 {oos_best['trades']} < 5（样本太少不可信）"
        else:
            reason = "未启用：IS 最优参数在 OOS 不如默认参数（可能过拟合，沿用原参数）"
    logger.info(f"参数启用判定: {'✅ 已自动启用' if adopted else '⚠️ 保留原参数'} — {reason}")

    # ---- 全样本最优参数交互报告 ----
    report_dir = Path("reports/backtesting")
    report_dir.mkdir(parents=True, exist_ok=True)
    html_path = report_dir / "optimize_v3_best_full.html"
    try:
        bt_plot = make_bt(data, equity, commission, margin)
        bt_plot.run(risk_usdt=risk_usdt, **V3_COMMON, **opt_params)
        bt_plot.plot(filename=str(html_path), open_browser=False)
        logger.info(f"最优参数全样本交互报告 -> {html_path}")
    except Exception as e:
        logger.warning(f"HTML 报告失败: {e}")

    out = {
        "data_source": f"OKX 真实K线 {len(data)} 根（编目 {catalog_path}，周期 {tf}）",
        "timeframe": tf,
        "flow_enabled": bool(use_flow),
        "bars": len(data),
        "data_range": f"{data.index.min()} -> {data.index.max()}",
        "commission_per_side": commission,
        "is_oos_split": f"自动 70/30: {split}/{len(data) - split}",
        "baselines_full": base,
        "is_best_params": opt_params,
        "is_stats": snapshot(stats_is),
        "is_top10": json.loads(top10.to_json(orient="records", force_ascii=False)) if not top10.empty else [],
        "is_by_param": (lambda: dim_breakdown(robust_table) if robust_table is not None and robust_table.notna().any() else {})(),
        "selection_method": "IS 3折中位数净收益%（每折≥3笔、≥2折有效参选、冠军回完整IS确认≥8笔；网格含每笔经济学capture_mult/MR盈亏比/持仓周期）",
        "oos": oos,
        "oos_diagnostics": oos_diag,
        "oos_direction": oos_direction,
        "champion_economics": champion_econ,
        "maker_scenarios": maker_scenarios,
        "adopted": adopted,
        "adopt_reason": reason,
        "state_distribution": state_dist,
        "params_file": str(PARAMS_FILE),
        "note": "全部基于真实行情数据（OKX 1m）；IS/OOS 按回测范围自动 7:3 划分；达标参数自动启用",
    }
    (report_dir / "optimize_report.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    logger.info(f"校准报告 -> {report_dir / 'optimize_report.json'}")
    return out


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="v3 策略 IS/OOS 校准（仅真实数据，自动划分/自动启用）")
    parser.add_argument("--bars", type=int, default=5000, help="回测范围（IS/OOS 自动 7:3 划分；建议 5000~20000）")
    parser.add_argument("--tf", type=str, default="1m", choices=["1m", "3m", "5m", "15m"],
                        help="K线周期：由真实1m聚合（bars=目标周期根数）")
    parser.add_argument("--flow", action="store_true",
                        help="启用 Rubik 主动买卖比流量闸门（先跑 scripts/24_fetch_flow.py）")
    parser.add_argument("--catalog", type=str, default=None, help="编目路径覆盖")
    args = parser.parse_args()
    main(bars=args.bars, catalog_path=args.catalog, tf=args.tf, use_flow=args.flow)
