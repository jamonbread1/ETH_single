"""
专业回测：backtesting.py 内核（kernc/backtesting.py，GitHub 13k+ stars）

2026-09 重构：弃用项目内 Nautilus 撮合链路（旧版 bug 见 git history），回测内核更换为
backtesting.py FractionalBacktest：
- 事件驱动逐 bar 撮合，市价单次根开盘价成交（无未来函数）
- SL/TP 括弧单 bar 内自动触发（比按收盘判定更真实）
- 佣金/杠杆/净持仓（exclusive_orders ≙ NETTING）内建支持
- 一键输出交互式 HTML 报告（K线+交易标记+权益曲线，plotly）

用法：
  python backtests/run_backtest.py --bars 300 --run-id selective_micro --strategy v1
数据链：DataCatalog 优先（离线可复现）→ 不足时 OKX REST 自动翻页拉取（>300 根分页）
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import pandas as pd
from loguru import logger

from eth_hft.data.catalog import DataCatalog
from eth_hft.data.okx_rest import fetch_candles
from eth_hft.strategy.micro_scalper_bs import FactorAlphaBS, RegimeAdaptiveBS, TrendAdaptiveBS, set_flow_source

ENGINE_NAME = "backtesting.py"


# --------------------------------------------------------------------------- #
# 配置 SSOT（configs/system.yaml）
# --------------------------------------------------------------------------- #
def _load_cfg() -> dict:
    try:
        from eth_hft.config.loader import load_system_config

        return load_system_config() or {}
    except Exception as e:
        logger.warning(f"system.yaml 读取失败，用默认值: {e}")
        return {}


V3_PARAM_KEYS = (
    "fast", "slow", "trend_len", "atr_len", "deadzone_atr", "stop_atr", "trail_atr", "tp_atr",
    "z_len", "z_in", "mr_stop_atr", "vr_len", "vr_k", "vr_hi", "vr_lo",
    "cooldown_bars", "atr_floor_bps", "score_thr",  # score_thr 供 v4 因子Alpha使用
    "max_hold_bars",  # 持仓周期上限（时间止损）
    "capture_mult", "mr_sl_mult", "mr_tp_mult",  # 每笔经济学 + MR 盈亏比
    "side_mode",  # 单边模式 both/long/short（OOS方向归因驱动）
    "flow_gate",  # 流量闸门 |taker_z|（Rubik主动买卖比，--flow 时启用）
)
PARAMS_FILE = Path("configs/params_live.json")


def _load_live_params(tf: str = "1m") -> tuple[dict, str]:
    """读取自动校准启用的参数（optimize_strategy.py 达标后写入）。返回 (params, 来源描述)。

    只加载匹配周期的参数：15m 校准出的窗口/阈值语义与 1m 完全不同，
    跨周期套用=参数污染（2026-09 审查修复；旧文件无 timeframe 字段按 1m 处理）。"""
    if PARAMS_FILE.exists():
        try:
            d = json.loads(PARAMS_FILE.read_text(encoding="utf-8"))
            p_tf = str(d.get("timeframe", "1m"))
            if p_tf != tf:
                logger.warning(f"params_live.json 为 {p_tf} 周期校准参数，当前回测周期 {tf} 不符——忽略，用默认参数")
                return {}, f"class defaults（忽略 {p_tf} 周期校准参数）"
            params = {k: v for k, v in (d.get("params") or {}).items() if k in V3_PARAM_KEYS}
            if params:
                src = f"calibrated {d.get('updated_at', '')} (OOS {d.get('oos_return_pct', '?')}%)"
                return params, src
        except Exception as e:
            logger.warning(f"params_live.json 读取失败，用默认参数: {e}")
    return {}, "class defaults"


# --------------------------------------------------------------------------- #
# 数据准备：catalog 优先（可复现），不足时 OKX 拉取（自动翻页）
# --------------------------------------------------------------------------- #
def fetch_bars_df(limit: int) -> pd.DataFrame:
    """拉取 OKX 1m K线（fetch_candles 内部支持 >300 根自动翻页）"""
    df = fetch_candles("ETH-USDT-SWAP", "1m", limit)
    return df.sort_values("ts").reset_index(drop=True)


def _catalog_bars(catalog_path: str) -> pd.DataFrame | None:
    try:
        cat = DataCatalog(catalog_path)
        if not cat.list_bars():
            return None
        df = cat.read_bars_pandas()
        if df is not None and not df.empty and len(df) >= 10:
            return df.sort_values("ts").reset_index(drop=True)
    except Exception as e:
        logger.warning(f"catalog 读取跳过: {e}")
    return None


def prepare_data(bars_limit: int, catalog_path: str) -> pd.DataFrame:
    df = _catalog_bars(catalog_path)
    if df is None or len(df) < bars_limit:
        have = len(df) if df is not None else 0
        logger.info(f"catalog 未命中或不足 {have}/{bars_limit}，尝试拉取 OKX {bars_limit} 根 1m")
        try:
            fetch_df = fetch_bars_df(bars_limit)
        except Exception as e:
            logger.warning(f"OKX 拉取失败（离线？）: {e}")
            if df is None:
                raise
            logger.warning(f"离线回退：使用 catalog 现有 {len(df)} 根（少于请求的 {bars_limit} 根）")
        else:
            df = fetch_df
            try:
                cat = DataCatalog(catalog_path)
                if not cat.list_bars():
                    cat.write_bars(df)
                    logger.info(f"已落盘 catalog {len(df)} bars（可复现）")
            except Exception as e:
                logger.warning(f"catalog 写入跳过: {e}")
    else:
        logger.info(f"命中 catalog {len(df)} bars（可复现，不拉取）")

    # 截取最近 bars_limit 根
    if len(df) > bars_limit:
        df = df.iloc[-bars_limit:].reset_index(drop=True)

    # → backtesting.py 格式：Open/High/Low/Close/Volume + DatetimeIndex（UTC naive）
    out = df.copy()
    ts = pd.to_datetime(out["ts"], utc=True)
    out.index = pd.DatetimeIndex(ts.dt.tz_convert("UTC").dt.tz_localize(None))
    rename = {}
    for c in ("open", "high", "low", "close", "volume", "vol"):
        if c in out.columns:
            rename[c] = c.capitalize() if c != "vol" else "Volume"
    out = out.rename(columns=rename)
    if "Volume" not in out.columns:
        out["Volume"] = 1.0  # 无量时占位（策略不依赖 Volume）
    out = out[["Open", "High", "Low", "Close", "Volume"]].astype(float)
    out = out.dropna().sort_index()
    out = out[~out.index.duplicated(keep="last")]
    logger.info(f"回测数据就绪 {len(out)} bars，{out.index.min()} -> {out.index.max()}")
    return out


TF_MINUTES = {"1m": 1, "3m": 3, "5m": 5, "15m": 15}


def resample_bars(df: pd.DataFrame, tf: str) -> pd.DataFrame:
    """1m 真实K线 → 高周期 OHLCV（label/closed=left；不完整末根丢弃）。
    仅聚合，不引入任何非真实数据。"""
    minutes = TF_MINUTES[tf]
    if minutes == 1:
        return df
    agg = {"Open": "first", "High": "max", "Low": "min", "Close": "last", "Volume": "sum"}
    out = df.resample(f"{minutes}min", label="left", closed="left").agg(agg)
    return out.dropna(subset=["Close"])


def load_real_or_exit(bars: int, catalog_path: str, tf: str = "1m") -> pd.DataFrame:
    """真实数据加载（共用）：编目优先 → 不足自动拉取 OKX；没有足够真实数据就退出。

    bars 为目标周期 tf 的根数（内部按 bars×ratio 换算 1m 需求，重采样后 tail(bars)）"""
    ratio = TF_MINUTES.get(tf)
    if ratio is None:
        raise SystemExit(f"不支持周期 {tf!r}（可选 1m/3m/5m/15m）")
    need_1m = int(bars) * ratio
    df = _catalog_bars(catalog_path)
    have = 0 if df is None else len(df)
    fetched = False
    if df is None or have < need_1m:
        logger.info(f"编目 {have}/{bars} 根不足，自动拉取 OKX 真实K线...")
        try:
            df = fetch_bars_df(need_1m)
            fetched = True
            logger.info(f"已拉取 {len(df)} 根真实K线（未落盘，回测用）")
        except Exception as e:
            logger.error(f"OKX 拉取失败：{e}")
            logger.error(
                f"真实数据不足且无法联网拉取。解决：\n"
                f"  1) python scripts/10_fetch_candles.py --bars {need_1m} --fill\n"
                f"  2) 国内网络加代理：--proxy http://127.0.0.1:7890 或 export OKX_PROXY=..."
            )
            raise SystemExit(1)
    # 审查修复：刚拉取过的数据直接格式化，不得再进 prepare_data（会二次触发 OKX 拉取）
    out = _bs_format(df) if fetched else prepare_data(need_1m, catalog_path)
    if out is None or len(out) < min(need_1m, 400):
        raise SystemExit(f"真实1m数据不足（{0 if out is None else len(out)}/{need_1m}），"
                         f"请先补齐：python scripts/10_fetch_candles.py --bars {need_1m} --fill")
    data = resample_bars(out, tf).tail(int(bars))
    if len(data) < min(int(bars), 300):
        raise SystemExit(f"重采样 {tf} 后不足（{len(data)}/{bars}），请补齐更多真实 1m 数据")
    return data


def _bs_format(df: pd.DataFrame) -> pd.DataFrame:
    """OKX DataFrame → backtesting.py OHLCV 格式"""
    out = df.copy()
    ts = pd.to_datetime(out["ts"], utc=True)
    out.index = pd.DatetimeIndex(ts.dt.tz_convert("UTC").dt.tz_localize(None))
    rename = {}
    for c in ("open", "high", "low", "close", "volume", "vol"):
        if c in out.columns:
            rename[c] = "Volume" if c == "vol" else c.capitalize()
    out = out.rename(columns=rename)
    if "Volume" not in out.columns:
        out["Volume"] = 1.0
    return out[["Open", "High", "Low", "Close", "Volume"]].astype(float).dropna().sort_index()


# --------------------------------------------------------------------------- #
# 回测主流程
# --------------------------------------------------------------------------- #
def run_backtest(
    bars_limit: int = 300,
    run_id: str | None = None,
    strategy_flag: str = "v3",
    commission: float | None = None,
    catalog_path: str | None = None,
    tf: str = "1m",
    use_flow: bool = False,
) -> dict:
    import backtesting

    cfg = _load_cfg()
    catalog_path = catalog_path or cfg.get("data_root", "data/catalog")
    equity_usdt = float(cfg.get("account", {}).get("equity_usdt", 50.0))
    pos_cfg = cfg.get("position", {})
    risk_usdt = float(pos_cfg.get("risk_budget_usdt", 0.20))
    max_leverage = int(pos_cfg.get("max_leverage", 100))
    cost_cfg = cfg.get("cost", {})
    min_edge_bps = float(cost_cfg.get("min_edge_bps", 1.5))
    spread_bps = float(cost_cfg.get("spread_bps", 0.8))
    slip_bps = float(cost_cfg.get("slippage_maker_bps", 0.6))
    buffer_bps = float(cost_cfg.get("safety_buffer_bps", 1.0))
    fee_cfg = cfg.get("fees", {})
    maker_fee = float(fee_cfg.get("maker", 0.0002))

    # 佣金：策略为 PostOnly-maker 风格，默认按 maker 单边；可用 --commission 保守覆盖
    per_side_commission = commission if commission is not None else maker_fee

    if run_id is None:
        run_id = f"bs_{strategy_flag}_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}"

    # 1) 数据（仅真实；--tf 15m 时由真实 1m 聚合，bars_limit 为目标周期根数）
    df = load_real_or_exit(bars_limit, catalog_path, tf)
    logger.info(f"回测周期 {tf}，{len(df)} 根：{df.index.min()} -> {df.index.max()}")

    # 2) 引擎：FractionalBacktest（小数仓位）+ 保证金上限（max_leverage SSOT）
    if strategy_flag not in ("v2", "v3", "v4"):
        logger.warning(f"策略 {strategy_flag} 不可用，本次按 v3 状态自适应执行")
        strategy_flag = "v3"
    strategy_cls = {"v3": RegimeAdaptiveBS, "v4": FactorAlphaBS}.get(strategy_flag, TrendAdaptiveBS)
    if use_flow and strategy_flag in ("v3", "v4"):
        from eth_hft.data.flow import load_or_fetch_flow
        from eth_hft.strategy.micro_scalper_bs import FlowRegimeAdaptiveBS, make_flow_strategy
        flow_df = load_or_fetch_flow(df.index)
        if strategy_cls is RegimeAdaptiveBS:
            set_flow_source(flow_df)
            strategy_cls = FlowRegimeAdaptiveBS  # 模块级类（与 optimize 一致）
        else:
            strategy_cls = make_flow_strategy(strategy_cls, flow_df)  # v4：仅 .run() 场景
        cov = float(flow_df["coverage_pct"].iloc[0]) if "coverage_pct" in flow_df else -1.0
        logger.info(f"流量闸门策略已启用（taker覆盖 {cov}%）；flow_gate 可经 params_live 传入")
    bt = backtesting.lib.FractionalBacktest(
        df,
        strategy_cls,
        fractional_unit=1 / 1e8,          # 1e-8 ETH 精度
        cash=equity_usdt,
        commission=per_side_commission,   # 单边费率
        margin=1.0 / max(1, max_leverage),
        exclusive_orders=True,            # 单仓净持仓（≙ NETTING）
        finalize_trades=True,             # 末根强制了结，统计完整
    )
    run_kwargs = dict(
        risk_usdt=risk_usdt,
        use_cost_gate=True,
        min_edge_bps=min_edge_bps,
        commission_bps=per_side_commission * 1e4,
        spread_bps=spread_bps,
        slippage_bps=slip_bps,
        buffer_bps=buffer_bps,
    )
    params_source = "class defaults"
    if strategy_flag in ("v3", "v4"):
        # 自动采用最新校准参数（optimize_strategy.py 达标后写入 configs/params_live.json）
        live, params_source = _load_live_params(tf)
        run_kwargs.update(live)
        if live:
            logger.info(f"已加载校准参数 {len(live)} 项（来源: {params_source}）: {live}")
    stats = bt.run(**run_kwargs)

    # 3) 统计映射（dashboard/报告兼容结构）
    trades_df: pd.DataFrame = stats["_trades"]
    n_trades = int(stats["# Trades"])
    equity_final = float(stats["Equity Final [$]"])
    fees_paid = float(stats.get("Commissions [$]", 0.0) or 0.0)
    win_rate = float(stats["Win Rate [%]"]) / 100.0

    rows = []
    for _, r in trades_df.iterrows():
        size = float(r["Size"])
        is_long = size > 0
        entry = float(r["EntryPrice"])
        exit_px = float(r["ExitPrice"])
        # 退出原因推断（引擎 _trades 无显式 reason，用 SL/TP 距离近似）
        sl, tp = r.get("SL"), r.get("TP")
        eps = entry * 1e-4 + 1e-9
        reason = "信号/其他"
        if pd.notna(sl) and pd.notna(tp):
            if is_long and exit_px <= float(sl) + eps:
                reason = "止损"
            elif not is_long and exit_px >= float(sl) - eps:
                reason = "止损"
            elif is_long and exit_px >= float(tp) - eps:
                reason = "止盈"
            elif not is_long and exit_px <= float(tp) + eps:
                reason = "止盈"
        opened = r["EntryTime"].strftime("%m-%d %H:%M") if "EntryTime" in trades_df.columns and pd.notna(r.get("EntryTime")) else ""
        closed = r["ExitTime"].strftime("%m-%d %H:%M") if "ExitTime" in trades_df.columns and pd.notna(r.get("ExitTime")) else ""
        hold_bars = int(r["ExitBar"] - r["EntryBar"]) if pd.notna(r.get("ExitBar")) else None
        rows.append({
            "status": "closed",
            "side": "LONG" if is_long else "SHORT",
            "entry": round(entry, 2),
            "exit": round(exit_px, 2),
            "pnl": round(float(r["PnL"]), 4),
            "fee": round(float(r.get("Commission", 0.0) or 0.0), 4),
            "size_eth": round(abs(size), 4),
            "exit_reason": reason,
            "opened": opened,
            "closed": closed,
            "hold_bars": hold_bars,
        })

    # 权益曲线（采样至最多2000点，供 dashboard 原生预览）
    eq_points = []
    try:
        ec = stats["_equity_curve"]
        step = max(1, len(ec) // 2000)
        sub = ec.iloc[::step]
        for ts, row in sub.iterrows():
            eq_points.append({"t": str(ts), "e": round(float(row["Equity"]), 6)})
    except Exception as e:
        logger.debug(f"权益曲线提取跳过: {e}")

    def _f(key, default=0.0):
        v = stats.get(key)
        try:
            return round(float(v), 4)
        except Exception:
            return default

    summary = {
        "engine": f"{ENGINE_NAME} {getattr(backtesting, '__version__', '>=0.6')}",
        "strategy": strategy_flag,
        "bars": len(df),
        "data_range": f"{df.index.min()} -> {df.index.max()}",
        "instrument": "ETH-USDT-SWAP (1m)",
        "venue": "OKX(模拟撮合)",
        "starting_balance": f"{equity_usdt:.2f} USDT",
        "trades": n_trades,
        "open_positions": 0,  # finalize_trades=True，全部已了结
        "wins": int(round(win_rate * n_trades)),
        "win_rate": round(win_rate, 4),
        "realized_pnl": round(equity_final - equity_usdt, 4),
        "open_upnl": 0.0,
        "fees": round(fees_paid, 4),
        "account_pnl": round(equity_final - equity_usdt, 4),
        "equity_final": round(equity_final, 4),
        "return_pct": _f("Return [%]"),
        "buy_hold_return_pct": _f("Buy & Hold Return [%]"),
        "exposure_pct": _f("Exposure Time [%]"),
        "profit_factor": _f("Profit Factor"),
        "sharpe": _f("Sharpe Ratio"),
        "max_drawdown_pct": _f("Max. Drawdown [%]"),
        "sqn": _f("SQN"),
        "commission_per_side": per_side_commission,
        "params": {
            "risk_usdt": risk_usdt,
            "max_leverage": max_leverage, "min_edge_bps": min_edge_bps,
            "source": params_source,
            **{f"live.{k}": v for k, v in (live if strategy_flag in ("v3", "v4") else {}).items()},
        },
        "note": "backtesting.py 专业引擎逐bar撮合；市价单次根开盘成交，SL/TP bar内触发，无未来函数",
    }

    # 4) 报告：交互式 HTML（plotly K线+交易+权益）+ JSON
    report_dir = Path("reports/backtesting")
    report_dir.mkdir(parents=True, exist_ok=True)
    html_path = report_dir / f"{run_id}.html"
    try:
        bt.plot(filename=str(html_path), open_browser=False)
        logger.info(f"交互式报告 -> {html_path} ({html_path.stat().st_size/1024:.1f} KB)")
    except Exception as e:
        logger.warning(f"bt.plot 失败（{e}），回退内置 HTML 报告")
        try:
            from eth_hft.monitoring.report import generate_html_report

            generate_html_report(backtest_result=summary, bars_df=df.reset_index(drop=False).rename(columns={"index": "ts"}), trades=rows, output_path=html_path, run_id=run_id)
        except Exception as e2:
            logger.error(f"HTML 报告生成失败: {e2}")

    json_path = report_dir / f"{run_id}.json"
    # NaN/Inf → None（严格 JSON 不允许 NaN 字面量；日内短窗口年化指标会是 NaN）
    def _sanitize(x):
        if isinstance(x, dict):
            return {k: _sanitize(v) for k, v in x.items()}
        if isinstance(x, list):
            return [_sanitize(v) for v in x]
        if isinstance(x, float) and (x != x or x in (float("inf"), float("-inf"))):
            return None
        return x

    json_path.write_text(
        json.dumps(_sanitize({"summary": summary, "trades": rows, "equity": eq_points}), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    logger.info(
        f"回测完成：{n_trades} 笔 | 胜率 {win_rate:.1%} | 净PnL {summary['realized_pnl']:+.4f} U "
        f"| 手续费 {summary['fees']:.4f} U | JSON -> {json_path}"
    )
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="backtesting.py 专业回测（ETH-USDT 1m scalper）")
    parser.add_argument("--bars", type=int, default=300, help="K线数量（dashboard 滑块传入）")
    parser.add_argument("--run-id", type=str, default=None, help="报告文件名ID")
    parser.add_argument("--strategy", type=str, default="v3", choices=["v3", "v4", "v2"],
                        help="v3=状态自适应(推荐) v4=因子Alpha(v1 8因子移植) v2=纯趋势ATR")
    parser.add_argument("--commission", type=float, default=None, help="单边佣金覆盖（保守测试，如 0.0005）")
    parser.add_argument("--tf", type=str, default="1m", choices=["1m", "3m", "5m", "15m"],
                        help="K线周期：由真实1m聚合（bars=目标周期根数，注意窗口语义按根数）")
    parser.add_argument("--flow", action="store_true", help="启用 Rubik 主动买卖比流量闸门")
    args = parser.parse_args()
    run_backtest(
        bars_limit=args.bars,
        run_id=args.run_id,
        strategy_flag=args.strategy,
        commission=args.commission,
        tf=args.tf,
        use_flow=args.flow,
    )
