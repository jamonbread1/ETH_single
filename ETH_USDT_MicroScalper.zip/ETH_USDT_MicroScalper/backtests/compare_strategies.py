"""
双策略对比：V0（第一版基准） vs V1（算法核心完整版）
可上线、非demo，统一用 Nautilus 真实撮合，对比 fill/成本/胜率
"""
from __future__ import annotations
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from decimal import Decimal
import pandas as pd
from loguru import logger
from nautilus_trader.backtest.engine import BacktestEngine
from nautilus_trader.config import BacktestEngineConfig, LoggingConfig
from nautilus_trader.model.identifiers import InstrumentId, Venue
from nautilus_trader.model.instruments import CryptoPerpetual
from nautilus_trader.model.currencies import ETH, USDT
from nautilus_trader.model.objects import Price, Quantity, Money
from nautilus_trader.model.enums import AccountType, OmsType, BookType
from nautilus_trader.model.data import Bar, BarType

from eth_hft.data.okx_rest import fetch_candles
from eth_hft.strategy.selectable import SelectableStrategy, SelectableConfig

def make_instrument(ts_ns: int = 0):
    """P0-2 唯一真源：core/instrument.py"""
    try:
        from eth_hft.core.instrument import DEFAULT_ETH_SWAP, InstrumentSpec, to_nautilus_instrument

        try:
            from eth_hft.data.okx_rest import fetch_instruments

            raw = fetch_instruments("SWAP", "ETH-USDT-SWAP")
            spec = InstrumentSpec.from_okx_raw(raw[0]) if raw else DEFAULT_ETH_SWAP
        except Exception:
            spec = DEFAULT_ETH_SWAP
        return to_nautilus_instrument(spec, ts_ns)
    except Exception:
        iid = InstrumentId.from_str("ETHUSDT-PERP.OKX")
        from nautilus_trader.model.identifiers import Symbol

        return CryptoPerpetual(
            instrument_id=iid,
            raw_symbol=Symbol("ETHUSDT"),
            base_currency=ETH,
            quote_currency=USDT,
            settlement_currency=USDT,
            is_inverse=False,
            price_precision=2,
            size_precision=2,
            price_increment=Price(0.01, 2),
            size_increment=Quantity(0.01, 2),
            multiplier=Quantity(0.1, 1),
            lot_size=Quantity(0.01, 2),
            max_quantity=Quantity(1000, 0),
            min_quantity=Quantity(0.01, 2),
            max_price=Price(100000, 2),
            min_price=Price(0.01, 2),
            margin_init=Decimal("0.01"),
            margin_maint=Decimal("0.005"),
            maker_fee=Decimal("0.0002"),
            taker_fee=Decimal("0.0005"),
            ts_event=ts_ns,
            ts_init=ts_ns,
        )

def df_to_bars(df: pd.DataFrame, bar_type_str="ETHUSDT-PERP.OKX-1-MINUTE-LAST-EXTERNAL"):
    bar_type = BarType.from_str(bar_type_str)
    vol_col = "volume" if "volume" in df.columns else "vol"
    bars = []
    for _, row in df.iterrows():
        ts_ns = int(pd.Timestamp(row["ts"]).timestamp() * 1_000_000_000)
        bars.append(Bar(
            bar_type=bar_type,
            open=Price(float(row["open"]), 2),
            high=Price(float(row["high"]), 2),
            low=Price(float(row["low"]), 2),
            close=Price(float(row["close"]), 2),
            volume=Quantity(float(row[vol_col]), 2),
            ts_event=ts_ns,
            ts_init=ts_ns,
        ))
    return bars

def _load_compare_cfg():
    try:
        from eth_hft.config.loader import load_system_config  # type: ignore

        raw = load_system_config()
        return float(raw.get("account", {}).get("equity_usdt", 50.0)), float(raw.get("position", {}).get("risk_budget_usdt", 0.20))
    except Exception:
        return 50.0, 0.20


def run_one(mode: str, bars, instrument, equity_usdt: float = 50.0):
    config = BacktestEngineConfig(trader_id=f"TRADER-{mode.upper()}", logging=LoggingConfig(log_level="WARNING"))
    engine = BacktestEngine(config=config)
    venue = Venue("OKX")
    engine.add_venue(
        venue=venue,
        oms_type=OmsType.NETTING,  # P0-2/ P0-3 对齐：NETTING 净持仓 + 限价 PostOnly，与 run_backtest 一致（原 HEDGING 堆积未平仓）
        account_type=AccountType.MARGIN,
        starting_balances=[Money(equity_usdt, USDT)],
        default_leverage=Decimal(100),
        book_type=BookType.L1_MBP,
        bar_execution=True,
        trade_execution=True,
    )
    engine.add_instrument(instrument)
    engine.add_data(bars)
    strat_cfg = SelectableConfig(instrument_id="ETHUSDT-PERP.OKX", bar_type="ETHUSDT-PERP.OKX-1-MINUTE-LAST-EXTERNAL", strategy_mode=mode)
    strat = SelectableStrategy(config=strat_cfg)
    engine.add_strategy(strategy=strat)
    engine.run()
    result = {
        "mode": mode,
        "orders": 0,
        "pnl": 0.0,
    }
    try:
        account = engine.portfolio.account(venue)
        if account:
            result["pnl"] = float(account.balance_total(USDT).as_double()) - equity_usdt
    except Exception:
        pass
    try:
        result["orders"] = len(engine.cache.orders() or [])
    except Exception:
        pass
    engine.dispose()
    return result


def main():
    # P1-5/P2-8 优先读 catalog 可复现，无则拉取
    try:
        from eth_hft.data.catalog import DataCatalog  # type: ignore

        cat = DataCatalog()
        df_cat = cat.read_bars_pandas()
        if df_cat is not None and not df_cat.empty and len(df_cat) >= 300:
            df = df_cat.iloc[-500:].reset_index(drop=True) if len(df_cat) > 500 else df_cat
            print(f"命中 catalog {len(df)} bars（可复现）{df['ts'].min()} -> {df['ts'].max()}")
        else:
            raise RuntimeError("catalog 空")
    except Exception:
        print("拉取 500 根 1m 用于对比（catalog 未命中）...")
        df = fetch_candles("ETH-USDT-SWAP", "1m", 500)
    bars = df_to_bars(df)
    instrument = make_instrument(bars[0].ts_init if bars else 0)

    print(f"数据 {len(bars)} bars {df['ts'].min()} -> {df['ts'].max()}")
    equity_usdt, _ = _load_compare_cfg()
    for mode in ["v0", "v1"]:
        print(f"\n=== 回测 {mode.upper()} (限价 PostOnly, 权益 {equity_usdt}U) ===")
        res = run_one(mode, bars, instrument, equity_usdt=equity_usdt)
        print(f"{mode}: orders={res['orders']} pnl={res['pnl']:.4f}U")
        import json

        Path("reports/compare").mkdir(parents=True, exist_ok=True)
        Path(f"reports/compare/{mode}.json").write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")

    print("\n对比完成，报告见 reports/compare/")
    print("说明：V0 为第一版基准（固定50根一单），V1 为算法核心完整版（8因子+Regime+双Alpha+成本过滤）")
    print("真实优劣需看 After-Cost Sharpe、ProfitFactor、MaxDrawdown，非单次 PnL")

if __name__ == "__main__":
    main()
