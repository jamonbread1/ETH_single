"""
v1「8因子」价值评估：IC 统计 + 同骨架回测对比（仅真实数据）

回答「v1 8因子还有价值吗」：
  1) IC 分析：按 v1 原权重构造 trend/mr 分数，与未来 1/5/15 根收益做 Spearman 秩相关，
     按 VR 状态分层看预测力（正 IC=有动量价值，负 IC=有反转价值）
  2) 同骨架 A/B：v3（SMA信号） vs v4（因子Alpha信号），唯一差异是信号源，
     风控/成本/状态切换完全一致 → 干净归因
注：OBI/MPD 需盘口tick，编目无此数据，按 v1 权重占比剔除重归一（详见策略类注释）。

用法：
  python backtests/test_v1_factors.py --bars 3000
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pandas as pd
from loguru import logger

from backtests.run_backtest import _load_cfg, load_real_or_exit
from eth_hft.strategy.micro_scalper_bs import RegimeAdaptiveBS, FactorAlphaBS


# --------------------------------------------------------------------------- #
# 因子/分数向量化计算（与 FactorAlphaBS.init 完全一致的公式）
# --------------------------------------------------------------------------- #
def compute_scores(df: pd.DataFrame, z_window: int = 60, z_min: int = 20,
                   cvd_len: int = 30, inten_len: int = 30) -> pd.DataFrame:
    o, h, l, c, v = (pd.Series(df[k]) for k in ("Open", "High", "Low", "Close", "Volume"))

    def zof(s: pd.Series) -> pd.Series:
        m = s.shift(1).rolling(z_window, min_periods=z_min).mean()
        sd = s.shift(1).rolling(z_window, min_periods=z_min).std(ddof=1).mask(lambda x: x < 1e-12)
        return ((s - m) / sd).clip(-3, 3)

    m1, m3, m5 = c.pct_change(1), c.pct_change(3), c.pct_change(5)
    rng = h - l
    signed_vol = v * (2.0 * (c - o) / rng.where(rng > 0, np.nan)).fillna(0.0)
    cvd = signed_vol.rolling(cvd_len).sum()
    cvd_z = zof(cvd / v.rolling(cvd_len).sum().replace(0, np.nan))
    intensity = v / v.rolling(inten_len).median().replace(0, np.nan) - 1.0

    trend_score = 0.333 * zof(m3) + 0.222 * zof(m5) + 0.278 * cvd_z + 0.167 * zof(intensity)
    mr_score = 0.40 * zof(-m1) + 0.267 * zof(-m3) + 0.333 * cvd_z

    r1 = c.diff()
    rk = c.diff(30)
    vr = (rk.rolling(240).var() / (30 * r1.rolling(240).var())).replace([np.inf, -np.inf], np.nan).bfill()

    out = pd.DataFrame({"trend_score": trend_score, "mr_score": mr_score, "vr": vr})
    out["fwd1"] = c.pct_change(1).shift(-1)
    out["fwd5"] = c.pct_change(5).shift(-5)
    out["fwd15"] = c.pct_change(15).shift(-15)
    return out


def rank_ic(s: pd.Series, fwd: pd.Series) -> float:
    j = pd.concat([s, fwd], axis=1).dropna()
    if len(j) < 30:
        return float("nan")
    return float(j.iloc[:, 0].corr(j.iloc[:, 1], method="spearman"))


def ic_table(scores: pd.DataFrame, label: str) -> list[dict]:
    rows = []
    for name, mask in (("全部", scores["vr"].notna()),
                       ("趋势(VR>1.1)", scores["vr"] >= 1.10),
                       ("回归(VR<0.9)", scores["vr"] <= 0.90)):
        sub = scores[mask]
        row = {"状态": label if name == "全部" else f"{label}|{name}", "样本": int(len(sub))}
        for hz in ("fwd1", "fwd5", "fwd15"):
            row[f"IC({hz[3:]})"] = round(rank_ic(sub["trend_score"], sub[hz]), 4)
            row[f"ICmr({hz[3:]})"] = round(rank_ic(sub["mr_score"], sub[hz]), 4)
        rows.append(row)
    return rows


# --------------------------------------------------------------------------- #
# 回测对比（同骨架 A/B）
# --------------------------------------------------------------------------- #
def make_bt(data: pd.DataFrame, cls, cash: float, commission: float, margin: float):
    import backtesting

    return backtesting.lib.FractionalBacktest(
        data, cls, fractional_unit=1 / 1e8, cash=cash, commission=commission, margin=margin,
        exclusive_orders=True, finalize_trades=True,
    )


V_COMMON = dict(use_cost_gate=True, min_edge_bps=1.5, commission_bps=3.0,
                spread_bps=0.8, slippage_bps=0.6, buffer_bps=1.0)


def snap(stats) -> dict:
    def g(k):
        v = stats.get(k)
        try:
            f = float(v)
            return None if f != f else round(f, 4)
        except Exception:
            return None
    return {"trades": int(stats["# Trades"]), "win_pct": g("Win Rate [%]"),
            "ret_pct": g("Return [%]"), "pf": g("Profit Factor"), "sqn": g("SQN"),
            "mdd_pct": g("Max. Drawdown [%]")}


def main(bars: int = 3000, catalog_path: str | None = None, tf: str = "1m") -> dict:
    cfg = _load_cfg()
    catalog_path = catalog_path or cfg.get("data_root", "data/catalog")
    equity = float(cfg.get("account", {}).get("equity_usdt", 50.0))
    risk_usdt = float(cfg.get("position", {}).get("risk_budget_usdt", 0.2))
    max_lev = int(cfg.get("position", {}).get("max_leverage", 100))
    commission, margin = 0.0003, 1.0 / max(1, max_lev)

    data = load_real_or_exit(bars, catalog_path, tf)
    logger.info(f"真实数据 {len(data)} 根（周期 {tf}）：{data.index.min()} -> {data.index.max()}")

    # ---- 1) IC 分析 ----
    scores = compute_scores(data)
    ic_rows = ic_table(scores, "全样本")
    split = int(len(data) * 0.7)
    ic_rows += ic_table(scores.iloc[:split], "IS70")
    ic_rows += ic_table(scores.iloc[split:], "OOS30")
    ic_df = pd.DataFrame(ic_rows)
    logger.info(f"因子IC（Spearman，trend_score/mr_score vs 未来收益）:\n{ic_df.to_string(index=False)}")

    # ---- 2) 同骨架 A/B ----
    results = {}
    for name, cls, extra in (("v3_SMA信号", RegimeAdaptiveBS, {}),
                             ("v4_因子Alpha信号", FactorAlphaBS, {})):
        st = make_bt(data, cls, equity, commission, margin).run(risk_usdt=risk_usdt, **V_COMMON, **extra)
        results[name] = {"full": snap(st)}
        st_is = make_bt(data.iloc[:split], cls, equity, commission, margin).run(risk_usdt=risk_usdt, **V_COMMON, **extra)
        st_oos = make_bt(data.iloc[split:], cls, equity, commission, margin).run(risk_usdt=risk_usdt, **V_COMMON, **extra)
        results[name]["is"] = snap(st_is)
        results[name]["oos"] = snap(st_oos)
        logger.info(f"{name}: full={results[name]['full']} | OOS={results[name]['oos']}")

    v3o, v4o = results["v3_SMA信号"]["oos"], results["v4_因子Alpha信号"]["oos"]
    verdict = (
        f"v4 OOS ({v4o['ret_pct']}%) {'优于' if (v4o['ret_pct'] or -1e9) > (v3o['ret_pct'] or -1e9) else '不优于'} "
        f"v3 OOS ({v3o['ret_pct']}%)。"
        + ("因子信号有增量价值，建议沿用/继续校准 v4。"
           if (v4o['ret_pct'] or -1e9) > (v3o['ret_pct'] or -1e9)
           else "1m bar 上因子代理未见增量（OBI/MPD 缺失+CV D代理粗糙），v3 SMA信号已足够/更稳。")
    )
    logger.info("结论: " + verdict)

    out = {
        "data_source": f"OKX 真实K线 {len(data)} 根（周期 {tf}）",
        "timeframe": tf,
        "data_range": f"{data.index.min()} -> {data.index.max()}",
        "is_oos_split": f"自动 70/30: {split}/{len(data) - split}",
        "ic_table": json.loads(ic_df.to_json(orient="records", force_ascii=False)),
        "backtest": results,
        "verdict": verdict,
        "note": "OBI/MPD 无盘口数据已剔除重归一；CVD 为 OHLCV 符号量代理；IC 为 Spearman 秩相关",
    }
    report_dir = Path("reports/backtesting")
    report_dir.mkdir(parents=True, exist_ok=True)
    (report_dir / "v1_factors_verdict.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    logger.info(f"评估报告 -> {report_dir / 'v1_factors_verdict.json'}")
    return out


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="v1 8因子价值评估（IC + 同骨架A/B）")
    parser.add_argument("--bars", type=int, default=3000)
    parser.add_argument("--tf", type=str, default="1m", choices=["1m", "3m", "5m", "15m"],
                        help="K线周期：由真实1m聚合（bars=目标周期根数）")
    parser.add_argument("--catalog", type=str, default=None)
    args = parser.parse_args()
    main(bars=args.bars, catalog_path=args.catalog, tf=args.tf)
