"""
统一入口：系统级 CLI（重构后，以 backtesting.py 为回测内核）
用法：
  python main.py check        # 环境自检（费率/合约/健康）
  python main.py instrument   # 校验合约规格与微仓
  python main.py backtest     # backtesting.py 引擎回测（v2 趋势自适应，可透传 --bars/--run-id）
  python main.py catalog      # 查看编目
  python main.py dashboard    # Streamlit 控制台
本地、无 docker、无 git 即可运行
"""
from __future__ import annotations
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))

from loguru import logger
from eth_hft.core.logger import setup_logger
setup_logger()

def print_help():
    print("""
ETH-USDT Selective Micro Scalper - 系统入口（backtesting.py 回测内核）

用法:
  python main.py check          环境自检（费率 0.04%/0.07%/0.10% + 合约 + 健康）
  python main.py instrument     校验合约规格与微仓可行性（RiskBudget 反推）
  python main.py backtest       回测（可加 --bars/--tf/--strategy；参数经 IS/OOS 校准自动启用）
  python main.py catalog        查看 Parquet 编目
  python main.py dashboard      启动可视化控制台（Streamlit）
  python main.py help           帮助
""")

def cmd_check():
    from eth_hft.core.fee_model import FeeConfig, round_trip_fee
    from eth_hft.core.instrument import InstrumentSpec
    from eth_hft.data.okx_rest import fetch_instruments
    cfg = FeeConfig()
    print(f"双Maker往返 {round_trip_fee(True, True, cfg):.4%} (预期 0.04%)")
    print(f"一Maker一Taker {round_trip_fee(True, False, cfg):.4%} (预期 0.07%)")
    print(f"双Taker {round_trip_fee(False, False, cfg):.4%} (预期 0.10%)")
    assert abs(round_trip_fee(True, True, cfg) - 0.0004) < 1e-9
    raw = fetch_instruments("SWAP", "ETH-USDT-SWAP")
    spec = InstrumentSpec.from_okx_raw(raw[0])
    print(f"合约: {spec.inst_id} ctVal={spec.ct_val} lotSz={spec.lot_sz} minSz={spec.min_sz} maxLev={spec.lever_max}")
    print("费率/合约 OK")
    # 健康（磁盘/编目）
    import psutil
    free = round(psutil.disk_usage(str(Path.cwd())).free / 1024**3, 2)
    print(f"磁盘剩余 {free} GB")
    print("自检通过")

def cmd_instrument():
    from eth_hft.data.okx_rest import fetch_instruments
    from eth_hft.core.instrument import InstrumentSpec
    from eth_hft.risk.position_sizer import calc_position
    raw = fetch_instruments("SWAP", "ETH-USDT-SWAP")
    spec = InstrumentSpec.from_okx_raw(raw[0])
    print(f"规格: lotSz={spec.lot_sz} minSz={spec.min_sz} tickSz={spec.tick_sz} ctVal={spec.ct_val} maxLever={spec.lever_max}")
    for bps in [6, 10, 30, 50]:
        r = calc_position(price=2444.48, stop_pct=bps/1e4, risk_budget_usdt=0.20, spec=spec, equity_usdt=50)
        print(f"止损{bps}bps -> 实际 {r.notional_usdt:.1f}U {r.size_contracts}张 保证金{r.margin_needed:.2f}U 可行={r.feasible}")
    print("杠杆为结果，非目标")

def cmd_backtest():
    # 调用 backtesting.py 专业回测（支持透传参数：--bars/--run-id/--strategy/--commission）
    import subprocess
    result = subprocess.run([sys.executable, "backtests/run_backtest.py", *sys.argv[2:]], capture_output=False)
    print(f"回测退出码 {result.returncode}，报告见 reports/backtesting/")

def cmd_catalog():
    from eth_hft.data.catalog import DataCatalog
    cat = DataCatalog("data/catalog")
    files = cat.list_bars()
    print(f"编目路径 data/catalog，共 {len(files)} 个 parquet")
    for f in files[:5]:
        print(" ", f)
    if files:
        df = cat.read_bars_pandas()
        print(f"总 bars ~{len(df)} 行，{df['ts'].min()} -> {df['ts'].max()}" if not df.empty else "空")

def main():
    if len(sys.argv) < 2 or sys.argv[1] in ("help", "-h", "--help"):
        print_help()
        return
    cmd = sys.argv[1]
    if cmd == "check":
        cmd_check()
    elif cmd == "instrument":
        cmd_instrument()
    elif cmd == "backtest":
        cmd_backtest()
    elif cmd == "catalog":
        cmd_catalog()
    elif cmd == "dashboard":
        import subprocess
        subprocess.run([sys.executable, "-m", "streamlit", "run", "app.py", "--server.headless", "false"])
    else:
        print(f"未知命令: {cmd}")
        print_help()

if __name__ == "__main__":
    main()
