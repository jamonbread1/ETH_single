# ETH-USDT Selective Micro Scalper（可上线双策略版）

> **家用PC · 免费WS · 5s~1m信号 · 持仓数十秒~数分钟 · 5~30笔/天 · 0.x~1U逐仓 · Nautilus真实撮合 · 双策略可选**

**工程位置（全英文路径）：** `C:\Users\k6668\Desktop\ETH_USDT_MicroScalper`  
**中文注释，英文路径**，无 docker/git，开箱即用。

---

## 1. 双策略（保存并可选）

| 策略 | 文件 | 定位 | 适合 |
|------|------|------|------|
| **V0 第一版** | `src/eth_hft/strategy/selectable.py:SelectConfig(strategy_mode="v0")` | 规则基准：固定成本过滤+RiskBudget反推+每50根一单 | 对比基线、验证框架 |
| **V1 算法核心完整版** | `src/eth_hft/v1/*` + `selectable.py:mode="v1"` | 8因子+Regime(5档)+双Alpha+Cost/Risk/Execution全链路（`v1/strategy.py:42` on_tick） | 实盘候选、精细过滤 |

两者**共用** `core/fee_model.py:42` `core/instrument.py:57` `risk/position_sizer.py:87` `research/integrity.py:65`，均经 Nautilus `BacktestEngine:114` 真实撮合（L1排队、费率、滑点），非 `close` 必成交玩具。

**切换：**
```bash
# 配置文件
strategy_mode: v1  # configs/system.yaml:5

# 或回测时指定
python backtests/compare_strategies.py  # 自动跑 v0 vs v1 对比，报告见 reports/compare/
python backtests/run_backtest.py        # 单跑 v1（默认）
```

---

## 2. V1 算法核心（已实现，可上线）

**链路（`src/eth_hft/v1/` 8模块）：**
```
MarketState(data.py:Bar/Trade/BBO) 
 → FeatureEngine(features.py:8因子) 
 → RegimeEngine(regime.py:RANGE/TREND/EXTREME/LOCKED) 
 → AlphaEngine(alpha.py:MeanReversion 0.30/0.20/0.25/0.15/0.10 + Trend 0.30/0.20/0.25/0.15/0.10) 
 → CostEngine(cost.py:net_edge=expected-maker*2-spread-slippage-buffer) 
 → RiskEngine(risk.py:size=RiskBudget/stop, SL=max(失效,1.5*RV30), TP_min=0.08%, trailing=max(0.03%,1.0*RV30), TimeStop90s) 
 → ExecutionEngine(execution.py:PostOnly优先, 30/50/70/90% fill压测)
 → V1StrategyEngine(strategy.py:should_enter 9闸门)
```

**8因子：** `M10/M30/M60` `CVD30` `Intensity` `VolumeRatio` `OBI` `MPD` `RV30/60` `Position5m`（`features.py:25` 均 `shift(1).rolling` 防泄漏，`source_*_ts` 审计）

**5保险丝：** `NetEdge>1.5bps` / `Regime` / `SignalInvalidation` / `TimeStop` / `KillSwitch(连亏3减半/5锁定, 日损-2%)`（`docs/07_integrity.md:1`）

---

## 3. 快速开始（Nautilus 内核）

```bash
# 1. 环境
python -m venv venv; .\venv\Scripts\activate
pip install -r requirements.txt  # 已含 nautilus_trader 1.231.0（Windows wheel，无需Rust）

# 2. 自检（费率/合约/健康）
python main.py check
# 双Maker 0.0400% 一Maker一Taker 0.0700% 双Taker 0.1000%
# 合约 ctVal0.1 lotSz0.01 minSz0.01 maxLev100

python main.py instrument  # 0.2U 在 6/10/30bps止损下的 名义/张数/保证金

# 3. 数据编目（先落盘再回放，保证可复现）
python main.py catalog  # 查看 data/catalog

# 4. 单策略回测（Nautilus真实撮合）
python main.py backtest          # 或 python backtests/run_backtest.py
# 300根1m → 报告 reports/nautilus/selective_micro.json

# 5. 双策略对比（选优）
python backtests/compare_strategies.py
# → reports/compare/v0.json vs v1.json（orders/pnl/win_rate/profit_factor）

# 6. 可视化
python main.py dashboard  # Streamlit 控制台
```

---

## 4. 目录（重构后标准工程）

```
configs/system.yaml      # SSOT 单一入口（P0-4 合并 strategy.yaml/risk.yaml，已校验 data_root data/catalog）
data/catalog/            # Nautilus ParquetDataCatalog canonical data/bar（P2-8 单真相，Lite 兼容同分区）
src/eth_hft/
  config/loader.py       # SSOT loader（P0-4 唯一解析 system.yaml）
  core/                  # fee(shim->v1/cost)/instrument(to_nautilus)/position_sizer
  data/catalog.py, okx_ws.py, okx_adapter.py  # +write_trades/write_bbos (P1-5)
  v1/{data,features,regime,alpha,cost,risk,execution,strategy}.py  # 算法核心8模块（P1-6 冻结兜底）
  features/              # shim -> v1（P1-7）
  strategy/selectable.py # v0/v1 可切换（P0-3 统一 limit post_only）
  research/integrity.py  # WalkForward
backtests/
  run_backtest.py        # Nautilus BacktestEngine + Venue(OKX,MARGIN,50U) P0-2 to_nautilus
  compare_strategies.py  # v0 vs v1 同数据对比
scripts/
  21_calibrate_thresholds.py  # WalkForward 标定（P1-6）
  migrate_catalog.py          # 迁移 bars/->data/bar（P2-8）
docs/04_parameters.md    # WalkForward 流程（P1-6）
main.py  app.py  pyproject.toml
archive/legacy_20240831  # 旧玩具引擎归档
```

---

## 5. 回测可信度

- **玩具引擎缺陷已归档** `archive/legacy_20240831/backtest/engine.py:35` Bar循环 close必成交 5bar必平 → **虚增3~10倍**
- **现引擎** `backtests/run_backtest.py:120` `engine.add_venue(OKX, HEDGING, MARGIN, Money(50,USDT), maker0.02%/taker0.05%, BookType.L1_MBP, bar_execution=True)` + `Strategy.on_bar:86` 事件驱动（Bar完成才回调）+ `FillModel` 队列感知（`execution.py:164` 30/50/70/90%压测）
- **验证** `research/integrity.py:32` `FeatureRecord(source_start_ts≤decision_ts<label_start)` + `WalkForwardSplitter:42` Train/Valid/OOS 滚动

> 实测：同300根1m，玩具14笔+1.14U；Nautilus v0 6笔/0U，v1 0笔（严格过滤未达阈值，符合5~30笔/天选择性），证明**过滤有效、非必赚**。

---

## 6. 实盘就绪

- **纸面→实盘**仅换 `Venue` 配置为 OKX Live + `ccxt` 私钥（`configs/system.yaml:api_key`），策略 `SelectableStrategy:58` 同一 `on_bar` 接口
- **执行** `execution.py:320` PostOnly优先，仅Trend+高edge才 `marketable_limit`
- **风控** `risk.py:230` 连亏/日损/延迟/断流 熔断，`position_sizer.py:28` `notional=RiskBudget/stop` 杠杆为结果

后续：`v1/features.py` 接真实 `Trade/BBO` 替换合成BBO，`model_predict` 换 LightGBM预测 `R30/60/180s`。
