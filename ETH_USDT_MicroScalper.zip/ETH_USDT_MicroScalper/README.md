# ETH-USDT Selective Micro Scalper（可上线双策略版）

> **家用PC · 免费WS · 1m信号 · backtesting.py 专业引擎逐bar撮合 · 三策略可选（v2 趋势自适应 推荐）· IS/OOS 校准内置**

**工程位置（全英文路径）：** `C:\Users\k6668\Desktop\ETH_USDT_MicroScalper`  
**中文注释，英文路径**，无 docker/git，开箱即用。

---

## 1. 双策略（保存并可选）

| 策略 | 文件 | 定位 | 状态 |
|------|------|------|------|
| **V3 状态自适应（在役，推荐）** | `strategy/micro_scalper_bs.py:RegimeAdaptiveBS` | 方差比VR判状态：趋势→动量跟随 / 均值回归→反向回归 / 震荡→不交易 | ✅ 实盘候选（`optimize_strategy.py` 自动IS/OOS校准并启用） |
| **V4 因子Alpha（在役，实验）** | `strategy/micro_scalper_bs.py:FactorAlphaBS` | v1「8因子」忠实移植（OBI/MPD无盘口数据剔除重归一，CVD为OHLCV代理）+ v1防泄漏zscore + v3风控骨架 | 🧪 `backtests/test_v1_factors.py` 评估后再定 |
| V1/V0 固定bps | `strategy/_archived.py` | TP8bps/SL10bps 固定括弧：对抗≥4.4bps往返成本期望为负（保守费率实测 835笔→-85%） | 🗄️ 已归档（2026-09），禁止新代码引用 |

回测内核（2026-09 重构）：开源专业引擎 **backtesting.py**（`FractionalBacktest` 支持小数仓位）逐bar撮合——市价单次根开盘成交、SL/TP 括弧单 bar 内触发、佣金/杠杆内建，无未来函数；算法层 `src/eth_hft/strategy/micro_scalper_bs.py`（v1/v2 均经 `configs/system.yaml` SSOT 注入）。

**切换：**
```bash
# 配置文件
strategy_mode: v1  # configs/system.yaml:5

# 或回测时指定
python backtests/compare_strategies.py  # 自动跑 v0 vs v1 对比，报告见 reports/compare/
python backtests/run_backtest.py        # 单跑 v1（默认）
```

---

## 2. V1 算法核心（已实现，可上线）

**链路（`src/eth_hft/v1/` 8模块）：**
```
MarketState(data.py:Bar/Trade/BBO) 
 → FeatureEngine(features.py:8因子) 
 → RegimeEngine(regime.py:RANGE/TREND/EXTREME/LOCKED) 
 → AlphaEngine(alpha.py:MeanReversion 0.30/0.20/0.25/0.15/0.10 + Trend 0.30/0.20/0.25/0.15/0.10) 
 → CostEngine(cost.py:net_edge=expected-maker*2-spread-slippage-buffer) 
 → RiskEngine(risk.py:size=RiskBudget/stop, SL=max(失效,1.5*RV30), TP_min=0.08%, trailing=max(0.03%,1.0*RV30), TimeStop90s) 
 → ExecutionEngine(execution.py:PostOnly优先, 30/50/70/90% fill压测)
 → V1StrategyEngine(strategy.py:should_enter 9闸门)
```

**8因子：** `M10/M30/M60` `CVD30` `Intensity` `VolumeRatio` `OBI` `MPD` `RV30/60` `Position5m`（`features.py:25` 均 `shift(1).rolling` 防泄漏，`source_*_ts` 审计）

**5保险丝：** `NetEdge>1.5bps` / `Regime` / `SignalInvalidation` / `TimeStop` / `KillSwitch(连亏3减半/5锁定, 日损-2%)`（`docs/07_integrity.md:1`）

---

## 2.5 OKX API 事实清单（实盘开发必读，2026-09 依官方文档核对）

| 项目 | 事实 | 代码落点 |
|------|------|----------|
| 近期K线 | `GET /market/candles` 每粒度仅保留**最近1440条**（1m≈1天），limit≤300，限速40次/2s(IP) | `okx_rest.py` 翻页第一段 |
| 历史K线 | `GET /market/history-candles` 可回溯**数年**（1s线仅3个月），limit≤300，限速20次/2s(IP) | 双接口接力第二段 |
| 缓存陷阱 | 行情多服务独立缓存，**相邻请求可能乱序/重复** → 必须 sort+去重 | `fetch_candles`/`DataCatalog.read_bars_pandas` |
| K线列序 | `ts,o,h,l,c,vol(张),volCcy(币),volCcyQuote(计价),confirm`；confirm=0 未完结须过滤 | 列名映射与 confirm 过滤 |
| 实时K线 | WS `wss://ws.okx.com:8443/ws/v5/public` 频道 `candle1m`（实盘增量用） | `data/okx_ws.py`（TODO实盘） |
| 深度/逐笔 | books 40次/2s(50ms更新)；trades 100次/2s；history-trades 20次/2s(3个月) | `data/okx_ws.py` / 因子升级 |
| **流量(Rubik)** | `rubik/stat/taker-volume-contract`：**unit 取值 0=币/1=张/2=U**（'ccy' 会 51000）；period [5m/15m/30m/1H/2H/4H]；**限速 5次/2s**(IP+instId)；limit≤100；begin=更新于/end=早于 | `data/flow.py`（5m≈2天/1H≈30天窗口，粒度自动降级） |
| OI/资金费率 | `contracts/open-interest-history` [ts,oi,oiCcy]；`public/funding-rate-history`(3个月, after=更旧) | 同上，code≠0 一律硬失败 |
| 代理 | 行情域 `www.okx.com` / `aws.okx.com` 自动切换；`OKX_PROXY`/`HTTPS_PROXY` 环境变量 | `okx_rest._proxies` |

> 单位提醒：SWAP 的 `vol` 单位是**张**（ctVal=0.1 ETH/张）。策略内只用量的比值（Intensity/VolumeRatio），无影响；如需币量用 `volCcy`。

## 3. 快速开始（backtesting.py 内核）

```bash
# 1. 环境
python -m venv venv; .\venv\Scripts\activate
pip install -r requirements.txt  # 含 backtesting.py + plotly（纯Python，Windows免编译）

# 2. 自检（费率/合约/健康）
python main.py check
# 双Maker 0.0400% 一Maker一Taker 0.0700% 双Taker 0.1000%
# 合约 ctVal0.1 lotSz0.01 minSz0.01 maxLev100

python main.py instrument  # 0.2U 在 6/10/30bps止损下的 名义/张数/保证金

# 3. 数据编目（先落盘再回放，保证可复现）
python main.py catalog  # 查看 data/catalog

# 4. 单策略回测（v2 趋势自适应）
python main.py backtest --bars 1000 --strategy v2   # 报告 reports/backtesting/*.html（交互式）
python main.py backtest --bars 1000 --strategy v1   # 旧固定bps对比

# 5. 拉取真实数据 → IS/OOS 参数校准（仅真实数据，不做任何合成）
python scripts/10_fetch_candles.py --bars 20000 --fill   # 补齐（双接口接力，1~2分钟；国内网络加 --proxy）
python backtests/optimize_strategy.py --bars 5000        # 真实K线 IS 3折稳健寻优 + OOS30% 验证（建议 5000~20000 根）

# 5.5 每笔经济学与持仓周期（2万根实证的核心教训）
#   实证：毛优势 +1.36%/OOS 但被 9.45U 费用吞没（每笔毛利≈0.4bps vs 成本≈6bps，14倍差距）
#   对策（全部入寻优网格，"少而厚"）：capture_mult[1,2,3]×成本门槛 / mr_sl_mult[0.8,1.3]×
#   mr_tp_mult[1.0,1.5]（R:R 可调，修复旧版风险1.3:目标1.0的结构性逆差）/ 持仓周期[15,45]bar /
#   ATR环境闸门[1,6]bps；OOS 报告含 多空方向归因（正毛利是谁贡献的→决定是否改单边）

# 5.6 流量因子（最佳方案：信号端换弹药，管线复用）
#   动机：2万根实证 K线毛优势≈1.2bps/笔 < 成本6~10bps —— 价格衍生信号到头了，
#   增量在交易所真实流量：主动买卖比(方向压力)/OI(仓位变化)/资金费率(拥挤度)
python scripts/24_fetch_flow.py                          # 拉取并对齐1m（缓存 data/flow/）
python backtests/optimize_strategy.py --bars 20000 --flow   # 流量闸门 flow_gate[0,1,1.5] 入寻优
python backtests/run_backtest.py --bars 5000 --flow         # 流量闸门回测
#   语义：momo=主动流同向确认；mr=逆向拥挤（卖压极端做多）。闸门 OOS 验证由门禁裁决

# 5.7 多周期研究（--tf 仅改变信号语义，撮合一律 1m 最细粒度）
#   持仓周期 max_hold_bars 已入校准网格 [5, 15, 45]（1m 下 = 5/15/45 分钟，时间止损）：
#   太短→往返费用(6~10bps)占比高；太长→敞口久、反转风险大。平衡点由 IS寻优+OOS验证 决定
python backtests/optimize_strategy.py --bars 5000            # 1m 信号 + 1m 撮合（默认，最细）
python backtests/test_v1_factors.py --bars 2000 --tf 15m     # 方向因子 IC（多空判断依据，15m 语义）
python backtests/optimize_strategy.py --bars 2000 --tf 15m   # 15m 语义校准（2000根15m = 3万根1m）
python backtests/run_backtest.py --bars 2000 --tf 15m        # 15m 回测（真实1m自动聚合，无合成）
# → reports/backtesting/optimize_report.json（IS最优参数 + OOS验证）

# v1「8因子」价值评估（IC统计 + v3/v4 同骨架A/B）：
python backtests/test_v1_factors.py --bars 3000      # → reports/backtesting/v1_factors_verdict.json

# 6. 可视化
python main.py dashboard  # Streamlit 控制台
```

---

## 4. 目录

```
configs/system.yaml        # 系统级配置（费率/数据根 data/catalog）
configs/params_live.json   # 实盘参数（校准门禁达标后由 optimize 写入）
data/catalog/              # Parquet K线编目（canonical data/bar，真实OKX 1m）
src/eth_hft/
  core/                    # fee_model / instrument / types / logger
  data/                    # okx_rest(双接口翻页) okx_ws(公共WS) catalog storage okx_adapter orderbook
  strategy/                # micro_scalper_bs.py = v2/v3/v4 全部策略逻辑（含因子Alpha）
  core/ data/ risk/ monitoring/ config/    # 成本/合约、数据(REST/WS/编目)、仓位、报告、配置 utils/
backtests/
  run_backtest.py          # backtesting.py 内核回测（--strategy v3/v4/v2，仅真实数据）
  optimize_strategy.py     # IS/OOS 校准寻优 → optimize_report.json（达标写 params_live.json）
  test_v1_factors.py       # v1 8因子 IC 评估
scripts/
  00_check_env.py          # 环境自检（dashboard 亦调用）
  10_fetch_candles.py      # 拉取/补齐 1m K线（--bars N --fill）
  22_signal_diagnosis.py   # 信号诊断（dashboard 亦调用）
app.py                     # Streamlit dashboard（python main.py dashboard）
main.py                    # CLI：check/instrument/backtest/catalog/dashboard
docs/  tests/  README.md
```

---

## 5. 回测可信度

- **玩具引擎缺陷已归档** `archive/legacy_20240831/backtest/engine.py:35` Bar循环 close必成交 5bar必平 → **虚增3~10倍**
- **现引擎** `backtests/run_backtest.py` 基于 [backtesting.py](https://github.com/kernc/backtesting.py)：事件驱动、Bar 收盘撮合、OKX 真实费率 maker 0.02% / taker 0.05% + 滑点与保证金约束
- **数据可信** 仅真实 OKX 1m K线（`load_real_or_exit`：无数据/数据不足直接退出，禁止合成）
- **样本外纪律** IS/OOS 70/30 划分；IS 寻优每组合 ≥8 笔才参选；OOS 收益>0 且 ≥5 笔且不劣于默认 → 才写 `configs/params_live.json`

---

## 6. 实盘就绪

- **行情**：历史/补数走 `data/okx_rest.py`（双接口接力，官方口径见 §2.5）；实时走 `data/okx_ws.py` 公共 WS（candle1m/books/trades，免登录）
- **交易**：OKX v5 REST 下单（签名/限速/模拟盘见官方文档 docs-v5）；合约规格 `core/instrument.py`（ETH-USDT-SWAP ctVal=0.1 ETH/张）
- **风控**：`risk/position_sizer.py` RiskBudget 反推仓位（杠杆为结果）+ `configs/params_live.json` 校准门禁
- **路径**：先 OKX 模拟盘（demo trading）纸面验证 → 小资金实盘；API 事实清单见 §2.5
