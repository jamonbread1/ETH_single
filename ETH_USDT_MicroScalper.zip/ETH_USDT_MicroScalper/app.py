"""
ETH MicroScalper - 系统控制台（backtesting.py 内核）
启动: streamlit run app.py  或  python main.py dashboard
布局 3.0：宽松分区 + 报告原生渲染（指标卡/权益曲线/明细表），引擎大图仅作附件下载
策略：v2 趋势 / v3 状态自适应（推荐）/ v4 因子Alpha，全部位于 strategy/micro_scalper_bs.py
"""
from __future__ import annotations
import sys
from pathlib import Path
# 确保UTF-8（修复Windows GBK乱码）
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))

import json
import pandas as pd
import streamlit as st

st.set_page_config(
    page_title="ETH MicroScalper",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded",
)

REPORT_DIR = Path("reports/backtesting")

# --- 全局样式：宽松间距 ---
st.markdown("""
<style>
    .block-container { padding-top: 1.6rem; padding-bottom: 3rem; max-width: 1400px; }
    .main-header { font-size: 26px; font-weight: 700; letter-spacing: .3px; }
    .sub-header { color: #8b8b8b; font-size: 13px; margin-bottom: 4px; }
    div[data-testid="stMetric"] { background: rgba(128,128,128,.07); border-radius: 10px; padding: 12px 16px; }
    div[data-testid="stHorizontalBlock"] { gap: .6rem; }
    .stTabs [data-baseweb="tab-list"] { gap: 14px; }
    .stTabs [data-baseweb="tab"] { padding: 10px 18px; font-size: 15px; }
</style>
""", unsafe_allow_html=True)


# --- 报告工具 ---
def list_reports() -> list[Path]:
    if not REPORT_DIR.exists():
        return []
    return sorted(REPORT_DIR.glob("*.html"), key=lambda p: p.stat().st_mtime, reverse=True)


@st.cache_data(ttl=20)
def load_report_json(html_path: str) -> dict:
    p = Path(html_path).with_suffix(".json")
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def render_report(html_path: Path, expanded: bool = False, scope: str = "rp"):
    """报告原生渲染：指标卡 + 权益曲线 + 交易明细 + 下载（引擎HTML作附件）"""
    data = load_report_json(str(html_path))
    s = data.get("summary", {})
    trades = data.get("trades", [])
    equity = data.get("equity", [])

    st.markdown(f"`{html_path.name}` ｜ {s.get('data_range', '')} ｜ {s.get('engine', '')} ｜ 佣金 {s.get('commission_per_side', '?')}/边")

    # 指标行
    wr = s.get("win_rate") or 0
    realized = s.get("realized_pnl") or 0
    c1, c2, c3, c4, c5, c6 = st.columns(6)
    c1.metric("交易笔数", f"{s.get('trades', 0)}")
    c2.metric("胜率", f"{wr * 100:.1f}%" if isinstance(wr, (int, float)) else "—")
    c3.metric("净收益 (U)", f"{realized:+.2f}")
    c4.metric("收益率", f"{s.get('return_pct', 0):+.2f}%")
    c5.metric("最大回撤", f"{s.get('max_drawdown_pct', 0):.2f}%")
    c6.metric("手续费 (U)", f"{(s.get('fees') or 0):.2f}")
    pr = s.get("params") or {}
    live = {k.replace("live.", ""): v for k, v in pr.items() if str(k).startswith("live.")}
    src = pr.get("source", "")
    if live or src:
        st.caption(f"参数来源: {src}" + (f" ｜ 校准参数: {live}" if live else ""))

    # 权益曲线
    if equity:
        eq = pd.DataFrame(equity)
        eq["t"] = pd.to_datetime(eq["t"])
        eq = eq.set_index("t")["e"]
        st.line_chart(eq, height=280)
    elif trades:
        cum = []
        run = 0.0
        for t in trades:
            run += t.get("pnl", 0)
            cum.append(run)
        st.area_chart(pd.DataFrame({"累计盈亏(U)": cum}), height=240)

    # 交易明细
    if trades:
        tdf = pd.DataFrame(trades)
        cols = [c for c in ("closed", "side", "size_eth", "entry", "exit", "pnl", "fee", "exit_reason", "hold_bars") if c in tdf.columns]
        tdf = tdf[cols]
        st.dataframe(tdf, height=min(420, 35 * (len(tdf) + 1) + 10), width="stretch")

    # 附件
    uid = f"{scope}_{html_path.stem.replace('.', '_')}"
    d1, d2 = st.columns(2)
    d1.download_button("⬇️ 下载引擎交互图 (HTML)", data=html_path.read_bytes(), file_name=html_path.name,
                       mime="text/html", width="stretch", key=f"dl_html_{uid}")
    jpath = html_path.with_suffix(".json")
    if jpath.exists():
        d2.download_button("⬇️ 下载明细数据 (JSON)", data=jpath.read_bytes(), file_name=jpath.name,
                           mime="application/json", width="stretch", key=f"dl_json_{uid}")

    with st.expander("📊 引擎交互式大图（若内嵌空白请下载后本地打开）", expanded=expanded):
        try:
            st.html(html_path.read_text(encoding="utf-8"))
        except Exception as e:
            st.error(f"内嵌失败: {e}")


# --- 侧边栏 ---
with st.sidebar:
    st.markdown("## 📈 MicroScalper")
    st.caption("ETH-USDT 永续 · 1m · 选择性趋势")
    st.divider()
    st.markdown("### 策略 v3 · 状态自适应")
    st.caption("方差比VR自动判 趋势/均值回归/震荡 · 震荡不交易 · ATR自适应止损")
    st.caption("仓位 = 风险预算 ÷ 止损距离")
    st.divider()
    risk_budget = st.slider("单笔风险预算 (U)", 0.05, 1.0, 0.20, 0.05,
                            help="写入 configs/system.yaml 后由回测读取；此处仅为展示")
    st.divider()
    if st.button("🔄 刷新", width="stretch"):
        st.rerun()
    st.caption("引擎 backtesting.py · 本地运行")
    st.caption("报告: reports/backtesting/")

# --- 页头 ---
st.markdown('<div class="main-header">📈 ETH-USDT Selective Trend Scalper</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-header">backtesting.py 逐bar撮合 · VR状态自适应 · 无未来函数 · 校准参数自动启用（configs/params_live.json）</div>', unsafe_allow_html=True)
st.divider()

tab_overview, tab_backtest, tab_catalog, tab_reports, tab_system = st.tabs(
    ["🏠 总览", "🧪 回测", "📚 数据", "📊 报告", "🔧 系统"]
)

# ========== 总览 ==========
with tab_overview:
    left, right = st.columns([2, 1], gap="large")
    with left:
        st.markdown("#### v3 状态自适应策略")
        st.markdown("""
**状态判别（方差比 VR，滚动240根估计）**
- VR > 1.1 → **趋势状态**：动量跟随（SMA差+长期趋势同向，2×ATR止损、1.5×ATR移动止盈）
- VR < 0.9 → **均值回归状态**：偏离60根均线超 1.8×ATR 时反向入场，目标=回归均线
- 中间 → **震荡**：不交易（省手续费，直接针对"高频送手续费"病根）

**通用风控**：冷却15根bar、ATR%活性下限、成本闸门、单笔风险恒定 0.2U
        """)
        st.markdown("""
**工作流（三步）**
1. 📚 **数据**：补齐真实 1m K线 —— `python scripts/10_fetch_candles.py --bars 20000 --fill`（进度条+分批入库）
2. 🧭 **校准**：`python backtests/optimize_strategy.py --bars 5000`（IS 3折稳健寻优 / OOS 30% 门禁 / 持仓周期入网格）
3. 🚀 **回测**：🧪 页按钮或 `python backtests/run_backtest.py --bars 5000`

> **回测一律以 1m 最细粒度撮合**；持仓周期 `max_hold_bars`（1m 下 5bar=5分钟）已纳入寻优：
> 太短 → 往返费用（6~10bps）占比过高；太长 → 敞口久、反转风险大。**平衡点由数据决定**。
""")
    with right:
        st.markdown("#### 最新回测")
        if Path("configs/params_live.json").exists():
            st.caption("🟢 使用校准参数（configs/params_live.json）")
        else:
            st.caption("⚪ 默认参数（尚未校准或校准未达标）")
        reps = list_reports()
        if reps:
            latest = reps[0]
            s = load_report_json(str(latest)).get("summary", {})
            st.metric("交易笔数", s.get("trades", "—"))
            st.metric("净收益 (U)", f"{(s.get('realized_pnl') or 0):+.2f}")
            st.caption(f"{latest.name}")
        else:
            st.caption("暂无报告，去 🧪 回测 页跑一次")

# ========== 回测 ==========
with tab_backtest:
    col_in, col_out = st.columns([1, 3], gap="large")

    with col_in:
        st.markdown("#### 参数")
        tf_sel = st.select_slider("K线周期", options=["1m", "3m", "5m", "15m"], value="1m",
                                  help="由真实1m数据聚合（无合成）。15m：单根波幅≈0.1~0.25%，更能覆盖往返成本")
        bars_limit = st.slider("K线数量（按所选周期计）", 100, 5000, 1000, 100,
                               help="15m 时 2000 根≈3万根1m数据；校准建议 ≥2000（OOS 只占30%）")
        run_id = st.text_input("运行ID（留空自动命名）", value="", placeholder="自动: bs_v2_时间戳")
        do_run = st.button("🚀 开始回测", type="primary", width="stretch")
        if st.button("🧭 校准参数（自动IS/OOS并启用）", width="stretch",
                     help=f"按上方K线数量自动 70/30 划分：IS 寻优 → OOS 验证 → "
                          f"达标自动写入 configs/params_live.json 并被后续回测采用"):
            import os
            import subprocess
            with st.spinner(f"校准 {bars_limit} 根真实数据（IS 3折稳健寻优 / OOS 30% 验证+全组合诊断）...约2-8分钟"):
                res = subprocess.run(
                    [sys.executable, "backtests/optimize_strategy.py", "--bars", str(bars_limit), "--tf", tf_sel],
                    capture_output=True, text=True, encoding="utf-8", errors="replace",
                    env={**os.environ, "PYTHONIOENCODING": "utf-8"})
            if res.returncode == 0:
                st.success("✅ 校准完成")
                try:
                    rep = json.loads(Path("reports/backtesting/optimize_report.json").read_text(encoding="utf-8"))
                    if rep.get("adopted"):
                        st.info("🎉 最优参数已通过 OOS 验证并自动启用，后续回测即用新参数", icon="✅")
                    else:
                        st.warning(f"参数未启用：{rep.get('adopt_reason', '')}", icon="⚠️")
                    with st.expander("校准详情（稳健冠军 / OOS对比与诊断 / 状态分布 / Top10）"):
                        st.json({k: rep.get(k) for k in ("is_best_params", "is_stats", "oos",
                                                         "oos_diagnostics", "oos_direction", "is_by_param",
                                                         "selection_method", "state_distribution",
                                                         "adopted", "adopt_reason")})
                except Exception as e:
                    st.caption(f"报告读取失败: {e}")
            else:
                st.error("❌ 校准失败（多为真实数据不足且无法拉取）")
                with st.expander("日志"):
                    st.text((res.stdout or "")[-1500:])
                    st.text((res.stderr or "")[-1000:])
        st.divider()
        st.caption("数据：本地编目优先，不足自动拉取 OKX（>300根自动翻页）")
        st.caption("佣金：按 maker 0.02%/边（system.yaml）")
        st.caption("撮合粒度：一律 1m 真实K线最细粒度；周期选择只改变信号/持仓的 bar 语义（5bar=5分钟@1m）")
        st.caption("每笔经济学：入场捕捉 ≥ capture_mult×往返成本(8.4bps)、MR盈亏比(sl/tp倍数)、momo环境闸门(ATR下限) 均入网格")

    with col_out:
        status = st.container()
        if do_run:
            with status:
                with st.spinner(f"回测 {bars_limit} 根 1m K线..."):
                    import os
                    import subprocess
                    rid = (run_id or "").strip() or f"bs_v2_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}"
                    result = subprocess.run(
                        [sys.executable, "backtests/run_backtest.py", "--bars", str(bars_limit),
                         "--tf", tf_sel, "--run-id", rid],
                        capture_output=True, text=True, encoding="utf-8", errors="replace",
                        env={**os.environ, "PYTHONIOENCODING": "utf-8"},
                    )
                    st.session_state["bt_code"] = result.returncode
                    st.session_state["bt_stdout"] = result.stdout
                    st.session_state["bt_stderr"] = result.stderr
                    if result.returncode == 0:
                        st.success(f"✅ 回测完成：{rid}")
                    else:
                        st.error(f"❌ 失败 code={result.returncode}")
                        with st.expander("日志"):
                            st.text((result.stdout or "")[-3000:])
                            st.text((result.stderr or "")[-2000:])

        reps = list_reports()
        if not reps:
            st.info("👈 设置参数并点击「开始回测」，结果将在这里原生展示", icon="👈")
        else:
            # 优先展示本次运行的报告
            rid_done = st.session_state.get("bt_run_id") if "bt_run_id" in st.session_state else None
            target = None
            if do_run and st.session_state.get("bt_code") == 0:
                rid = (run_id or "").strip() or None
                if rid:
                    cand = REPORT_DIR / f"{rid}.html"
                    if cand.exists():
                        target = cand
                        st.session_state["bt_run_id"] = rid
            if target is None:
                target = reps[0]
            render_report(target, expanded=(do_run and st.session_state.get("bt_code") == 0), scope="bt")
            if do_run and st.session_state.get("bt_code") == 0:
                with st.expander("控制台日志"):
                    st.text((st.session_state.get("bt_stdout") or "")[-3000:])

# ========== 数据 ==========
with tab_catalog:
    st.markdown("#### 📚 数据编目（仅真实数据）")
    from eth_hft.data.catalog import DataCatalog

    cat = DataCatalog("data/catalog")
    files = cat.list_bars()
    c_fetch, c_chart = st.columns([1, 2], gap="large")

    with c_fetch:
        st.markdown("##### ⬇️ 数据补齐")
        st.caption("OKX 公开接口，1m，>300 根自动翻页；补齐=与编目合并去重（保留已有历史）")
        fetch_bars = st.select_slider("补齐目标（根）", options=[500, 1000, 2000, 3000, 5000, 10000, 20000], value=1000,
                                      help="3000根≈2天；校准建议 ≥3000（OOS 只占30%）")
        fetch_proxy = st.text_input("代理（可选）", value="", placeholder="http://127.0.0.1:7890",
                                    help="国内网络直连 OKX 常见 SSL 失败，填本地代理端口；留空则直连")
        if st.button("⬆️ 补齐至 " + str(fetch_bars) + " 根", width="stretch", type="primary"):
            import os
            import subprocess
            cmd = [sys.executable, "scripts/10_fetch_candles.py", "--bars", str(fetch_bars), "--fill"]
            if fetch_proxy.strip():
                cmd += ["--proxy", fetch_proxy.strip()]
            with st.spinner(f"补齐至 {fetch_bars} 根..."):
                res = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace",
                                     env={**os.environ, "PYTHONIOENCODING": "utf-8"})
            if res.returncode == 0:
                st.success(f"✅ 补齐完成（目标 {fetch_bars} 根，增量合并）")
                st.rerun()
            else:
                st.error("❌ 拉取失败")
                with st.expander("排查日志"):
                    st.text((res.stdout or "")[-2000:])
                    st.text((res.stderr or "")[-1500:])
                st.caption("常见原因：网络无法直连 OKX → 填上方代理；或系统代理未开")
        st.divider()
        st.markdown("##### 🧭 信号诊断")
        st.caption("在真实数据上判断 趋势/均值回归/震荡，解释策略适配性")
        if st.button("🧭 运行诊断", width="stretch"):
            import subprocess
            res = subprocess.run([sys.executable, "scripts/22_signal_diagnosis.py"],
                                 capture_output=True, text=True, encoding="utf-8", errors="replace")
            st.code((res.stdout or res.stderr or "")[-2200:], language=None)
        st.divider()
        st.metric("编目文件", len(files))
        if files:
            if st.button("🗑️ 清空编目（重建）", help="拉取新数据前清空，防区间重复"):
                n = cat.clear_bars()
                st.toast(f"已清空 {n} 个文件")
                st.rerun()
            for f in files[:8]:
                st.text(f.name)

    with c_chart:
        if files:
            try:
                df = cat.read_bars_pandas()
                st.write(f"总 {len(df)} 行 ｜ {df['ts'].min()} → {df['ts'].max()}")
                st.line_chart(df.set_index("ts")["close"].tail(1500), height=320)
                st.dataframe(df.tail(20), width="stretch")
            except Exception as e:
                st.error(str(e))
        else:
            st.info("编目为空：点左侧「拉取并写入编目」，或命令行 `python scripts/10_fetch_candles.py --bars 3000`")

# ========== 报告 ==========
with tab_reports:
    st.markdown("#### 📊 历史报告")
    reps = list_reports()
    if not reps:
        st.info("暂无报告，先去 🧪 回测")
    else:
        opts = [f"{p.stem}  ({p.stat().st_mtime and pd.Timestamp.fromtimestamp(p.stat().st_mtime).strftime('%m-%d %H:%M')})" for p in reps]
        sel = st.selectbox("选择报告", opts, index=0)
        chosen = reps[opts.index(sel)]
        render_report(chosen, scope="rp")

# ========== 系统 ==========
with tab_system:
    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("#### 🔍 环境自检")
        if st.button("运行自检", width="stretch"):
            import subprocess
            res = subprocess.run([sys.executable, "scripts/00_check_env.py"], capture_output=True, text=True, encoding="utf-8", errors="replace")
            st.text((res.stdout or "")[-3000:])
        st.markdown("#### 💰 费率基准")
        try:
            from eth_hft.core.fee_model import FeeConfig, round_trip_fee
            cfg_fee = FeeConfig()
            st.markdown(
                f"- 双 Maker 往返 **{round_trip_fee(True, True, cfg_fee):.3%}**\n"
                f"- 一 Maker 一 Taker **{round_trip_fee(True, False, cfg_fee):.3%}**\n"
                f"- 双 Taker **{round_trip_fee(False, False, cfg_fee):.3%}**"
            )
        except Exception as e:
            st.caption(f"费率模块读取失败: {e}")
    with c2:
        st.markdown("#### ⚙️ configs/system.yaml")
        cfg_path = Path("configs/system.yaml")
        if cfg_path.exists():
            st.code(cfg_path.read_text(encoding="utf-8"), language="yaml")
        else:
            st.warning("configs/system.yaml 不存在")
        st.markdown("#### 📜 日志")
        log_files = list(Path("logs").glob("*.log")) if Path("logs").exists() else []
        if log_files:
            latest_log = max(log_files, key=lambda p: p.stat().st_mtime)
            if st.button("查看日志尾部"):
                st.text(latest_log.read_text(encoding="utf-8", errors="replace")[-4000:])
            st.caption(f"最新: {latest_log.name}")
        else:
            st.caption("暂无日志")

st.divider()
st.caption("backtesting.py 专业引擎 · 1m 真实数据最细粒度 · 策略 v2/v3/v4 · 持仓周期已入校准网格")
