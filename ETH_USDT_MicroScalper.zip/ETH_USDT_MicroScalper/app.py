"""
ETH MicroScalper - 系统控制台（Nautilus内核）
启动: streamlit run app.py  或  python main.py dashboard
设计: Tabs主导航 + 侧边栏全局设置 + 实时反馈，无乱码（UTF-8）
"""
from __future__ import annotations
import sys
from pathlib import Path
# 确保UTF-8（修复Windows GBK乱码）
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))

import streamlit as st
import pandas as pd
from eth_hft.core.fee_model import FeeConfig, round_trip_fee
from eth_hft.data.catalog import DataCatalog

st.set_page_config(
    page_title="ETH MicroScalper",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded",
)

# --- 全局样式 ---
st.markdown("""
<style>
    .main-header { font-size: 28px; font-weight: 700; color: #1a1a1a; margin-bottom: 5px; }
    .sub-header { color: #666; font-size: 14px; margin-bottom: 20px; }
    .metric-card { background: #f8f9fa; padding: 12px; border-radius: 8px; border-left: 4px solid #1890ff; }
    .stTabs [data-baseweb="tab-list"] { gap: 8px; }
    .stTabs [data-baseweb="tab"] { padding: 10px 20px; }
</style>
""", unsafe_allow_html=True)

# --- 侧边栏：全局设置 ---
with st.sidebar:
    st.markdown("## 📈 MicroScalper")
    st.caption("Selective · Nautilus · 家用PC")
    st.divider()
    st.markdown("### ⚙️ 全局设置")
    strategy_mode = st.selectbox("策略", ["v1 算法核心完整版", "v0 第一版基准"], help="v1=8因子+Regime+双Alpha，v0=基准")
    risk_budget = st.slider("单笔风险 (U)", 0.05, 1.0, 0.20, 0.05, help="RiskBudget/stop 反推仓位，杠杆为结果")
    st.caption(f"当前: {risk_budget:.2f} U/笔 ≈ {risk_budget*500:.0f}U名义 @0.04%止损")
    st.divider()
    st.markdown("### 📌 快捷入口")
    if st.button("🔄 刷新页面", width='stretch'):
        st.rerun()
    st.info("💡 提示：回测 300根约5-10秒，报告自动生成为HTML")
    st.divider()
    st.caption("本地运行 · 无docker/git")
    st.caption("日志: logs/  报告: reports/nautilus/*.html")

# --- 顶部状态栏（常显）---
cfg = FeeConfig()
colA, colB, colC, colD = st.columns(4)
with colA:
    st.metric("💰 双Maker往返", f"{round_trip_fee(True, True, cfg):.2%}", "0.04% 目标")
with colB:
    try:
        from eth_hft.data.okx_rest import fetch_instruments
        from eth_hft.core.instrument import InstrumentSpec
        spec = InstrumentSpec.from_okx_raw(fetch_instruments("SWAP", "ETH-USDT-SWAP")[0])
        st.metric("📦 最小下单", f"{spec.min_sz} 张", f"ctVal{spec.ct_val}")
    except Exception:
        st.metric("📦 最小下单", "0.01 张", "联网失败用默认")
with colC:
    st.metric("⚖️ 风险预算", f"{risk_budget:.2f} U", "逐仓隔离")
with colD:
    st.metric("🎯 策略", strategy_mode.split()[0], "可切换")

st.markdown('<div class="main-header">ETH-USDT Selective Micro Scalper</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-header">1m LAST · Nautilus L1撮合 · 成本过滤 1.5bps · 5~30笔/天 · 家用PC可跑</div>', unsafe_allow_html=True)

# --- 主导航 Tabs ---
tab_overview, tab_backtest, tab_catalog, tab_reports, tab_system = st.tabs(
    ["🏠 总览", "🧪 回测", "📚 数据", "📊 报告", "🔧 系统"]
)

# ========== 总览 ==========
with tab_overview:
    st.markdown("### 欢迎使用 MicroScalper 系统")
    col1, col2 = st.columns([2, 1])
    with col1:
        st.markdown("""
**定位：** 低频选择性 Scalper，非HFT。`1m Bar` 经 `Nautilus BacktestEngine` 真实撮合（L1排队、费率、滑点），非玩具 `close`必成交。

**数据链：** `OKX 1m 1-MINUTE-LAST-EXTERNAL` → `DataCatalog` `zstd` 落盘 → `BarType` 回放

**风控：** `RiskBudget/stop` 反推仓位，杠杆为结果；`KillSwitch` 熔断；`integrity.py` 防未来函数

**快速操作：**
- 新手：点 **🧪 回测** → 选 `v1` → 一键运行 → 查看HTML报告
- 对比：`v0` 为基准，`v1` 为8因子完整版，`backtests/compare_strategies.py` 同数据对比
        """)
        st.success("✅ 系统已就绪：Nautilus 1.231.0 已安装，编目可用")
    with col2:
        st.markdown("**当前编目**")
        cat = DataCatalog("data/catalog")
        files = cat.list_bars()
        st.metric("Parquet 文件", len(files))
        if files:
            df = None
            try:
                df = cat.read_bars_pandas()
                st.metric("总 Bar", len(df))
                if not df.empty and "close" in df.columns:
                    st.line_chart(df.set_index("ts")["close"].tail(100), height=180)
            except Exception as e:
                st.warning(f"读取失败: {e}")
        st.markdown("**最近操作**")
        import pathlib
        reports = list(pathlib.Path("reports/nautilus").glob("*.html"))
        if reports:
            latest = max(reports, key=lambda p: p.stat().st_mtime)
            st.caption(f"最新报告: {latest.name}")
            st.caption(f"大小: {latest.stat().st_size/1024:.1f} KB")
        else:
            st.caption("暂无报告，请先回测")

# ========== 回测 ==========
with tab_backtest:
    st.markdown("### 🧪 Nautilus 一键回测")
    colL, colR = st.columns([1, 2])
    with colL:
        st.markdown("**参数**")
        bars_limit = st.slider("K线数量", 100, 1000, 300, 50, help="300根≈5小时，1000根≈16小时")
        run_id = st.text_input("运行ID", value="selective_micro", help="报告文件名")
        strategy_choice = st.radio("策略", ["v1 完整版", "v0 基准"], horizontal=True)
        if st.button("🚀 开始回测", type="primary", width='stretch'):
            with st.spinner(f"拉取 {bars_limit}根 1m 并经 Nautilus撮合中...约5-10秒"):
                try:
                    import subprocess, pathlib
                    # 清理旧数据避免区间重叠（可选）
                    # 直接调用
                    result = subprocess.run(
                        [sys.executable, "backtests/run_backtest.py"],
                        capture_output=True, text=True, encoding="utf-8", errors="replace",
                        env={**__import__("os").environ, "PYTHONIOENCODING": "utf-8"}
                    )
                    # 保存输出到session
                    st.session_state["bt_stdout"] = result.stdout
                    st.session_state["bt_stderr"] = result.stderr
                    st.session_state["bt_code"] = result.returncode
                    # 生成报告的ID
                    st.session_state["bt_run_id"] = run_id
                    if result.returncode == 0:
                        st.success("✅ 回测完成")
                    else:
                        st.error(f"❌ 失败 code={result.returncode}")
                    st.rerun()
                except Exception as e:
                    st.error(f"异常: {e}")

        # 显示上次结果
        if "bt_stdout" in st.session_state:
            code = st.session_state.get("bt_code", -1)
            if code == 0:
                st.success("上次回测成功")
            else:
                st.error(f"上次失败 code={code}")
            with st.expander("📜 控制台日志", expanded=False):
                st.text(st.session_state.get("bt_stdout", "")[-4000:])
                if st.session_state.get("bt_stderr"):
                    st.text(st.session_state.get("bt_stderr")[-2000:])

    with colR:
        st.markdown("**报告预览**")
        import pathlib
        html_reports = list(pathlib.Path("reports/nautilus").glob("*.html"))
        if html_reports:
            # 默认显示最新的
            latest = max(html_reports, key=lambda p: p.stat().st_mtime)
            st.info(f"📄 最新: {latest.name} ({latest.stat().st_size/1024:.1f} KB)")
            # 读取并显示
            try:
                html_content = latest.read_text(encoding="utf-8")
                st.html(html_content)
            except Exception as e:
                st.error(f"读取失败: {e}")
                # 降级显示JSON
                json_path = latest.with_suffix(".json")
                if json_path.exists():
                    st.json(json_path.read_text(encoding="utf-8"))
        else:
            st.warning("暂无报告，请在左侧启动回测")
            st.caption("报告将自动生成为HTML（含Plotly图表+明细表+内嵌JSON），非单JSON不伦不类")

# ========== 数据 ==========
with tab_catalog:
    st.markdown("### 📚 数据编目")
    cat = DataCatalog("data/catalog")
    files = cat.list_bars()
    col1, col2 = st.columns([1,2])
    with col1:
        st.metric("文件数", len(files))
        if st.button("🔄 刷新编目"):
            st.rerun()
        st.write("**文件列表**")
        for f in files[:10]:
            st.text(str(f.relative_to(Path("."))) if f.is_relative_to(Path(".")) else str(f))
        if len(files) > 10:
            st.caption(f"...还有 {len(files)-10} 个")
    with col2:
        if files:
            try:
                df = cat.read_bars_pandas()
                st.write(f"总 {len(df)} 行 {df['ts'].min()} → {df['ts'].max()}")
                if "close" in df.columns:
                    st.line_chart(df.set_index("ts")["close"].tail(300), height=250)
                    st.dataframe(df.tail(20), width='stretch')
            except Exception as e:
                st.error(str(e))
        else:
            st.info("编目为空，请先回测或 `python scripts/10_fetch_candles.py`")

# ========== 报告 ==========
with tab_reports:
    st.markdown("### 📊 历史报告")
    import pathlib
    html_reports = sorted(pathlib.Path("reports/nautilus").glob("*.html"), key=lambda p: p.stat().st_mtime, reverse=True)
    json_reports = list(pathlib.Path("reports/nautilus").glob("*.json"))
    if not html_reports:
        st.warning("暂无HTML报告，请先在 🧪 回测 页运行")
    else:
        # 下拉选择
        options = [p.name for p in html_reports]
        selected = st.selectbox("选择报告", options, index=0)
        chosen = next(p for p in html_reports if p.name == selected)
        colA, colB = st.columns([3,1])
        with colA:
            st.caption(f"{chosen} · {chosen.stat().st_size/1024:.1f} KB · {pd.Timestamp.fromtimestamp(chosen.stat().st_mtime).strftime('%Y-%m-%d %H:%M:%S')}")
        with colB:
            # 下载按钮
            st.download_button("⬇️ 下载HTML", data=chosen.read_bytes(), file_name=chosen.name, mime="text/html")
        # 显示
        try:
            content = chosen.read_text(encoding="utf-8")
            st.html(content)
        except Exception as e:
            st.error(f"读取失败: {e}")
        # 同时展示JSON
        json_path = chosen.with_suffix(".json")
        if json_path.exists():
            with st.expander("📄 查看JSON数据"):
                st.json(json_path.read_text(encoding="utf-8"))

# ========== 系统 ==========
with tab_system:
    st.markdown("### 🔧 系统")
    col1, col2 = st.columns(2)
    with col1:
        st.markdown("**环境自检**")
        if st.button("🔍 运行自检"):
            try:
                import subprocess
                res = subprocess.run([sys.executable, "scripts/00_check_env.py"], capture_output=True, text=True, encoding="utf-8", errors="replace")
                st.text(res.stdout[-3000:])
                if res.returncode == 0:
                    st.success("自检通过")
                else:
                    st.error(res.stderr[-2000:])
            except Exception as e:
                st.error(str(e))
        st.markdown("**合约规格**")
        if st.button("📦 校验合约"):
            try:
                import subprocess
                res = subprocess.run([sys.executable, "scripts/12_check_instrument.py"], capture_output=True, text=True, encoding="utf-8", errors="replace")
                st.text(res.stdout[-3000:])
            except Exception as e:
                st.error(str(e))
    with col2:
        st.markdown("**配置**")
        cfg_path = Path("configs/system.yaml")
        if cfg_path.exists():
            st.code(cfg_path.read_text(encoding="utf-8"), language="yaml")
        else:
            st.warning("configs/system.yaml 不存在")
        st.markdown("**日志**")
        log_files = list(Path("logs").glob("*.log")) if Path("logs").exists() else []
        if log_files:
            latest_log = max(log_files, key=lambda p: p.stat().st_mtime)
            st.caption(f"最新: {latest_log.name}")
            if st.button("📄 查看日志尾部"):
                txt = latest_log.read_text(encoding="utf-8", errors="replace")[-4000:]
                st.text(txt)
        else:
            st.caption("暂无日志")

st.divider()
st.caption("✅ 已修复GBK乱码（UTF-8）· 直连Nautilus L1撮合 · 统一HTML报告 · 本地运行")
