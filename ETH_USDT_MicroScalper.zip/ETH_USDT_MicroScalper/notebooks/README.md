# notebooks

研究笔记请放在此目录，示例：`01_因子IC探索.ipynb`

建议用 `polars` + `pyarrow` 处理高频数据，避免 pandas OOM。
