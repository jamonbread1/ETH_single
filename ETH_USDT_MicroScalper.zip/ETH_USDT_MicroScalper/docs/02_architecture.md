# 02 架构设计 — Selective Micro Scalper

## 1. 定位纠偏

- **非 HFT**：不拼 10ms，持仓 1~5 分钟，速度差不再致命
- **优势转移**：更好过滤 + 更少错误 + 更好成本/极端行情处理

## 2. 分层（单向依赖，禁止循环）

```
接入层  OKX WS 长连接（bbo-tbt/trades/books）→ 本地聚合 5s/15s/1m（不轮询 REST）
   ↓
存储层  Parquet DataLake 按日分区（zstd 压缩）
   ↓
特征层  OHLCV(1m/3m/5m) → 成交量结构(MA/Z-score) → CVD(10s/30s/60s) → BBO(spread/OBI1)  [L2 留到 V3]
   ↓
评估层  IC / After-Cost IC / 分Regime IC（时序，非横截面）
   ↓
信号层  Rule + LightGBM 预测 E[R_{30s/60s/180s}]（V1 先规则，后统计模型）
   ↓
成本闸门 ExpectedNet = E[R] - Fee - Spread - Slippage - Buffer > 1.5bps
   ↓
状态机 NO_TRADE → SCANNING → ENTRY → MANAGING → FLAT（会“不交易”）
   ↓
风控层 KillSwitch + 账户级 RiskBudget + 逐仓强平距离 + 延迟守卫
   ↓
回测层 事件驱动（bar 完成才可用）+ Maker排队 FillModel + 延迟/滑点压力测试
   ↓
研究完整性层  Lookahead检测 + Train/Valid/OOS隔离 + Walk-Forward（见 07）
```

## 3. 数据流（家庭电脑友好）

```
OKX WS → 本地 Buffer(deque, 仅存5分钟) → Feature(每秒算一次) → Regime → Model → CostFilter → PositionSizing → Order(Post-only) → TP/SL/Timeout
```

- 单品种 ETH-USDT-SWAP，计算量极小，无需 GPU/Rust/服务器
- V0 仅需 REST candles 即可跑通全链路

## 4. 配置

- `configs/config.yaml` 全局（交易所/费率/路径）
- `configs/strategy.yaml` 策略（信号窗口/成本阈值/仓位 RiskBudget）
- `configs/risk.yaml` 风控（KillSwitch/日损）

经 `src/eth_hft/config/loader.py` pydantic 校验，不允许硬编码魔法数字。

## 5. 可观测

- `src/eth_hft/core/logger.py` 统一 loguru，关键路径（信号、seqId断档、KillSwitch、强平预警）必落日志
- 时间戳链路：exchange ts → local recv → decision → order send → ack → fill
