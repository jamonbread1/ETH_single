# 07 防未来函数与数据泄露硬规则（Research Integrity Layer）

> **NautilusTrader 等事件驱动引擎能防“框架层”穿越，但防不住你自己在特征/训练/调参中偷看未来。** 本层是裁判。

## 1. 时间因果律

```
Information(t) ⊆ History(≤t)
```

- bar 完成前不可用：10:00:00~10:00:59 的 bar，10:01:00 才可用
- 信号时间 < 决策时间，feature_end ≤ decision_time < label_start

## 2. 常见泄露坑（已在代码层拦截）

1. 用整根 K 线的 close/high/low 在形成前决策
2. 全量 `df.mean()/std()` 做标准化 → 必须 `shift(1).rolling(300).mean()`
3. 全量 percentile/volatility regime
4. 用未来数据定阈值/选参
5. 拿 OOS 反复调参（OOS 变验证集）→ 需冻结

## 3. 硬规则（代码级，非自觉）

- `src/eth_hft/research/integrity.py:20` `MarketSnapshot` frozen + `assert_feature_uses_past_only()`
- `src/eth_hft/features/microstructure.py:60` 所有滚动均 `shift(1)`，防止包含当前 bar 的 close
- `src/eth_hft/features/evaluator.py:25` `forward_return` 用 `shift(-h)` 做 label，特征与 label 严格分离
- `scripts/20_evaluate_factors.py` 采用 Walk-Forward：Train→Valid→OOS 滚动，scaler 仅在 Train fit

## 4. 四套回测（必做）

- A 理想价（无滑点/无 miss）→ 判断 alpha 是否存在
- B 现实手续费（+Maker/Taker）→ 能否覆盖成本
- C 执行压力（+latency/slippage/partial fill/maker fill 20~80% 灵敏度）→ 家庭网络能否活
- D 灾难测试（延迟×2/spread×3/slippage×3/波动×5）→ 会不会爆

## 5. 时间戳记录

每个订单记录：`exchange_ts, local_recv_ts, decision_ts, order_send_ts, ack_ts, fill_ts`，用于事后分析行情延迟/计算延迟/网络延迟。

## 6. 引用

- NautilusTrader 执行顺序：历史数据→交易所更新→撮合已有订单→策略回调→处理新订单（事件驱动，非整段计算）
- 但历史 L2 无法知队列位置，需 fill_model 假设并做敏感性分析
