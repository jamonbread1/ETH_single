# 01 里程碑计划（Milestone Plan）— 选择性低频 Scalping 版

> 根据补充对话：**降维到 5s~1m 信号、几十秒~十几分钟持仓、每天 5~30 笔、家用电脑 + 免费 API 优先**，不追求真 HFT。

## 阶段总览（省钱、渐进、可验证）

```
V0: 1m OHLCV                    → 问：仅 K 线是否有 after-cost edge？
V1: V0 + trades (5s/10s CVD)   → 问：加入成交量结构是否提升？
V2: V1 + BBO (spread/OBI1)     → 问：简单盘口是否值得？
V3: V2 + L2（按需，VIP4+）     → 问：深度是否真的优于 BBO？
```

每一步都要回答：**新增数据是否真的增加了 after-cost alpha**。若 V1 已稳定盈利，则不必为高频而上 L2。

## M0 框架与成本模型（第1周，已完成）

- 输入：OKX 官方 Maker 0.02%/Taker 0.05%、真实 instruments（ctVal 0.1/lotSz 0.01）
- 输出：`fee_model.py`、`instrument.py`、`position_sizer.py`、`configs/*.yaml`
- 验证：`tests/test_fee_model.py` 断言 0.04%/0.07%/0.10%；`scripts/12_校验合约规格.py` 显示 0.2U 风控在不同止损下的名义/杠杆/保证金可行性

## M1 数据层-免费优先（第1-2周）

- **只做免费**：REST `candles` + WS `trades` + `bbo-tbt`（10ms 最优价，无需 VIP）
- **不做**：`books-l2-tbt`（VIP4+）留到 V3
- 本地聚合：WS 长连接推送 → 本地 deque 缓冲 → 自行聚合成 5s/15s/1m
- 输出：`okx_rest.py`、`okx_ws.py`、`storage.py`（Parquet）
- 验证：断线重连+seqId 校验有日志；`scripts/10_采集K线.py` 可采 1m

## M2 特征与评估（第2-3周）

- 特征优先级（补充对话）：
  1. OHLCV（1m/3m/5m）
  2. 成交量结构（Volume MA/Z-score/突增）
  3. 订单流低配版（10s/30s/60s CVD）
  4. BBO（spread、OBI1 = (bidSz-askSz)/(bidSz+askSz)）
- 评估：IC / After-Cost IC / 分 Regime IC，`scripts/20_因子评估.py` 输出 `reports/factor_ic.csv`

## M3 策略与风控-选择性（第3-4周）

- 策略名：**ETH-USDT Micro Scalper**（非 HFT）
- 开仓闸门（需同时满足）：
  ```
  TrendScore>阈值 AND ShortMomentum>阈值 AND VolumeExpansion>阈值
  AND CVD>0 AND ExpectedMove> Cost+Buffer AND Regime!=Extreme AND Spread<Max
  ```
  执行：Post-only 挂单，挂不上就撤，不吃单
- 止盈：动态（ExpectedMove - 费用），失败则不交易 → 自然降到 5~30 笔/天
- 风控：KillSwitch（ATR/Spread/BookCollapse/Latency/连续亏损/日损）+ 账户级 RiskBudget
- 输出：`state_machine.py`、`dual_alpha.py`、`kill_switch.py`、`position_sizer.py`
- 验证：在历史极端行情触发 KillSwitch；逐仓强平距离与 OKX 一致

## M4 回测与报表（第4-5周）

- 事件驱动（1m 为主，tick 仅作 fill 校验），Maker 排队模型
- 指标：胜率、平均净收益、最大连续亏损、日损、回撤、profit factor
- 验证：不同手续费下净收益单调；Maker Fill<100%

## M5 小资金实盘（可选）

- OKX 模拟盘 `x-simulated-trading: 1`，验证信号→发单→成交→费用链路

## 关键约束

- 家用电脑：单品种、最近 5 分钟 tick buffer、deque/numpy/polars 足够，无需 GPU
- 每 1 秒更新状态，但**不是每秒下单**，靠过滤降频
- 每参数必须有来源（官方/实测分位数/配置）
