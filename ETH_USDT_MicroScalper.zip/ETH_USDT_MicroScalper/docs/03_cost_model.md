# 03 数据与成本模型依据（有据可循）

> 本文档所有数字都标明来源，拒绝拍脑子。

## 1. 手续费

- 来源：OKX 官方费率页 + 2026-08 多家费率汇总
- 普通用户永续：Maker 0.02% / Taker 0.05%
- 往返：双 Maker 0.04%，一 Maker 一 Taker 0.07%，双 Taker 0.10%
- 强平按 Taker 计费，资金费每 8h 结算，不计入单笔但计入持仓成本
- 代码：`src/eth_hft/core/fee_model.py` 的 `round_trip_fee()` 与文档一致，单元测试覆盖

## 2. 点差与滑点

- 不固定为常数，而是**从历史 bbo-tbt 实测分位数估计**
- 配置：`configs/strategy.yaml` 的 `cost.spread_bps` 默认取历史 `spread / mid * 1e4` 的中位数，安全垫取 75 分位数
- 滑点：Maker 假设 0.6bps（来自对话记录示例中 0.006%），Taker 取 1.5bps，均可在 `cost.slippage_*` 中覆盖并注明实测方法

## 3. 最低预期收益

公式（来自对话记录，已工程化）：

```
预期净收益 = 预期毛收益 - 手续费 - 点差 - 滑点 - 安全垫
阈值 = max(往返手续费 + 点差 + 滑点 + 安全垫, 6.4bps)  # 对话示例中 Maker→Maker 的 0.064%
仅当 预期净收益 > 1.5bps~3bps 才允许开仓
```

对应 `fee_model.expected_net_edge()`。

## 4. OKX 市场数据

- REST：`GET /api/v5/market/candles`（OHLC）、`/api/v5/market/trades`（逐笔）
- WS 公共频道：`books`（100ms 增量）、`bbo-tbt`（10ms 最优）、`trades`（逐笔）
- `books-l2-tbt` / `books50-l2-tbt` 10ms 深度，需 VIP4+，否则用 `books` 降级
- 2026-06 起 checksum 废弃，改为 `seqId/prevSeqId` 连续性校验（`orderbook.py` 已实现）

## 5. 参数来源清单

| 参数 | 默认值 | 来源 |
|---|---|---|
| taker_fee | 0.0005 | OKX 官方 |
| maker_fee | 0.0002 | OKX 官方 |
| spread_bps | 实测 | 历史 bbo 分位数 |
| slippage | 0.00006 | 对话示例 + 可配置 |
| kill_atr_multiple | 4.0 | 对话 KillSwitch 设计 |
| kill_spread_multiple | 3.0 | 同上 |
| max_latency_ms | 500 | 同上 |
| atr_window | 14 | 经典 ATR，非拍脑子 |

任何新增参数必须在此表追加一行。
