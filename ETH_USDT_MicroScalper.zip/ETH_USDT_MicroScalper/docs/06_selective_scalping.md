# 06 选择性低频 Scalping 设计（补充对话专项）

> 真正 HFT 拼速度，家用环境拼**选择性**。本项目定位：**Selective Micro Scalper**，不是 HFT。

## 1. 为什么降频

- 家庭网络无法与专业做市商拼 10ms
- 持仓 1~5 分钟时，10ms vs 100ms 差异不再致命
- 竞争优势转移到：更好过滤 + 更少错误 + 更好成本控制

## 2. 周期

- 数据：1m K线 + 本地聚合 5s/15s（WS 推，本地算，不轮询 REST）
- 特征窗口：过去 10s/30s/1m/3m/5m
- 预测：未来 30s/1m/3m/5m，选最稳定持仓周期
- 执行：每 1 秒更新一次状态，但仅在 `ExpectedNetEdge > 阈值` 才开仓 → 5~30 笔/天

## 3. 数据优先级（省钱版）

1. OHLCV（免费、稳、可回测）
2. 成交量结构（Volume Z-score/突增）
3. 订单流低配（trades 聚合出 CVD）
4. BBO（best bid/ask、spread、OBI1）
5. L2（V3 按需，若 V1 已盈利则不必上）

## 4. 绕过限频

- 误区：每秒 GET ticker/depth/candles → 撞限频
- 正确：WS 长连接订阅 → 本地持续接收 → 自己聚合成任意周期 → 零额外请求

## 5. 开仓与执行

- 多条件与：Trend + Momentum + Volume + CVD + Cost + Regime + Spread
- Post-only 限价，能挂则挂，挂不上撤单，不主动吃单（保费率）
- 止盈动态：`TP = max(费用+缓冲, ExpectedMove*k)`，预期 0.07% 时直接不交易

## 6. 账户级风控

- 30U 账户连续 10 笔各亏 0.5U = -16.7%，故不能只看单笔 1U
- 设计：每笔 RiskBudget 0.2U + 日损上限 2U + 连续亏损熔断
- 止损是策略失效点，不是固定 0.10%，极端行情直接 RiskScale=0

## 7. 技术栈（家用友好）

```
家庭电脑
  → OKX WS (1m/trades/bbo)
  → Local Buffer (deque 5分钟)
  → Feature (Momentum/CVD/Volume/Vol/Spread/OBI)
  → Cost Filter → Regime → Position Sizing → Order → TP/SL/Timeout
```

完全无需 VIP、GPU、Rust、服务器。
