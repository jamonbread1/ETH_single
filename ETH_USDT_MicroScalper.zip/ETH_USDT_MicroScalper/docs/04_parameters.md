# 04 参数与权重说明（防拍脑子清单）

## 1. 禁止

- 禁止在代码中写 `threshold = 0.05` 却无注释
- 禁止“经验权重 0.3/0.7” 无回测支撑

## 2. 允许的三种来源

1. **官方/公开**：如 OKX 费率、合约乘数
2. **数据驱动**：如 spread 取历史分位数，需在 `scripts/21_标定成本.py` 中可复现
3. **文献/经典**：如 ATR 14，需标注来源

## 3. 权重如何定

- V1 因子权重不手设，而是用 LightGBM 训练得到，或用 IC 加权
- 若必须手设，需在 `configs/strategy.yaml` 暴露并在 `docs/03_*.md` 解释

## 4. 变更流程（P1-6 WalkForward 定版，禁止手改字面量）

1. 改阈值 → 仅改 `scripts/21_calibrate_thresholds.py` 搜索空间，不直接改 `alpha.py`/`regime.py`/`strategy.py` 数值
2. 跑 `python scripts/21_calibrate_thresholds.py --catalog data/catalog --walk 3`
3. 产出 `configs/system.yaml:calibrated` + `reports/calibration/<date>/grid.json`
4. 跑 `python main.py backtest --bars 500` OOS 验证 trades 5~30/天 且 AfterCost PF>1.2
5. 报表对比通过 → PR 附 calibration 报告 → 再合入

禁止：`strategy.py:allow_momentum_fallback` 兜底动量默认关闭，`alpha.py:mr_m10_thr` 等仅作 fallback，需经 WalkForward 覆盖

冻结：官方费率 `maker 0.0002 taker 0.0005` 为 Final，`yaml` 只读镜像
