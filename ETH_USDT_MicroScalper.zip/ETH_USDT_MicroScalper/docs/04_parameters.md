# 04 参数与权重说明（防拍脑子清单）

## 1. 禁止

- 禁止在代码中写 `threshold = 0.05` 却无注释
- 禁止“经验权重 0.3/0.7” 无回测支撑

## 2. 允许的三种来源

1. **官方/公开**：如 OKX 费率、合约乘数
2. **数据驱动**：如 spread 取历史分位数，需在 `scripts/21_标定成本.py` 中可复现
3. **文献/经典**：如 ATR 14，需标注来源

## 3. 权重如何定

- V1 因子权重不手设，而是用 LightGBM 训练得到，或用 IC 加权
- 若必须手设，需在 `configs/strategy.yaml` 暴露并在 `docs/03_*.md` 解释

## 4. 变更流程（P1-6 WalkForward 定版，禁止手改字面量）

1. 改参数 → 仅改 `backtests/optimize_strategy.py` 网格（fast/slow/stop/trail/cooldown/z_in/mr）
2. 跑 `python backtests/optimize_strategy.py --bars 3000`（真实数据；IS 70% 寻优、每组合 ≥8 笔才参选）
3. 产出 `reports/backtesting/optimize_report.json`（含 OOS 验证与 state_distribution）
4. 启用门禁：OOS 收益>0 且 OOS ≥5 笔 且不劣于默认参数 → 自动写入 `configs/params_live.json`
5. `python backtests/run_backtest.py --bars 3000 --strategy v3` 复核报表通过 → 合入

禁止：`strategy.py:allow_momentum_fallback` 兜底动量默认关闭，`alpha.py:mr_m10_thr` 等仅作 fallback，需经 WalkForward 覆盖

冻结：官方费率 `maker 0.0002 taker 0.0005` 为 Final，`yaml` 只读镜像
