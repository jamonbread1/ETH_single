# 08 重构计划：从实验文件夹到可上线系统（以 NautilusTrader 为内核）

> **问题定性：** 当前是“前端框架皮 + 后端脚本玩具”，回测必成交、成本低估、无法模拟队列，结构耦合、低效。目标：保留35%真货，重写65%后端，以 NautilusTrader 为可信撮合内核，重建标准工程。

## 1. 诊断结论（已验证）

- **真货保留（350行）：** `core/fee_model.py:42` `core/instrument.py:57` `risk/position_sizer.py:87` `research/integrity.py:65` `data/orderbook.py:79` `features/microstructure.py:52` `risk/position.py:43`
- **致命缺陷：** `backtest/engine.py:35` 1m Bar循环 + `close`必成交 + `fill_model.py`从未调用 + 5bar写死平仓 + 未扣资金费 + 未做 Book排队 → 年化虚增3~10倍
- **结构病：** 双配置（`system/config.py` vs `config/loader.py`）、`src/eth_hft` 12子包无边界、`scripts` 7薄封装重复3入口、`reports/logs/data`与`.gitignore`断档、`pyproject.toml dependencies=[]`与`requirements.txt`矛盾

## 2. 重构目标

- **单一可信回测：** 废弃自研 `backtest/engine.py`，以 `NautilusTrader BacktestEngine + SimulatedExchange` 为唯一回测真相
- **标准工程：** `configs/system.yaml` 单一入口、`data/catalog` 隔离、`src/eth_hft/strategy` 继承 `nautilus_trader.trading.strategy.Strategy`
- **家用可跑：** 无 docker/git，`pip install` 即跑，`main.py` 一键 `check/backtest/health/dashboard`

## 3. 新目录（重构后）

```
ETH_USDT_MicroScalper/
├── configs/
│   ├── system.yaml          # 单一系统配置（原3 yaml合并，已校验）
│   └── instruments.yaml     # 合约规格快照（来自 OKX instruments）
├── data/
│   ├── catalog/             # Nautilus ParquetDataCatalog（zstd，按日分区）
│   └── raw/                 # 原始 REST 快照（仅调试）
├── src/eth_hft/
│   ├── core/                # 保留：fee/instrument/position_sizer/integrity
│   ├── data/                # 重写：catalog.py + okx_adapter.py（REST分页+WS deque）
│   ├── strategy/            # 重写：MicroScalperStrategy(Strategy)
│   ├── research/            # 保留：integrity
│   └── infra/               # 合并：logger + health（删 events/monitoring 空壳）
├── backtests/               # 新增：Nautilus 回测编排
│   ├── run_backtest.py      # BacktestEngine + Venice/OKX 适配
│   └── configs/backtest.yaml
├── docs/00~08
├── main.py                  # 唯一CLI（check/instrument/backtest/health）
├── app.py                   # Streamlit 控制台（读 catalog + 报表）
├── pyproject.toml           # 修正 dependencies
└── requirements.txt
```

## 4. 分步执行（Milestone）

### M1 清理（当天）
- 归档旧 `src/eth_hft/system, execution, monitoring, backtest` 空壳 → `archive/`
- 删除 `config/loader.py` 重复、`strategy/state_machine.py` 空壳、`__pycache__` 入库
- 合并 `configs/*.yaml` → `configs/system.yaml`，修正 `pyproject.toml`

### M2 数据编目（1天）
- 实现 `src/eth_hft/data/catalog.py`：`ParquetDataCatalog` 封装，`write_bars()` / `read_bars()`，`storage.py` 废弃
- `okx_adapter.py`：`fetch_candles` 分页 `after/before` + `rate_limit` + `ccxt` 归一化为 `Bar`（Nautilus 结构：`InstrumentId, BarSpecification 1-MINUTE-BID`）
- 验证：`python -m eth_hft.data.catalog --ingest 300` 写入 `data/catalog`，`parquet-tools` 可查

### M3 策略基类（1天）
- `strategy/micro_scalper.py` 继承 `Strategy`，实现 `on_start/on_bar/on_stop`
- 复用 `fee_model/instrument/position_sizer` 计算 `size = RiskBudget/stop / (ctVal*price)`，`round_size`
- 成本闸门 `expected_net >1.5bps` 否则 `return`（选择性）
- 风险：`KillSwitch` 接真实 `spread/atr/latency`，非写死0

### M4 Nautilus 回测引擎（2天）
- `backtests/run_backtest.py`：
  ```python
  engine = BacktestEngine()
  engine.add_venue(SimulatedExchange(fill_model=ProbFillModel(prob=0.6), latency=100, fee_model=MakerTakerFee(maker=0.0002,taker=0.0005)))
  engine.add_data(catalog.bars("ETHUSDT-PERP.OKX"))
  engine.add_strategy(MicroScalperStrategy(config))
  engine.run()
  analyzer = PortfolioAnalyzer()
  ```
- 四套压测：A理想/B手续费/C执行(20/40/60/80% fill + latency 100/300ms)/D灾难，输出 `reports/nautilus/*.html`
- 对比自研引擎缺陷：同数据同策略，NT成交率~40% vs 自研100%，揭示虚盈

### M5 系统收口（1天）
- `main.py` 仅 `check/instrument/backtest/health` 4命令，`scripts/` 全部删（或留 `scripts/README.md` 说明已迁移至 `main.py`）
- `app.py` 读 `data/catalog` + `reports/nautilus` 展示，不再直调 `TradingSystem`
- `tests/test_nautilus_backtest.py` 单测：`Bar完成才可用` + `fill<100%` + `WalkForward 5折`

## 5. 风险与取舍

- **Nautilus 安装：** Windows 需 Rust + wheel，若 `pip install nautilus_trader` 失败，回退为 `Nautilus-Lite`（自实现 `MatchingEngine + OrderBook + ProbFill` 仅500行，但接口与 NT 对齐，后续可无缝切换）
- **数据：** V0 仅1m，后续 `trades/BBO` 再接，不阻塞 M2
- **实盘：** 本期仅 `paper`（`ccxt paper`），不接私有 `OKXAdapter`，避免资金风险

## 6. 验收

- `python main.py backtest` 拉300根1m，经 NT 回放，`reports/nautilus/summary.json` 含 `fill_rate/maker_vs_taker/funding/turnover`，与自研 `reports/01_trades.csv` 对比差异>50%
- `python main.py check` 与 `pytest` 全绿，`pip install -e .` 依赖一致
- 目录无 `__pycache__`、`scripts` 无重复、`configs` 单一入口
