"""11 WS 实时订阅（演示）"""
import asyncio
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from eth_hft.data.okx_ws import OKXPublicWS
async def main():
    ws = OKXPublicWS("ETH-USDT-SWAP")
    await ws.subscribe(["books", "trades", "bbo-tbt"])
if __name__ == "__main__":
    asyncio.run(main())
