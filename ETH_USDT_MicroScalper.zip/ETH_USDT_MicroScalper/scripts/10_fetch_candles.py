"""
10 拉取真实 K线 → 数据编目（data/catalog）

用法：
  python scripts/10_fetch_candles.py                       # 默认拉 1000 根 1m
  python scripts/10_fetch_candles.py --bars 3000           # 自动翻页（OKX 单页上限300）
  python scripts/10_fetch_candles.py --proxy http://127.0.0.1:7890   # 走本地代理
  python scripts/10_fetch_candles.py --force               # 清空旧编目后重建

说明：
- 数据经 OKX REST 公开接口（无需鉴权），写入 data/catalog 供回测复现
- 编目已有数据时默认跳过写入（防重复区间），--force 清空重建
- 国内网络建议 --proxy 或先 export OKX_PROXY=http://127.0.0.1:7890
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from loguru import logger


def main() -> int:
    parser = argparse.ArgumentParser(description="拉取 OKX 真实K线并写入数据编目")
    parser.add_argument("--inst", default="ETH-USDT-SWAP", help="合约ID")
    parser.add_argument("--bar", default="1m", help="K线周期（1m/5m/15m/1H...）")
    parser.add_argument("--bars", type=int, default=1000, help="数量（>300 自动翻页）")
    parser.add_argument("--proxy", default=None, help="HTTP代理，如 http://127.0.0.1:7890")
    parser.add_argument("--force", action="store_true", help="清空旧编目后重建（防区间重复）")
    parser.add_argument("--fill", action="store_true", help="补齐模式：与编目合并去重（保留已有历史，只留最近 --bars 根）")
    args = parser.parse_args()

    if args.proxy:
        os.environ["OKX_PROXY"] = args.proxy
        logger.info(f"使用代理 {args.proxy}")
    elif os.environ.get("OKX_PROXY") or os.environ.get("HTTPS_PROXY"):
        logger.info(f"使用环境变量代理 {os.environ.get('OKX_PROXY') or os.environ.get('HTTPS_PROXY')}")

    from eth_hft.data.catalog import DataCatalog
    from eth_hft.data.okx_rest import fetch_candles

    cat = DataCatalog("data/catalog")
    existing = cat.list_bars()
    if existing and args.force:
        n = cat.clear_bars()
        logger.warning(f"已清空旧编目 {n} 个 bar 文件（--force）")
        existing = []

    logger.info(f"拉取 {args.inst} {args.bar} × {args.bars} 根"
                f"（>300 自动翻页；近期接口只保留 1m 最近约1天，更早自动切换 history-candles 回溯，"
                f"历史页较慢请耐心；下方有进度条）...")
    try:
        from tqdm import tqdm
        pbar = tqdm(total=args.bars, unit="根", desc="拉取K线", ascii=True, dynamic_ncols=True)
        last_mode = ["recent"]

        def on_progress(done: int, total: int, mode: str):
            pbar.update(done - pbar.n)
            if mode != last_mode[0]:
                logger.info(f"近期接口已见底，切换 history-candles 继续回溯（较慢，限速20次/2s）...")
                last_mode[0] = mode
            if pbar.n // 1000 != (pbar.n - pbar.unit // 2) // 1000:  # 每约1000根打一条日志
                logger.info(f"进度 {pbar.n}/{total} 根（{mode} 接口）")

        df = fetch_candles(args.inst, args.bar, args.bars, progress=on_progress)
        pbar.close()
    except Exception as e:
        logger.error(f"拉取失败：{e}")
        logger.error("排查建议：① 检查网络；② 国内网络加代理：--proxy http://127.0.0.1:7890"
                     " 或 export OKX_PROXY=...；③ 已自动尝试备用域 aws.okx.com")
        return 1

    if df.empty:
        logger.error("OKX 返回空数据（接口变化或参数错误）")
        return 1

    logger.info(f"拉取成功 {len(df)} 根：{df['ts'].min()} → {df['ts'].max()}")

    if existing and not args.force and not args.fill:
        logger.warning(f"编目已有 {len(existing)} 个文件，跳过写入（防区间重复）。"
                       f"补齐请加 --fill；重建请加 --force")
        return 0

    # 分批写库：每 CHUNK 根 merge 一次（读-并-写循环），避免一次性大块写入占用内存
    CHUNK = 2000
    df = df.sort_values("ts").reset_index(drop=True)  # 旧→新 分批
    total = 0
    with tqdm(total=len(df), unit="根", desc="写入编目", ascii=True, dynamic_ncols=True) as wbar:
        for i in range(0, len(df), CHUNK):
            part = df.iloc[i:i + CHUNK]
            total = cat.merge_bars(part, keep_last=args.bars)
            wbar.update(len(part))
            logger.info(f"已入库 {min(i + CHUNK, len(df))}/{len(df)} 根（编目现有 {total} 根）")

    logger.info(f"写入完成，编目现有 {total} 根（目标 {args.bars}）")
    logger.info("验证：python main.py catalog")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
