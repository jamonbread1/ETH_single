"""10 采集K线 -> Catalog"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from eth_hft.data.okx_rest import fetch_candles
from eth_hft.data.catalog import DataCatalog
cat = DataCatalog("data/catalog")
df = fetch_candles("ETH-USDT-SWAP", "1m", 100)
print(df.head())
path = cat.write_bars(df)
print(f"已写入 {path}")
