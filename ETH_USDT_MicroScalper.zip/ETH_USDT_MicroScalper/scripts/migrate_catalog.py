"""迁移：data/catalog/bars -> data/catalog/data/bar 归一（P2-8 一次性）

扫描 legacy bars/ 下 parquet，读取后经 DataCatalog.write_bars 重写至 canonical data/bar 分区，
校验行数一致后归档至 archive/catalog_bars_legacy/
"""
from __future__ import annotations

import shutil
from pathlib import Path

import pandas as pd
from loguru import logger


def main() -> None:
    src_root = Path("data/catalog/bars")
    if not src_root.exists():
        logger.info("无 legacy bars/，无需迁移")
        return
    files = list(src_root.rglob("*.parquet"))
    if not files:
        logger.info("legacy bars/ 为空")
        return
    logger.info(f"发现 {len(files)} 个 legacy 文件，开始迁移...")

    from eth_hft.data.catalog import DataCatalog

    cat = DataCatalog("data/catalog")
    total = 0
    for f in files:
        try:
            df = pd.read_parquet(f)
            # 兼容 ts 列名
            if "ts" not in df.columns and "ts_event" in df.columns:
                df["ts"] = pd.to_datetime(df["ts_event"], unit="ns", utc=True)
            cat.write_bars(df)
            total += len(df)
            logger.info(f"已迁移 {f} -> canonical {len(df)} rows")
        except Exception as e:
            logger.warning(f"迁移失败 {f}: {e}")

    # 归档
    archive = Path("archive/catalog_bars_legacy")
    archive.mkdir(parents=True, exist_ok=True)
    for f in files:
        dest = archive / f.relative_to(src_root)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(f), str(dest))
    try:
        if not any(src_root.rglob("*")):
            src_root.rmdir()
    except Exception:
        pass
    logger.info(f"迁移完成 {total} rows，legacy 已归档至 {archive}")


if __name__ == "__main__":
    main()
