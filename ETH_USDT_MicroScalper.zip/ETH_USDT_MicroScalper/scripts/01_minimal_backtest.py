"""DEPRECATED 2026-09-01: 请用 python main.py backtest（P2-10 脚本归一）"""
import warnings

warnings.warn("scripts/01_minimal_backtest 已废弃，请用 python main.py backtest", DeprecationWarning, stacklevel=2)
from pathlib import Path
import sys
import subprocess

print("调用 Nautilus 回测 backtests/run_backtest.py ...（已废弃，请用 main.py backtest）")
subprocess.run([sys.executable, str(Path(__file__).resolve().parents[1] / "backtests/run_backtest.py")])
