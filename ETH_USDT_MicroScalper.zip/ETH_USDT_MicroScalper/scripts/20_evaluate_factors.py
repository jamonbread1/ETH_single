"""20 因子评估（v1 FeatureEngine）"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from eth_hft.data.okx_rest import fetch_candles
from eth_hft.v1.features import FeatureEngine
from eth_hft.v1.data import MarketState, Bar
try:
    df = fetch_candles("ETH-USDT-SWAP", "1m", 300)
    ms = MarketState()
    for _, row in df.iterrows():
        ms.update_bar(Bar(ts=int(row["ts"].timestamp()*1000), open=row["open"], high=row["high"], low=row["low"], close=row["close"], volume=row["vol"]))
    eng = FeatureEngine()
    feats = eng.compute(ms)
    print("特征示例", list(feats.keys())[:8])
    print(f"特征数 {len(feats)}")
except Exception as e:
    import traceback; traceback.print_exc()
