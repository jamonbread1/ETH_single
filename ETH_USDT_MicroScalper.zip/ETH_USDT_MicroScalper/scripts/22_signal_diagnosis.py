"""
22 信号诊断：在真实数据上判断 1m 行情属于 趋势/均值回归/震荡，给出策略模式建议

原理：
- 自相关 AC(1..5)：显著为正→趋势，显著为负→均值回归
- 方差比 VR(k)：Var(k期收益)/(k·Var(1期收益))；>1 趋势，<1 均值回归，≈1 随机游走
显著性参考：|AC| > 2/√N 约为 95% 置信。

用法：
  python scripts/22_signal_diagnosis.py            # 诊断编目全部数据 + 最近500根
  python scripts/22_signal_diagnosis.py --bars 3000
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import numpy as np
import pandas as pd


def diagnose(close: pd.Series, label: str) -> dict:
    r = close.pct_change().dropna()
    n = len(r)
    sig = 2.0 / np.sqrt(n)
    acs = {f"AC({lag})": round(float(r.autocorr(lag)), 4) for lag in (1, 2, 3, 5, 10)}

    def vr(k: int) -> float:
        rk = close.diff(k).dropna()
        r1 = close.diff().dropna()
        v1 = float(r1.var())
        return float(rk.var()) / (k * v1) if v1 > 0 else float("nan")

    vrs = {f"VR({k})": round(vr(k), 3) for k in (15, 30, 60)}
    vr_mean = float(np.nanmean(list(vrs.values())))
    pos_ac = sum(1 for v in list(acs.values())[:3] if v > sig)
    neg_ac = sum(1 for v in list(acs.values())[:3] if v < -sig)
    if vr_mean > 1.05 or (pos_ac >= 2 and neg_ac == 0):
        verdict = "趋势状态 → v3 走 动量跟随 模式"
    elif vr_mean < 0.95 or (neg_ac >= 2 and pos_ac == 0):
        verdict = "均值回归状态 → v3 走 反向回归 模式"
    else:
        verdict = "震荡/随机游走 → v3 会选择 不交易（正确行为：省手续费）"
    # 与回测策略同款的滚动 VR（这才是实际控制交易的状态闸门）
    vr_roll = (c.diff(30).rolling(240).var() / (30 * c.diff().rolling(240).var())).replace([np.inf, -np.inf], np.nan).dropna()
    roll_info = ""
    if not vr_roll.empty:
        pct_t = float((vr_roll >= 1.1).mean() * 100)
        pct_m = float((vr_roll <= 0.9).mean() * 100)
        roll_info = (f"\n  滚动VR(240,30)（回测同款）: p10={vr_roll.quantile(.1):.2f} p50={vr_roll.quantile(.5):.2f}"
                     f" p90={vr_roll.quantile(.9):.2f} | 趋势区 {pct_t:.0f}% / 回归区 {pct_m:.0f}%"
                     f" / 震荡不交易 {100-pct_t-pct_m:.0f}%")

    print(f"\n[{label}] 样本收益 {n} 条（显著性阈值 ±{sig:.4f}）")
    print("  自相关:", acs)
    print("  方差比:", vrs, f"均值={vr_mean:.3f}" + roll_info)
    print(f"  ⇒ {verdict}")
    return {"label": label, "acs": acs, "vrs": vrs, "vr_mean": round(vr_mean, 3),
            "vr_roll_pct_trend": round(pct_t, 1) if roll_info else None,
            "vr_roll_pct_mr": round(pct_m, 1) if roll_info else None,
            "verdict": verdict}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bars", type=int, default=0, help="仅用最近 N 根（0=全部）")
    args = parser.parse_args()

    from eth_hft.data.catalog import DataCatalog

    cat = DataCatalog("data/catalog")
    df = cat.read_bars_pandas()
    if df is None or len(df) < 200:
        print(f"真实数据不足（{0 if df is None else len(df)}/200）。"
              f"请先拉取：python scripts/10_fetch_candles.py --bars 1000 --fill")
        return 1
    if args.bars:
        df = df.iloc[-args.bars:]
    print(f"真实数据 {len(df)} 根：{df['ts'].min()} → {df['ts'].max()}")
    diagnose(df["close"].reset_index(drop=True), "全部样本")
    if len(df) >= 800:
        diagnose(df["close"].iloc[-500:].reset_index(drop=True), "最近500根")
    print("\n注：状态会随行情切换，v3 的滚动 VR 会在回测中逐段自动识别；"
          "本诊断给出的是样本整体倾向。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
