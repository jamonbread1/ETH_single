"""23 校准报告摘要打印：把 optimize_report.json 的决策要点压成一屏文本

用法：python scripts/23_report_digest.py [报告路径，默认 reports/backtesting/optimize_report.json]
跑完把整段输出贴给助手即可（附件进不了沙盒时用这个）。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

# 只打印有信息量的维度（单值维度略过）
KEY_DIMS = ("side_mode", "capture_mult", "vr_lo", "vr_hi", "max_hold_bars",
            "mr_sl_mult", "mr_tp_mult", "atr_floor_bps", "z_in", "cooldown_bars")


def main() -> int:
    path = Path(sys.argv[1] if len(sys.argv) > 1 else "reports/backtesting/optimize_report.json")
    if not path.exists():
        print(f"报告不存在: {path}")
        return 1
    r = json.loads(path.read_text(encoding="utf-8"))

    print(f"== 数据: {r.get('bars')} 根 | {r.get('data_range', '')} | tf={r.get('timeframe', '1m')}")
    print(f"== 启用判定: {'✅已启用' if r.get('adopted') else '❌未启用'} | {r.get('adopt_reason', '')}")
    print(f"\n== IS 冠军参数: {r.get('is_best_params')}")
    st = r.get("is_stats") or {}
    print(f"   IS: {st.get('trades')}笔 胜率{st.get('win_rate_pct')}% 收益{st.get('return_pct')}% PF={st.get('profit_factor')}")

    print("\n== OOS 对比:")
    for k, v in (r.get("oos") or {}).items():
        if isinstance(v, dict) and "trades" in v:
            print(f"   {k}: {v.get('trades')}笔 胜率{v.get('win_rate_pct')}% 收益{v.get('return_pct')}% "
                  f"费{v.get('fees')} PF={v.get('profit_factor')}")

    d = r.get("oos_diagnostics") or {}
    print(f"\n== OOS 诊断: {d.get('positive_combos')}/{d.get('total_combos')} 组合为正 "
          f"| p10/p50/p90 = {d.get('return_p10')}/{d.get('return_p50')}/{d.get('return_p90')}%")

    bp = d.get("by_param") or {}
    if bp:
        print("\n== 按参数维度分解（OOS 全组合收益，pos_pct=该档正收益占比）:")
        for dim in KEY_DIMS:
            if dim in bp:
                items = " | ".join(f"{k}:均值{v.get('mean')}% 正{v.get('pos_pct')}%" for k, v in bp[dim].items())
                print(f"   {dim:14s} {items}")
        ib = r.get("is_by_param") or {}
        if ib:
            print("\n== IS 稳健分关键维度:")
            for dim in KEY_DIMS:
                if dim in ib:
                    items = " | ".join(f"{k}:{v}" for k, v in ib[dim].items())
                    print(f"   {dim:14s} {items}")

    od = r.get("oos_direction") or {}
    if od:
        print("\n== OOS 方向归因（毛利=哪边贡献）:")
        for tag, sides in od.items():
            lo = (sides or {}).get("long") or {}
            sh = (sides or {}).get("short") or {}
            print(f"   [{tag}] 多: {lo.get('trades')}笔 毛利{lo.get('gross_usdt')}U 胜率{lo.get('win_rate')}%"
                  f" | 空: {sh.get('trades')}笔 毛利{sh.get('gross_usdt')}U 胜率{sh.get('win_rate')}%")

    ce = r.get("champion_economics") or {}
    if ce:
        print(f"\n== 冠军每笔经济学: {ce.get('trades')}笔 毛利{ce.get('gross_usdt')}U "
              f"- 费用{ce.get('fees_usdt')}U = 净{ce.get('net_usdt')}U "
              f"(费用/毛利={ce.get('cost_to_gross_ratio')}x)")
    ms = r.get("maker_scenarios") or {}
    if ms:
        print("== maker 执行情景（挂单0.02%/边；排队未建模，偏乐观，须模拟盘验证）:")
        for k, v in ms.items():
            print(f"   {k}: {v.get('trades')}笔 收益{v.get('return_pct')}% 费{v.get('fees')} PF={v.get('profit_factor')}")

    print("\n== IS top10（稳健分=折间中位数净收益%）:")
    for t in (r.get("is_top10") or [])[:10]:
        print(f"   {t.get('score_median'):>8}  {t.get('params')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
