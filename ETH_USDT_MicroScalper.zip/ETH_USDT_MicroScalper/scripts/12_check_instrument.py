"""12 校验合约规格"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from eth_hft.data.okx_rest import fetch_instruments
from eth_hft.core.instrument import InstrumentSpec
from eth_hft.risk.position_sizer import calc_position
raw = fetch_instruments("SWAP", "ETH-USDT-SWAP")
spec = InstrumentSpec.from_okx_raw(raw[0])
print(f"规格 lotSz={spec.lot_sz} minSz={spec.min_sz} ctVal={spec.ct_val}")
for bps in [6,10,30,50]:
    r = calc_position(price=2444.48, stop_pct=bps/1e4, risk_budget_usdt=0.20, spec=spec, equity_usdt=50)
    print(f"止损{bps}bps -> {r.notional_usdt:.1f}U {r.size_contracts}张 保证金{r.margin_needed:.2f}U 可行={r.feasible}")
