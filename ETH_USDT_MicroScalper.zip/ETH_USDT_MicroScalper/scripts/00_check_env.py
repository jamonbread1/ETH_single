"""00 环境自检（直连核心）"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from eth_hft.core.fee_model import FeeConfig, round_trip_fee
from eth_hft.core.instrument import InstrumentSpec
from eth_hft.data.okx_rest import fetch_instruments

cfg = FeeConfig()
print(f"双Maker往返 {round_trip_fee(True, True, cfg):.4%} (预期 0.04%)")
print(f"一Maker一Taker {round_trip_fee(True, False, cfg):.4%} (预期 0.07%)")
print(f"双Taker {round_trip_fee(False, False, cfg):.4%} (预期 0.10%)")
assert abs(round_trip_fee(True, True, cfg) - 0.0004) < 1e-9
try:
    raw = fetch_instruments("SWAP", "ETH-USDT-SWAP")
    spec = InstrumentSpec.from_okx_raw(raw[0])
    print(f"合约 {spec.inst_id} ctVal={spec.ct_val} lotSz={spec.lot_sz} (OKX实盘)")
except Exception as e:
    print(f"合约获取跳过（网络波动）: {e}")
    from eth_hft.core.instrument import DEFAULT_ETH_SWAP
    spec = DEFAULT_ETH_SWAP
    print(f"使用本地默认合约 {spec.inst_id} ctVal={spec.ct_val} lotSz={spec.lot_sz}")
print("自检通过")
