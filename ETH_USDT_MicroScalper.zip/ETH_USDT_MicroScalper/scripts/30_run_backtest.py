"""DEPRECATED 2026-09-01: 请用 python main.py backtest（P2-10 脚本归一）"""
import warnings

warnings.warn("scripts/30_run_backtest 已废弃，请用 python main.py backtest", DeprecationWarning, stacklevel=2)
import subprocess
import sys
from pathlib import Path

print("请用 python main.py backtest  或  python backtests/run_backtest.py（已废弃）")
subprocess.run([sys.executable, str(Path(__file__).resolve().parents[1] / "backtests/run_backtest.py")])
