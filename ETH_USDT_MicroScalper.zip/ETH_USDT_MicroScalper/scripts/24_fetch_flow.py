"""24 拉取流量数据（Rubik 主动买卖比 / OI / 资金费率）→ data/flow/flow_1m.parquet

按编目 K 线的时间窗口拉取并对齐到 1m 索引（前向填充），供 --flow 策略闸门使用。
粒度自动选择：窗口 ≤2 天用 5m，否则 1H（官方限制：5m 仅回溯2天、1H 30天、1D 180天）。

用法：
  python scripts/24_fetch_flow.py                # 按编目窗口拉取并缓存
  python scripts/24_fetch_flow.py --refresh      # 强制重拉
  python scripts/24_fetch_flow.py --proxy http://127.0.0.1:7890
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from loguru import logger


def main() -> int:
    parser = argparse.ArgumentParser(description="拉取 OKX 流量数据并对齐 1m")
    parser.add_argument("--inst", default="ETH-USDT-SWAP")
    parser.add_argument("--refresh", action="store_true", help="忽略缓存强制重拉")
    parser.add_argument("--proxy", default=None, help="HTTP代理")
    args = parser.parse_args()

    if args.proxy:
        os.environ["OKX_PROXY"] = args.proxy
        logger.info(f"使用代理 {args.proxy}")

    from eth_hft.data.catalog import DataCatalog
    from eth_hft.data.flow import load_or_fetch_flow

    cat = DataCatalog("data/catalog")
    df = cat.read_bars_pandas()
    if df is None or df.empty:
        logger.error("编目为空：先跑 python scripts/10_fetch_candles.py --bars 20000 --fill")
        return 1
    idx = pd.DatetimeIndex(pd.to_datetime(df["ts"], utc=True).dt.tz_convert("UTC").dt.tz_localize(None))
    logger.info(f"编目窗口 {len(idx)} 根 1m：{idx.min()} -> {idx.max()}")

    f = load_or_fetch_flow(idx, inst_id=args.inst, refresh=args.refresh)
    tz = f["taker_z"]
    print("\n===== 流量数据摘要 =====")
    print(f"行数 {len(f)} | taker 覆盖 {f['coverage_pct']}%")
    print(f"taker_z: p10={tz.quantile(0.1):.2f} p50={tz.quantile(0.5):.2f} p90={tz.quantile(0.9):.2f}")
    if f["funding_rate"].notna().any():
        print(f"funding: 均值 {f['funding_rate'].mean():.5f} | 最新 {f['funding_rate'].dropna().iloc[-1]:.5f}")
    if f["oi"].notna().any():
        print(f"OI(币): 最新 {f['oi'].dropna().iloc[-1]:,.0f}")
    print("\n用法：python backtests/optimize_strategy.py --bars 20000 --flow")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
