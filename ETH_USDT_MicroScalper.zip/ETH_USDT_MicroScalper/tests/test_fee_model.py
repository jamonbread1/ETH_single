import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/"src"))
from eth_hft.core.fee_model import FeeConfig, round_trip_fee, passes_cost_filter

def test_round_trip():
    cfg=FeeConfig()
    assert abs(round_trip_fee(True, True, cfg)-0.0004)<1e-9
    assert abs(round_trip_fee(True, False, cfg)-0.0007)<1e-9
    assert abs(round_trip_fee(False, False, cfg)-0.001)<1e-9

def test_filter():
    cfg=FeeConfig()
    assert passes_cost_filter(0.001, True, True, cfg) == True
    assert passes_cost_filter(0.0005, True, True, cfg) == False

if __name__=="__main__":
    test_round_trip()
    test_filter()
    print("ok")
