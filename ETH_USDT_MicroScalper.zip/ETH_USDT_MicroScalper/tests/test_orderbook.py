import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/"src"))
from eth_hft.data.orderbook import OrderBook

def test_obi():
    ob=OrderBook()
    ob.apply_snapshot([["3000","10"],["2999","5"]], [["3001","4"],["3002","2"]], seq_id=1)
    assert ob.obi(1) is not None
    assert ob.spread_bps() is not None
    print("obi", ob.obi(), "spread", ob.spread_bps())

if __name__=="__main__":
    test_obi()
    print("ok")
