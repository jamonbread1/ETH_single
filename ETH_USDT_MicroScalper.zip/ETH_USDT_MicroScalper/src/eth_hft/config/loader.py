"""SSOT loader: 唯一解析 configs/system.yaml -> CostConfig/RiskConfig/ExecutionConfig

P0-4 统一配置：所有模块禁止直接 yaml.safe_load("strategy.yaml"/"risk.yaml")，必须经此 loader。
若 strategy.yaml/risk.yaml 仍存在则告警/抛错，account.equity 仅顶层一处。
"""
from __future__ import annotations

import warnings
from pathlib import Path
from typing import Any

import yaml

_SYSTEM_YAML = Path("configs/system.yaml")


def _load_raw(path: str | Path = _SYSTEM_YAML) -> dict[str, Any]:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"system.yaml 不存在: {p.resolve()}")
    # 强校验：三源抢占告警
    for legacy in ["configs/strategy.yaml", "configs/risk.yaml", "configs/config.example.yaml"]:
        lp = Path(legacy)
        if lp.exists():
            # 允许存在但打废弃标记，若内容非空且被其他代码加载则告警
            try:
                txt = lp.read_text(encoding="utf-8")
                if "DEPRECATED" not in txt:
                    warnings.warn(f"{legacy} 已废弃，仅 {path} 生效，请删除或归档", DeprecationWarning, stacklevel=3)
            except Exception:
                pass
    data: dict[str, Any] = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    # 强校验：risk.account 重复定义禁止（system.yaml:58-60 旧缺陷）
    if "risk" in data and isinstance(data["risk"], dict) and "account" in data["risk"]:
        raise ValueError("system.yaml: risk.account 重复定义，请仅保留顶层 account.equity_usdt（P0-4 已修复）")
    return data


def load_system_config(path: str | Path = _SYSTEM_YAML) -> dict[str, Any]:
    """加载 system.yaml 原始字典"""
    return _load_raw(path)


def build_cost_engine(path: str | Path = _SYSTEM_YAML):  # type: ignore
    from eth_hft.v1.cost import CostEngine

    raw = _load_raw(path)
    fees = raw.get("fees", {})
    cost = raw.get("cost", {})
    return CostEngine(
        maker_fee=float(fees.get("maker", 0.0002)),
        taker_fee=float(fees.get("taker", 0.0005)),
        spread_cost=float(cost.get("spread_bps", 0.8)) / 1e4,
        slippage_maker=float(cost.get("slippage_maker_bps", 0.6)) / 1e4,
        slippage_taker=float(cost.get("slippage_taker_bps", 1.5)) / 1e4,
        safety_buffer=float(cost.get("safety_buffer_bps", 1.0)) / 1e4,
        min_net_edge=float(cost.get("min_edge_bps", 1.5)) / 1e4,
    )


def build_risk_engine(path: str | Path = _SYSTEM_YAML):  # type: ignore
    from eth_hft.v1.risk import RiskEngine, RiskConfig

    raw = _load_raw(path)
    pos = raw.get("position", {})
    risk_raw = raw.get("risk", {})
    ks = risk_raw.get("kill_switch", {})
    stop = risk_raw.get("stop", {})
    cfg = RiskConfig(
        risk_budget_usdt=float(pos.get("risk_budget_usdt", 0.20)),
        max_leverage=float(pos.get("max_leverage", 100)),
        min_margin_usdt=float(pos.get("min_margin_usdt", 0.30)),
        risk_scale_normal=float(pos.get("risk_scale_normal", 1.0)),
        risk_scale_high_vol=float(pos.get("risk_scale_high_vol", 0.5)),
        risk_scale_extreme=float(pos.get("risk_scale_extreme", 0.0)),
        max_sl_pct=float(stop.get("fixed_stop_bps", 10)) / 1e4 * 5,  # 0.5% 兜底（configs 10bps*5）
        daily_loss_limit_usdt=float(ks.get("daily_loss_limit_usdt", 2.0)),
    )
    return RiskEngine(config=cfg)


def build_execution_engine(path: str | Path = _SYSTEM_YAML, cost_engine=None, risk_engine=None):  # type: ignore
    from eth_hft.v1.execution import ExecutionEngine, ExecutionConfig

    raw = _load_raw(path)
    exec_raw = raw.get("execution", {})
    cfg = ExecutionConfig(
        post_only_default=bool(exec_raw.get("post_only_default", True)),
        marketable_edge_thr_bps=float(exec_raw.get("marketable_edge_thr_bps", 5.0)) if exec_raw.get("marketable_edge_thr_bps") is not None else None,  # type: ignore
        marketable_edge_thr=float(exec_raw.get("marketable_edge_thr_bps", 5.0)) / 1e4 if exec_raw.get("marketable_edge_thr_bps") is not None else 0.0005,
        velocity_thr=float(exec_raw.get("velocity_thr", 0.0015)),
        allow_marketable=bool(exec_raw.get("allow_marketable", True)),
        maker_fill_probs=tuple(exec_raw.get("maker_fill_probs", [0.30, 0.50, 0.70, 0.90])),  # type: ignore
        cancel_replace_after_s=float(exec_raw.get("cancel_replace_after_s", 5.0)),
        cancel_replace_price_dev_bps=float(exec_raw.get("cancel_replace_price_dev_bps", 2.0)),
    )
    return ExecutionEngine(config=cfg, cost_engine=cost_engine, risk_engine=risk_engine)


__all__ = ["load_system_config", "build_cost_engine", "build_risk_engine", "build_execution_engine"]
