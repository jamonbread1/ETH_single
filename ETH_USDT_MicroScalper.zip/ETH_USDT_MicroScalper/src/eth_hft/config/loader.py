"""SSOT loader：唯一解析 configs/system.yaml（2026-09 精简：仅配置加载，引擎构建随死代码移除）"""
from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

_SYSTEM_YAML = Path("configs/system.yaml")


def load_system_config(path: str | Path = _SYSTEM_YAML) -> dict[str, Any]:
    """加载 system.yaml 原始字典（唯一配置入口）"""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"system.yaml 不存在: {p.resolve()}")
    data: dict[str, Any] = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    if "risk" in data and isinstance(data["risk"], dict) and "account" in data["risk"]:
        raise ValueError("system.yaml: risk.account 重复定义，请仅保留顶层 account（P0-4）")
    return data


__all__ = ["load_system_config"]
