"""config package: SSOT loader"""
from .loader import load_system_config

__all__ = ["load_system_config"]
