"""研究完整性层：防未来函数与数据泄露硬规则
依据：安全性强调.txt 中 25 条建议的工程化
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List
import pandas as pd

class LookaheadError(RuntimeError):
    """未来函数异常：特征试图访问未来数据"""
    pass

@dataclass(frozen=True)
class MarketSnapshot:
    """市场快照（冻结，防止篡改未来）
    仅包含 ≤ decision_time 的数据
    """
    timestamp: pd.Timestamp  # 决策时刻
    bar_close_time: pd.Timestamp  # 最新已完成 bar 的 close_time
    features: dict = field(default_factory=dict)

    def __post_init__(self):
        if self.bar_close_time > self.timestamp:
            raise LookaheadError(f"bar_close_time {self.bar_close_time} > timestamp {self.timestamp} 未来数据泄露")

def assert_feature_uses_past_only(feature_time: pd.Timestamp, decision_time: pd.Timestamp):
    """特征时间必须 ≤ 决策时间"""
    if feature_time > decision_time:
        raise LookaheadError(f"feature_time {feature_time} > decision_time {decision_time}")

def check_no_future_in_rolling(df: pd.DataFrame, feature_col: str, timestamp_col: str = "ts"):
    """静态检查：滚动特征未使用未来（如未 shift）
    简化检查：特征的计算窗口不应包含当前行未来
    """
    # 工程建议：所有 rolling 必须 shift(1)，此函数可在单测中调用
    if feature_col not in df.columns:
        return True
    # 若特征在 timestamp 等于当前 bar 的 close_time 时已可用，说明可能泄露
    # 具体由 feature 实现保证 shift(1)
    return True

@dataclass
class WalkForwardSplitter:
    """Walk-Forward 切分器：Train/Valid/OOS 滚动，防调参污染"""
    n_splits: int = 5
    train_size: int = 1000
    valid_size: int = 200
    oos_size: int = 200

    def split(self, n: int) -> List[dict]:
        splits = []
        start = 0
        for _ in range(self.n_splits):
            train_end = start + self.train_size
            valid_end = train_end + self.valid_size
            oos_end = valid_end + self.oos_size
            if oos_end > n:
                break
            splits.append({"train": (start, train_end), "valid": (train_end, valid_end), "oos": (valid_end, oos_end)})
            start += self.oos_size  # 滚动
        return splits

def fit_scaler_only_on_train(train: pd.DataFrame, valid: pd.DataFrame, oos: pd.DataFrame, cols: List[str]):
    """仅在 train 上 fit scaler，valid/oos 仅 transform，防止泄露"""
    from sklearn.preprocessing import StandardScaler
    scaler = StandardScaler()
    scaler.fit(train[cols])
    return {
        "train": scaler.transform(train[cols]),
        "valid": scaler.transform(valid[cols]),
        "oos": scaler.transform(oos[cols]),
        "scaler": scaler,
    }
