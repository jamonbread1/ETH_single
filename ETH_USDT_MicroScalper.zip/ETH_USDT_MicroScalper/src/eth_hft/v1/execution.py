"""执行引擎 v1 — Selective Micro Scalper 入场/持仓/撤改（Nautilus 可上线版）

职责（任务严格要求）
- Entry：Post Only 优先，仅 Trend + 高 edge + 快速行情才 marketable limit（吃单）
- Maker fill 需模拟 queue_position（Nautilus FillModel prob），回测四档 30/50/70/90% 灵敏度
- 提供 ExecutionEngine.submit_entry(signal,size), manage_position(...), cancel_replace

参数来源可追溯
- Post Only 优先：docs/06 §5 开仓与执行 Post-only 限价，能挂则挂，挂不上撤单，不主动吃单（保费率）；OKX 费率 Maker 0.02% vs Taker 0.05%（docs/03 §1）
- Marketable 例外三条件：Trend + 高 edge + 快速行情，三者同时满足才允许吃单（任务描述 Entry 细则，防滥用 Taker）
  * Trend 判定：来自 SignalType.TREND / Regime.STRONG_TREND（src/eth_hft/features/regime.detect_regime）
  * 高 edge 阈值：net_edge > 2×MIN_NET_EDGE 或 > 5bps（需 OOS 校准，默认 5bps + 可配置 execution.marketable_edge_thr_bps）
  * 快速行情：RV30 > 1.5×RV30_median 或 1m 波动 > 阈值（docs/05 §4 高波动 RiskScale=0.5，快速行情才放宽）
- Maker fill 排队：Nautilus FillModel prob 思想 + 本地队列模型（archive/legacy backtest/fill_model.maker_fill_probability）
  * 回测四档 30/50/70/90%：对 queue_position 灵敏度分析（docs/07 §4 四套回测 C 执行压力 + D 灾难测试）
- manage_position：复用 RiskEngine.manage_position（SL/TP/TimeStop/Emergency）+ 移动止损 trailing = max(0.03%, 1.0*RV30)
- cancel_replace：订单存活>阈值或价格偏离>阈值则撤改（OKX 限频保护，docs/06 §4 WS 长连接本地聚合，不轮询 REST）

与旧代码对齐
- Nautilus 策略基类：src/eth_hft/strategy/micro_scalper.MicroScalperStrategy.on_bar 通过 CostEngine + RiskEngine 前置过滤后，再经 ExecutionEngine 决定 PostOnly vs Marketable
- 合约取整：InstrumentSpec.round_price/round_size（src/eth_hft/core/instrument）
- 回测 FillModel：兼容 archive/legacy fill_model.simulate_fill 语义，本模块提供更细粒度的 queue_position 与四档敏感度

中文注释全覆盖，Nautilus 可直接 from eth_hft.v1.execution import ExecutionEngine 注入策略
"""

from __future__ import annotations

import math
import random
import time
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Literal

try:
    from loguru import logger  # type: ignore
except Exception:  # pragma: no cover
    import logging as _logging

    logger = _logging.getLogger("eth_hft.v1.execution")  # type: ignore

# 复用合约与成本/风控
try:
    from eth_hft.core.instrument import InstrumentSpec, DEFAULT_ETH_SWAP  # type: ignore
except Exception:
    try:
        from ..core.instrument import InstrumentSpec, DEFAULT_ETH_SWAP  # type: ignore
    except Exception:
        InstrumentSpec = None  # type: ignore
        DEFAULT_ETH_SWAP = None  # type: ignore

try:
    from eth_hft.v1.cost import CostEngine  # type: ignore
    from eth_hft.v1.risk import RiskEngine, RiskConfig, SignalType, PositionContext  # type: ignore
except Exception:
    try:
        from .cost import CostEngine  # type: ignore
        from .risk import RiskEngine, RiskConfig, SignalType, PositionContext  # type: ignore
    except Exception:
        CostEngine = None  # type: ignore
        RiskEngine = None  # type: ignore
        RiskConfig = None  # type: ignore
        SignalType = None  # type: ignore
        PositionContext = None  # type: ignore

# Nautilus 可选（实盘/回测引擎）
try:
    from nautilus_trader.model.enums import OrderSide, TimeInForce  # type: ignore
    from nautilus_trader.model.objects import Quantity, Price  # type: ignore

    _HAS_NAUTILUS = True
except Exception:
    _HAS_NAUTILUS = False
    OrderSide = None  # type: ignore
    TimeInForce = None  # type: ignore


# ------------------------------------------------------------------------------
# 配置与类型
# ------------------------------------------------------------------------------
class EntryMode(str, Enum):
    """入场模式"""

    POST_ONLY = "post_only"  # Post Only 挂单（默认，保 Maker 费率）
    MARKETABLE_LIMIT = "marketable_limit"  # 可成交限价（允许吃单，付 Taker 费率）
    MARKET = "market"  # 市价（仅极端，默认禁用）


class OrderStatus(str, Enum):
    """本地订单状态（简化 Nautilus OrderStatus）"""

    PENDING = "pending"
    OPEN = "open"
    FILLED = "filled"
    CANCELLED = "cancelled"
    REJECTED = "rejected"
    PARTIAL = "partial"


@dataclass
class ExecutionConfig:
    """执行配置（所有阈值可追溯，需样本外校准）

    来源
    - post_only_default True：docs/06 §5 Post-only 优先
    - marketable_edge_thr 0.0005 (5bps)：任务“高 edge”阈值，默认 5bps（2×MIN_NET_EDGE 1bps 的保守放大，需 OOS 扫描 3~10bps）
    - velocity_thr 0.0015：快速行情阈值（1m 波动或 RV30 上分位，需在 scripts/21_标定成本.py 中用历史 bbo-tbt 分位数标定）
    - maker_fill_probs 四档：30/50/70/90% 回测灵敏度（docs/07 §4 B/C/D 四套回测）
    - cancel_replace 阈值：订单存活 5s 或价格偏离 2bps 则撤改（OKX 限频与 docs/06 §4 WS 本地聚合）
    """

    post_only_default: bool = True
    # 仅当 Trend + edge>thr + velocity>thr 三条件同时满足才允许 marketable
    marketable_edge_thr: float = 0.0005  # 5bps，需 OOS 校准（来源 docs/03 阈值 1.5~3bps 放大）
    marketable_edge_thr_bps: float | None = None  # 若提供则覆盖 marketable_edge_thr
    velocity_thr: float = 0.0015  # 快速行情阈值（0.15% 1m 波动，示例，需实测分位数覆盖）
    allow_marketable: bool = True  # 总开关，关闭则永远 Post Only
    # Maker 排队
    queue_ahead_default: float = 100.0  # 队列前方名义（USDT），用于 fill_prob = volume/(queue+volume)
    maker_fill_probs: tuple[float, ...] = (0.30, 0.50, 0.70, 0.90)  # 回测四档灵敏度
    default_fill_prob: float = 0.50  # 默认档位
    # 撤改
    cancel_replace_after_s: float = 5.0  # 挂单超过 5s 未成交则考虑撤改
    cancel_replace_price_dev_bps: float = 2.0  # 价格偏离 >2bps 则撤改
    max_cancel_replace_retries: int = 3
    # 限价偏离
    post_only_offset_bps: float = 0.2  # Post Only 挂单相对 mid/best 的偏移（0.2bps 保队列优先）
    marketable_offset_bps: float = 1.0  # Marketable 限价相对 best 的偏移（1bps 保成交）

    def __post_init__(self) -> None:
        if self.marketable_edge_thr_bps is not None:
            self.marketable_edge_thr = float(self.marketable_edge_thr_bps) / 1e4

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Signal:
    """信号（供 ExecutionEngine.submit_entry 使用，最小化接口）

    字段
    - side: long/short
    - price: 参考价（mid 或 close）
    - expected_return: 预期毛收益小数（如 0.001 =0.10%），来自模型 E[R_{h}]
    - signal_type: mean_reversion | trend（决定 SL 取值与是否允许 marketable）
    - velocity: 快速行情指标（如 1m 波动、RV30、或 ATR/median 比值）
    - rv30: 30s 已实现波动率（用于 trailing / SL）
    - net_edge: 可选，若已由 CostEngine 计算则直接传入，否则引擎内部重算
    - best_bid / best_ask / mid: 可选，用于定价
    """

    side: Literal["long", "short"]
    price: float
    expected_return: float = 0.0
    signal_type: str = "mean_reversion"  # mean_reversion | trend
    velocity: float = 0.0
    rv30: float = 0.0
    net_edge: float | None = None
    best_bid: float | None = None
    best_ask: float | None = None
    mid: float | None = None
    timestamp: float | None = None  # 信号时间戳秒
    extra: dict = field(default_factory=dict)


@dataclass
class OrderRequest:
    """订单请求（本地抽象，Nautilus 适配时再转换）"""

    side: Literal["long", "short", "buy", "sell"]
    size_contracts: float
    price: float  # 限价
    mode: EntryMode
    post_only: bool
    time_in_force: str = "GTC"
    reduce_only: bool = False
    client_order_id: str | None = None
    created_ts: float = field(default_factory=time.time)
    status: OrderStatus = OrderStatus.PENDING
    filled_qty: float = 0.0
    queue_position: float | None = None  # 队列前方名义（USDT），用于 fill 模拟
    retries: int = 0
    meta: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["mode"] = self.mode.value if isinstance(self.mode, Enum) else str(self.mode)
        d["status"] = self.status.value if isinstance(self.status, Enum) else str(self.status)
        return d


@dataclass
class FillResult:
    """成交结果（模拟）"""

    filled: bool
    fill_price: float | None
    fill_qty: float
    fill_prob: float
    queue_position: float | None
    reason: str = ""


@dataclass
class PositionState:
    """持仓状态（供 manage_position 使用）"""

    side: Literal["long", "short"]
    entry_price: float
    size_contracts: float
    size_usdt: float
    entry_ts: float
    stop_pct: float = 0.0
    tp_pct: float = 0.0
    trailing_pct: float = 0.0
    expected_move: float = 0.0
    rv30: float = 0.0
    signal_type: str = "mean_reversion"
    best_trailing_price: float | None = None  # 趋势 40% trailing 的最高/最低锚


# ------------------------------------------------------------------------------
# 队列成交概率（Nautilus FillModel 思想）
# ------------------------------------------------------------------------------
def maker_fill_probability(queue_ahead: float, trade_volume: float) -> float:
    """Maker 成交概率（简化队列模型）

    来源：archive/legacy backtest/fill_model.maker_fill_probability
    思想：Nautilus FillModel 需估计队列位置，本实现用 trade_volume/(queue_ahead+trade_volume) 近似
    - queue_ahead：前方排队名义（USDT）
    - trade_volume：本周期成交量（USDT）

    注：真实 L2 队列需逐档深度，本函数为回测近似，必须做 30/50/70/90% 灵敏度分析
    """
    if trade_volume <= 0:
        return 0.0
    if queue_ahead <= 0:
        return 1.0
    return min(1.0, float(trade_volume) / (float(queue_ahead) + float(trade_volume)))


def simulate_maker_fill(
    queue_position: float,
    trade_volume: float = 50.0,
    fill_prob_override: float | None = None,
    rng: random.Random | None = None,
) -> tuple[bool, float]:
    """模拟 Maker 是否成交

    参数
    - queue_position：队列前方名义（USDT），越大越难成交
    - trade_volume：周期成交量
    - fill_prob_override：若提供则直接作为概率（用于 30/50/70/90% 四档敏感度强制覆盖）
    - rng：随机数生成器（便于回测复现）

    返回 (filled, prob)
    """
    if fill_prob_override is not None:
        prob = float(fill_prob_override)
        prob = max(0.0, min(1.0, prob))
    else:
        prob = maker_fill_probability(queue_position, trade_volume)
    r = (rng or random).random()
    return (r < prob), prob


# ------------------------------------------------------------------------------
# 执行引擎
# ------------------------------------------------------------------------------
class ExecutionEngine:
    """执行引擎 — 负责入场模式判定、Maker 排队模拟、持仓管理、撤改

    设计约束
    - 默认 Post Only，保 Maker 费率（0.02%）
    - 仅当 signal_type==trend 且 net_edge>marketable_edge_thr 且 velocity>velocity_thr 才允许 marketable_limit
    - Maker 未成交需 cancel_replace，避免长期挂单被动成交劣质价
    - manage_position 复用 RiskEngine 的 SL/TP/TimeStop/Emergency + trailing
    """

    def __init__(
        self,
        config: ExecutionConfig | None = None,
        cost_engine: CostEngine | None = None,
        risk_engine: RiskEngine | None = None,
        instrument_spec: InstrumentSpec | None = None,
    ) -> None:
        self.config: ExecutionConfig = config or ExecutionConfig()
        # 成本/风控引擎（惰性创建，保证独立可测）
        if cost_engine is not None:
            self.cost = cost_engine
        else:
            if CostEngine is not None:
                try:
                    self.cost = CostEngine()  # type: ignore
                except Exception:
                    self.cost = None  # type: ignore
            else:
                self.cost = None  # type: ignore
        if risk_engine is not None:
            self.risk = risk_engine
        else:
            if RiskEngine is not None:
                try:
                    self.risk = RiskEngine()  # type: ignore
                except Exception:
                    self.risk = None  # type: ignore
            else:
                self.risk = None  # type: ignore
        self.spec = instrument_spec if instrument_spec is not None else DEFAULT_ETH_SWAP  # type: ignore
        # 本地订单簿
        self.open_orders: dict[str, OrderRequest] = {}
        self._order_seq: int = 0
        self._rng = random.Random(42)  # 回测可复现随机数

    # ------------------------------------------------------------------ #
    # 入场模式判定
    # ------------------------------------------------------------------ #
    def _decide_entry_mode(self, signal: Signal, net_edge: float) -> tuple[EntryMode, bool, str]:
        """判定入场模式（核心三条件）

        规则
        - 默认 POST_ONLY
        - 仅当 allow_marketable 且 signal_type==trend 且 net_edge>thr 且 velocity>thr 时，才放宽为 MARKETABLE_LIMIT

        返回 (mode, post_only, reason)
        """
        if not self.config.allow_marketable:
            return EntryMode.POST_ONLY, True, "allow_marketable=False 强制 PostOnly"

        # 兼容 SignalType(str, Enum) 会使 str(enum) == "SignalType.TREND"，需取 .value
        try:
            _raw_st = signal.signal_type.value if hasattr(signal.signal_type, "value") else str(signal.signal_type)  # type: ignore
        except Exception:
            _raw_st = str(signal.signal_type)
        st = str(_raw_st).strip().lower()
        is_trend = st in ("trend", "strong_trend", "trend_start", "breakout", "momentum")
        if not is_trend:
            return EntryMode.POST_ONLY, True, f"非趋势信号({st})，保持 PostOnly"

        # 高 edge 判定：优先用已算净边际，否则用毛收益近似
        edge_thr = float(self.config.marketable_edge_thr)
        if net_edge < edge_thr:
            return EntryMode.POST_ONLY, True, f"net_edge {net_edge*1e4:.1f}bps < thr {edge_thr*1e4:.1f}bps，不吃单"

        # 快速行情判定
        vel = float(signal.velocity) if signal.velocity is not None else 0.0
        # velocity 来源多样：若为比值则阈值需映射；这里直接与 velocity_thr 比较
        if vel < float(self.config.velocity_thr):
            return EntryMode.POST_ONLY, True, f"velocity {vel:.5f} < thr {self.config.velocity_thr:.5f}，非快速行情"

        # 三条件同时满足
        return EntryMode.MARKETABLE_LIMIT, False, f"Trend+高edge({net_edge*1e4:.1f}bps)+快速行情({vel:.5f}) 允许 marketable"

    def _calc_net_edge(self, signal: Signal, entry_mode: EntryMode | None = None) -> float:
        """计算净边际（若 signal 已带则复用，否则经 CostEngine 估算）"""
        if signal.net_edge is not None:
            return float(signal.net_edge)
        if self.cost is None:
            # 无成本引擎时用毛收益近似（保守）
            return float(signal.expected_return) - 0.0004 - 0.00008 - 0.00006 - 0.00010
        # 按入场模式选择费率档位
        if entry_mode == EntryMode.MARKETABLE_LIMIT:
            # 吃单入场按 Taker 计费
            return float(self.cost.net_edge(signal.expected_return, "taker", "maker"))
        return float(self.cost.net_edge(signal.expected_return, "maker", "maker"))

    # ------------------------------------------------------------------ #
    # 定价
    # ------------------------------------------------------------------ #
    def _price_for_entry(self, signal: Signal, mode: EntryMode) -> float:
        """计算入场限价

        - POST_ONLY：在 best 盘口内侧挂单（买在 best_bid + offset，卖在 best_ask - offset），保证不跨 spread
        - MARKETABLE_LIMIT：在对侧 best 上加减 offset 保成交（买在 ask + offset，卖在 bid - offset）

        价格按 tickSz 取整
        """
        mid = signal.mid
        bid = signal.best_bid
        ask = signal.best_ask
        ref = float(signal.price)

        # 推导 mid
        if mid is None and bid is not None and ask is not None:
            mid = (float(bid) + float(ask)) / 2
        if mid is None:
            mid = ref

        offset_post = float(self.config.post_only_offset_bps) / 1e4 * mid
        offset_mkt = float(self.config.marketable_offset_bps) / 1e4 * mid

        if mode == EntryMode.POST_ONLY:
            if signal.side == "long":
                # 买单挂在 bid 侧略微抬价但不超过 mid，保 PostOnly
                base = float(bid) if bid is not None else mid
                price = base + offset_post * 0.5  # 轻微抬价提升队列优先级，但仍 < ask
                # 若跨 spread 则回退到 bid
                if ask is not None and price >= float(ask):
                    price = float(bid) if bid is not None else mid - offset_post
            else:
                base = float(ask) if ask is not None else mid
                price = base - offset_post * 0.5
                if bid is not None and price <= float(bid):
                    price = float(ask) if ask is not None else mid + offset_post
        else:
            # Marketable：为保证成交，价格设在对侧外侧
            if signal.side == "long":
                base = float(ask) if ask is not None else mid
                price = base + offset_mkt
            else:
                base = float(bid) if bid is not None else mid
                price = base - offset_mkt

        # 按 tickSz 取整
        if self.spec is not None:
            try:
                price = self.spec.round_price(float(price))  # type: ignore
            except Exception:
                pass
        return float(price)

    # ------------------------------------------------------------------ #
    # 对外 API：submit_entry
    # ------------------------------------------------------------------ #
    def submit_entry(
        self,
        signal: Signal | dict,
        size_contracts: float | None = None,
        size_usdt: float | None = None,
        price: float | None = None,
        queue_position: float | None = None,
        fill_prob_override: float | None = None,
        client_order_id: str | None = None,
        *args,
        **kwargs,
    ) -> OrderRequest:
        # 兼容任务描述 submit_entry(signal, size) 的 size 别名（支持 size/size_contracts/size_usdt 混用）
        # 处理位置参数形式 submit_entry(sig, 0.02) -> 第二位置已为 size_contracts
        # 关键字别名：size / qty / quantity / amount
        for _k in ("size", "qty", "quantity", "amount", "contracts"):
            if _k in kwargs and size_contracts is None and size_usdt is None:
                _v = kwargs.pop(_k)
                # 若值较小（<10）且 spec 存在，视为张数；否则按名义处理由后续换算决定
                # 这里优先视为 size_contracts，兼容任务示例
                size_contracts = float(_v)
        # 若仍无 size 且 args 中有剩余位置参数（兼容 submit_entry(sig, size) 的第二位置已在 signature，此处处理额外 args）
        if size_contracts is None and size_usdt is None and args:
            # args[0] 可能是 size 的位置别名
            try:
                size_contracts = float(args[0])
            except Exception:
                pass
        """提交入场订单（本地模拟 + Nautilus 适配）

        参数
        - signal: Signal 对象或 dict（含 side/price/expected_return/signal_type/velocity/rv30 等）
        - size_contracts: 合约张数（与 size_usdt 二选一，优先 contracts）
        - size_usdt: 名义 USDT（若提供则换算为张数）
        - price: 覆盖限价（None 则按定价逻辑自动算）
        - queue_position: 队列前方名义（用于 Maker fill 模拟，Nautilus FillModel prob）
        - fill_prob_override: 强制成交概率（用于回测 30/50/70/90% 档位覆盖）
        - client_order_id: 客户端订单 ID

        返回 OrderRequest（含 mode/post_only/price/queue_position）

        熔断前置：若 RiskEngine 处于 LOCKED/STOPPED 则拒绝
        """
        # 归一化 signal
        if isinstance(signal, dict):
            sig = Signal(
                side=signal.get("side", "long"),  # type: ignore
                price=float(signal.get("price", signal.get("mid", 3000))),
                expected_return=float(signal.get("expected_return", signal.get("expected_move", 0))),
                signal_type=str(signal.get("signal_type", signal.get("type", "mean_reversion"))),
                velocity=float(signal.get("velocity", signal.get("atr_ratio", 0))),
                rv30=float(signal.get("rv30", 0)),
                net_edge=signal.get("net_edge"),
                best_bid=signal.get("best_bid"),
                best_ask=signal.get("best_ask"),
                mid=signal.get("mid"),
                timestamp=signal.get("timestamp"),
                extra={k: v for k, v in signal.items() if k not in ("side", "price", "expected_return", "expected_move", "signal_type", "type", "velocity", "atr_ratio", "rv30", "net_edge", "best_bid", "best_ask", "mid", "timestamp")},
            )
        elif isinstance(signal, Signal):
            sig = signal
        else:
            raise TypeError(f"signal 类型非法 {type(signal)}")

        # 熔断检查
        if self.risk is not None:
            try:
                allowed, reason = self.risk.is_trading_allowed()  # type: ignore
                if not allowed:
                    raise RuntimeError(f"KillSwitch 禁止开仓: {reason}")
            except Exception as e:
                if "KillSwitch" in str(e):
                    raise

        # 尺寸换算
        contracts = size_contracts
        if contracts is None and size_usdt is not None and self.spec is not None:
            try:
                contracts = float(size_usdt) / (self.spec.ct_val * float(sig.price))  # type: ignore
                contracts = self.spec.round_size(float(contracts))  # type: ignore
            except Exception:
                contracts = float(size_usdt) / float(sig.price)
        if contracts is None:
            raise ValueError("需提供 size_contracts 或 size_usdt（后者需 instrument_spec）")
        contracts = float(contracts)
        if contracts <= 0:
            raise ValueError(f"数量非法 {contracts}")

        # 数量校验 minSz
        if self.spec is not None:
            try:
                if not self.spec.is_valid_size(contracts):  # type: ignore
                    raise ValueError(f"数量 {contracts} < minSz {self.spec.min_sz}")
            except Exception as e:
                if "minSz" in str(e):
                    raise

        # 成本判定
        # 先按 PostOnly 估算净边际，再决定是否放宽为 Marketable
        edge_post = self._calc_net_edge(sig, EntryMode.POST_ONLY)
        mode, post_only, reason = self._decide_entry_mode(sig, edge_post)
        # 若判定为 Marketable，需重算 Taker 入场的净边际，若重算后不满足则回退
        if mode == EntryMode.MARKETABLE_LIMIT:
            edge_mkt = self._calc_net_edge(sig, EntryMode.MARKETABLE_LIMIT)
            if edge_mkt < float(self.config.marketable_edge_thr):
                mode, post_only, reason = EntryMode.POST_ONLY, True, f"Marketable 重算 edge {edge_mkt*1e4:.1f}bps < thr，回退 PostOnly"

        # 定价
        if price is not None:
            order_price = float(price)
            if self.spec is not None:
                try:
                    order_price = self.spec.round_price(order_price)  # type: ignore
                except Exception:
                    pass
        else:
            order_price = self._price_for_entry(sig, mode)

        # 生成订单
        self._order_seq += 1
        oid = client_order_id or f"v1-{int(time.time()*1000)}-{self._order_seq}"
        req = OrderRequest(
            side=str(sig.side).lower(),  # type: ignore
            size_contracts=float(contracts),
            price=float(order_price),
            mode=mode,
            post_only=bool(post_only),
            client_order_id=oid,
            queue_position=float(queue_position) if queue_position is not None else float(self.config.queue_ahead_default),
            meta={"signal_type": sig.signal_type, "expected_return": sig.expected_return, "net_edge": edge_post, "velocity": sig.velocity, "rv30": sig.rv30, "reason": reason, "fill_prob_override": fill_prob_override},
        )
        req.status = OrderStatus.OPEN
        self.open_orders[oid] = req
        logger.info(f"提交入场 {req.side} {req.size_contracts}@{req.price:.2f} mode={mode.value} post_only={post_only} edge={edge_post*1e4:.1f}bps 原因:{reason} oid={oid}")
        return req

    # ------------------------------------------------------------------ #
    # Maker 成交模拟（队列位置）
    # ------------------------------------------------------------------ #
    def try_fill(
        self,
        order: OrderRequest,
        best_bid: float | None = None,
        best_ask: float | None = None,
        trade_volume: float = 50.0,
        last_price: float | None = None,
        fill_prob_override: float | None = None,
    ) -> FillResult:
        """尝试撮合（回测/本地模拟）

        逻辑
        - MARKETABLE_LIMIT：假设立即成交（Taker），返回 filled=True（回测中已含滑点）
        - POST_ONLY：按 queue_position 与 trade_volume 计算 prob，或用四档覆盖；随机判定是否成交
        - 若 best 盘口跨过限价（买单 price>=ask / 卖单 price<=bid），也视为可成交，但 PostOnly 需检查是否被动跨 spread（此时按 Taker 处理并告警）

        参数
        - best_bid/best_ask/last_price：当前盘口
        - trade_volume：本周期成交量名义（USDT），用于队列模型
        - fill_prob_override：强制概率（30/50/70/90% 灵敏度档位）

        返回 FillResult
        """
        # 覆盖优先级：调用参数 > 订单 meta > 配置默认
        prob_override = fill_prob_override
        if prob_override is None and order.meta.get("fill_prob_override") is not None:
            prob_override = order.meta.get("fill_prob_override")

        if order.mode == EntryMode.MARKETABLE_LIMIT:
            # Taker 假设必成（回测中已通过滑点计成本）
            order.status = OrderStatus.FILLED
            order.filled_qty = float(order.size_contracts)
            return FillResult(filled=True, fill_price=float(order.price), fill_qty=float(order.size_contracts), fill_prob=1.0, queue_position=order.queue_position, reason="marketable 必成（Taker 滑点已计成本）")

        # POST_ONLY 路径
        # 检查是否触价
        touch = False
        if order.side in ("long", "buy"):
            if best_ask is not None and order.price >= float(best_ask):
                touch = True
                logger.warning(f"PostOnly 买单 {order.price:.2f} >= ask {best_ask:.2f} 触价，若成交将按 Taker 处理")
            if last_price is not None and order.price >= float(last_price):
                touch = True
        else:
            if best_bid is not None and order.price <= float(best_bid):
                touch = True
                logger.warning(f"PostOnly 卖单 {order.price:.2f} <= bid {best_bid:.2f} 触价")
            if last_price is not None and order.price <= float(last_price):
                touch = True

        # 队列成交概率
        qp = float(order.queue_position) if order.queue_position is not None else float(self.config.queue_ahead_default)
        filled, prob = simulate_maker_fill(qp, trade_volume, prob_override, self._rng)

        # 若未触价，强行未成交（即使随机命中也视为未成交，保 PostOnly 语义）
        if not touch and prob_override is None:
            # 回测简化：未触价时成交概率减半（队列未被消耗）
            # 但若显式传入 fill_prob_override（敏感度测试），则尊重覆盖值
            prob = prob * 0.5
            filled = self._rng.random() < prob

        if filled:
            order.status = OrderStatus.FILLED
            order.filled_qty = float(order.size_contracts)
            # 队列消耗后，前方排队减少
            order.queue_position = max(0.0, qp - trade_volume)
            return FillResult(filled=True, fill_price=float(order.price), fill_qty=float(order.size_contracts), fill_prob=prob, queue_position=order.queue_position, reason="maker 排队成交")

        # 未成交，保持 OPEN
        # 队列随时间小幅前移（模拟前方订单被成交）
        order.queue_position = max(0.0, qp - trade_volume * 0.2)
        return FillResult(filled=False, fill_price=None, fill_qty=0.0, fill_prob=prob, queue_position=order.queue_position, reason="maker 未成交（队列未消耗完）")

    def backtest_fill_sensitivity(
        self,
        order: OrderRequest,
        trade_volume: float = 50.0,
        repeats: int = 1000,
    ) -> dict:
        """回测四档成交率灵敏度（30/50/70/90%）

        对同一订单，分别在四档 fill_prob 下模拟 repeats 次，统计成交率与期望成本
        用于 docs/07 §4 四套回测 C 执行压力分析

        返回 {prob: {fill_rate, expected_pnl, ...}}
        """
        results: dict[float, dict] = {}
        for prob in self.config.maker_fill_probs:
            fills = 0
            for _ in range(repeats):
                # 每次重置队列
                f, _ = simulate_maker_fill(float(order.queue_position or self.config.queue_ahead_default), trade_volume, prob, random.Random())
                if f:
                    fills += 1
            fill_rate = fills / repeats if repeats else 0.0
            results[float(prob)] = {"fill_prob": prob, "fill_rate": fill_rate, "fills": fills, "repeats": repeats, "queue_position": order.queue_position}
        return results

    # ------------------------------------------------------------------ #
    # 持仓管理（复用 RiskEngine）
    # ------------------------------------------------------------------ #
    def manage_position(
        self,
        position: PositionState | dict,
        mark_price: float,
        now_ts: float | None = None,
        current_expected: float | None = None,
        signal_invalidation_score: float | None = None,
        rv30: float | None = None,
    ) -> dict:
        """持仓管理（SL/TP/TimeStop/Emergency/Trailing）

        参数
        - position: PositionState 或 dict（含 side/entry_price/size_contracts/entry_ts/stop_pct/tp_pct 等）
        - mark_price: 最新标记价
        - now_ts: 当前时间戳秒
        - current_expected: 当前预期收益（用于 TimeStop 判定）
        - signal_invalidation_score: 失效分（用于 Emergency）
        - rv30: 最新 RV30（用于 trailing 更新）

        返回 {action: 'hold'|'close'|'reduce', reason, msg, details}
        复用 RiskEngine.manage_position，若无 RiskEngine 则做简化判定
        """
        # 归一化 position
        if isinstance(position, dict):
            pos = PositionState(
                side=position.get("side", "long"),  # type: ignore
                entry_price=float(position.get("entry_price", mark_price)),
                size_contracts=float(position.get("size_contracts", 0)),
                size_usdt=float(position.get("size_usdt", 0)),
                entry_ts=float(position.get("entry_ts", now_ts or time.time())),
                stop_pct=float(position.get("stop_pct", 0)),
                tp_pct=float(position.get("tp_pct", 0)),
                trailing_pct=float(position.get("trailing_pct", 0)),
                expected_move=float(position.get("expected_move", 0)),
                rv30=float(position.get("rv30", rv30 or 0)),
                signal_type=str(position.get("signal_type", "mean_reversion")),
                best_trailing_price=position.get("best_trailing_price"),
            )
        elif isinstance(position, PositionState):
            pos = position
        else:
            raise TypeError(f"position 类型非法 {type(position)}")

        now = float(now_ts) if now_ts is not None else time.time()
        # Trailing 锚点更新（趋势 40% 仓位）—— 先更新锚点，但不立即判定，保留给后续优先级比较
        trailing_hit = False
        trailing_msg = ""
        trailing_anchor = None
        if pos.trailing_pct and pos.trailing_pct > 0:
            # 更新锚点（记录多头最高/空头最低）
            if pos.side == "long":
                anchor = pos.best_trailing_price if pos.best_trailing_price is not None else pos.entry_price
                if mark_price > anchor:
                    pos.best_trailing_price = float(mark_price)
                    anchor = float(mark_price)
                else:
                    anchor = float(anchor)
                # 回撤超过 trailing 则标记命中（但 SL/Emergency 优先级更高，延后返回）
                if anchor and mark_price <= anchor * (1 - pos.trailing_pct):
                    trailing_hit = True
                    trailing_anchor = anchor
                    trailing_msg = f"Trailing 触发 {mark_price:.2f} <= {anchor:.2f}*(1-{pos.trailing_pct*1e4:.1f}bps)"
            else:
                anchor = pos.best_trailing_price if pos.best_trailing_price is not None else pos.entry_price
                if mark_price < anchor:
                    pos.best_trailing_price = float(mark_price)
                    anchor = float(mark_price)
                else:
                    anchor = float(anchor)
                if anchor and mark_price >= anchor * (1 + pos.trailing_pct):
                    trailing_hit = True
                    trailing_anchor = anchor
                    trailing_msg = f"Trailing 触发 {mark_price:.2f} >= {anchor:.2f}*(1+{pos.trailing_pct*1e4:.1f}bps)"

        # 委托 RiskEngine 综合判定（SL/Emergency/TimeStop 优先级高于 Trailing）
        if self.risk is not None and PositionContext is not None:
            try:
                # 兼容 SignalType(str, Enum) 的 normalize 需先判断 Enum 本体
                if SignalType is not None:
                    _st_raw = pos.signal_type
                    if isinstance(_st_raw, SignalType):  # type: ignore
                        _st = _st_raw  # type: ignore
                    else:
                        try:
                            _val = _st_raw.value if hasattr(_st_raw, "value") else str(_st_raw)  # type: ignore
                        except Exception:
                            _val = str(_st_raw)
                        _st = SignalType.normalize(str(_val))  # type: ignore
                else:
                    _st = pos.signal_type  # type: ignore
                ctx = PositionContext(
                    entry_price=float(pos.entry_price),
                    side=str(pos.side),  # type: ignore
                    entry_ts=float(pos.entry_ts),
                    size_usdt=float(pos.size_usdt),
                    stop_pct=float(pos.stop_pct),
                    tp_pct=float(pos.tp_pct),
                    expected_move=float(pos.expected_move),
                    rv30=float(pos.rv30 if rv30 is None else rv30),
                    signal_type=_st,  # type: ignore
                )
                res = self.risk.manage_position(ctx, float(mark_price), now, current_expected, signal_invalidation_score)  # type: ignore
                # 同步 trailing 锚点回结果
                if pos.best_trailing_price is not None:
                    res.setdefault("details", {})["best_trailing_price"] = pos.best_trailing_price
                # 若 Risk 判定为 SL/Emergency/TimeStop，则优先于 Trailing
                if res.get("action") == "close" and res.get("reason") in ("stop_loss", "emergency", "time_stop"):
                    return res
                # 若 Trailing 命中且 Risk 未触发更高级熔断，则 Trailing 触发
                if trailing_hit:
                    return {"action": "close", "reason": "trailing", "msg": trailing_msg, "details": {"anchor": trailing_anchor, "trailing_pct": pos.trailing_pct, "best_trailing_price": pos.best_trailing_price}}
                return res
            except Exception as e:
                logger.warning(f"RiskEngine.manage_position 异常回退至本地判定: {e}")
                # 异常时若 Trailing 命中则返回 Trailing
                if trailing_hit:
                    return {"action": "close", "reason": "trailing", "msg": trailing_msg, "details": {"anchor": trailing_anchor, "trailing_pct": pos.trailing_pct}}

        # 本地简化判定（无 RiskEngine 时）
        # Emergency
        if signal_invalidation_score is not None and float(signal_invalidation_score) > 0.8:
            return {"action": "close", "reason": "emergency", "msg": f"失效分 {signal_invalidation_score:.3f} > 0.8"}
        # TimeStop
        holding = now - float(pos.entry_ts)
        thr_s = 90
        thr_exp = 0.0003
        if holding > thr_s and current_expected is not None and float(current_expected) < thr_exp:
            return {"action": "close", "reason": "time_stop", "msg": f"持仓 {holding:.0f}s > {thr_s}s 且 expected {float(current_expected)*1e4:.1f}bps < {thr_exp*1e4:.1f}bps"}
        # SL
        if pos.stop_pct and pos.stop_pct > 0:
            if pos.side == "long" and mark_price <= pos.entry_price * (1 - pos.stop_pct):
                return {"action": "close", "reason": "stop_loss", "msg": f"SL {mark_price:.2f} <= {pos.entry_price*(1-pos.stop_pct):.2f}"}
            if pos.side == "short" and mark_price >= pos.entry_price * (1 + pos.stop_pct):
                return {"action": "close", "reason": "stop_loss", "msg": f"SL {mark_price:.2f} >= {pos.entry_price*(1+pos.stop_pct):.2f}"}
        # Trailing（仅在 SL 未触发时考虑，优先级低于 SL 高于 TP）
        if trailing_hit:
            return {"action": "close", "reason": "trailing", "msg": trailing_msg, "details": {"anchor": trailing_anchor, "trailing_pct": pos.trailing_pct, "best_trailing_price": pos.best_trailing_price}}
        # TP
        if pos.tp_pct and pos.tp_pct > 0:
            if pos.side == "long" and mark_price >= pos.entry_price * (1 + pos.tp_pct):
                return {"action": "close", "reason": "take_profit", "msg": f"TP {mark_price:.2f} >= {pos.entry_price*(1+pos.tp_pct):.2f}"}
            if pos.side == "short" and mark_price <= pos.entry_price * (1 - pos.tp_pct):
                return {"action": "close", "reason": "take_profit", "msg": f"TP {mark_price:.2f} <= {pos.entry_price*(1-pos.tp_pct):.2f}"}
        return {"action": "hold", "reason": "ok", "msg": "持有"}

    # ------------------------------------------------------------------ #
    # 撤改 cancel_replace
    # ------------------------------------------------------------------ #
    def should_cancel_replace(self, order: OrderRequest, mark_price: float | None = None, now_ts: float | None = None) -> tuple[bool, str]:
        """判断是否需要撤改

        条件（任一满足即撤改）
        - 存活时间 > cancel_replace_after_s (5s)
        - 价格偏离 > cancel_replace_price_dev_bps (2bps)（以 mid/mark_price 为基准）
        - 订单状态非 OPEN 则不撤改
        """
        if order.status != OrderStatus.OPEN:
            return False, "订单非 OPEN"
        now = float(now_ts) if now_ts is not None else time.time()
        age = now - float(order.created_ts)
        if age > float(self.config.cancel_replace_after_s):
            return True, f"存活 {age:.1f}s > {self.config.cancel_replace_after_s:.1f}s"
        if mark_price is not None and order.price:
            mid = float(mark_price)
            if mid > 0:
                dev_bps = abs(float(order.price) - mid) / mid * 1e4
                if dev_bps > float(self.config.cancel_replace_price_dev_bps):
                    return True, f"价格偏离 {dev_bps:.1f}bps > {self.config.cancel_replace_price_dev_bps:.1f}bps"
        return False, "ok"

    def cancel_replace(
        self,
        order: OrderRequest,
        new_price: float | None = None,
        mark_price: float | None = None,
        now_ts: float | None = None,
        signal: Signal | dict | None = None,
    ) -> OrderRequest | None:
        """撤单并重挂（cancel_replace）

        步骤
        1. 检查 should_cancel_replace，若无需撤改则返回 None
        2. 将旧订单标记为 CANCELLED
        3. 按最新盘口/信号重算价格（若提供 new_price 则直接用，否则按 signal 定价）
        4. 生成新订单，retries+1，queue_position 重置

        返回新 OrderRequest 或 None（无需撤改）
        """
        need, reason = self.should_cancel_replace(order, mark_price, now_ts)
        if not need:
            logger.debug(f"无需撤改 oid={order.client_order_id} {reason}")
            return None
        if order.retries >= int(self.config.max_cancel_replace_retries):
            logger.warning(f"撤改次数已达上限 {order.retries} oid={order.client_order_id}，不再重挂")
            order.status = OrderStatus.CANCELLED
            return None

        # 撤销旧单
        order.status = OrderStatus.CANCELLED
        logger.info(f"撤单 oid={order.client_order_id} 原因:{reason} price={order.price:.2f}")

        # 计算新价
        if new_price is not None:
            nxt_price = float(new_price)
        elif signal is not None:
            # 按信号重定价
            if isinstance(signal, dict):
                sig = Signal(
                    side=signal.get("side", order.side),  # type: ignore
                    price=float(signal.get("price", mark_price or order.price)),
                    expected_return=float(signal.get("expected_return", 0)),
                    signal_type=str(signal.get("signal_type", "mean_reversion")),
                    velocity=float(signal.get("velocity", 0)),
                    rv30=float(signal.get("rv30", 0)),
                    best_bid=signal.get("best_bid"),
                    best_ask=signal.get("best_ask"),
                    mid=signal.get("mid", mark_price),
                )
            else:
                sig = signal  # type: ignore
            nxt_price = self._price_for_entry(sig, order.mode)
        else:
            # 无信号则按原方向微调向 mid 靠拢
            if mark_price is not None:
                # 向 mark_price 靠拢一个 tick
                nxt_price = float(mark_price)
                if self.spec is not None:
                    try:
                        nxt_price = self.spec.round_price(nxt_price)  # type: ignore
                    except Exception:
                        pass
                # 保证 PostOnly 语义：买单不高于 ask，卖单不低于 bid
                if order.side in ("long", "buy") and order.price < nxt_price:
                    nxt_price = float(order.price)
            else:
                nxt_price = float(order.price)

        # 生成新订单
        self._order_seq += 1
        new_oid = f"{order.client_order_id}-r{order.retries+1}"
        new_order = OrderRequest(
            side=order.side,  # type: ignore
            size_contracts=float(order.size_contracts),
            price=float(nxt_price),
            mode=order.mode,
            post_only=bool(order.post_only),
            client_order_id=new_oid,
            created_ts=float(now_ts) if now_ts is not None else time.time(),
            status=OrderStatus.OPEN,
            queue_position=float(self.config.queue_ahead_default),
            retries=int(order.retries) + 1,
            meta={**order.meta, "replaced_from": order.client_order_id, "replace_reason": reason},
        )
        if self.spec is not None:
            try:
                new_order.price = self.spec.round_price(float(new_order.price))  # type: ignore
            except Exception:
                pass
        self.open_orders[new_oid] = new_order
        logger.info(f"重挂 oid={new_oid} price={new_order.price:.2f} from={order.client_order_id} 原因:{reason}")
        return new_order

    # ------------------------------------------------------------------ #
    # Nautilus 适配（可选）
    # ------------------------------------------------------------------ #
    def to_nautilus_order(self, req: OrderRequest, instrument_id_str: str = "ETHUSDT-PERP.OKX"):
        """将 OrderRequest 转为 Nautilus 订单（需 nautilus_trader 安装）

        仅在 _HAS_NAUTILUS 时可用，否则抛出 ImportError
        """
        if not _HAS_NAUTILUS:
            raise ImportError("nautilus_trader 未安装，无法转换 Nautilus 订单（回测可用本地模拟）")
        # 动态导入以保持可选
        from nautilus_trader.model.identifiers import InstrumentId  # type: ignore
        from nautilus_trader.model.enums import OrderSide as NTSide, TimeInForce as NT_TIF  # type: ignore
        from nautilus_trader.model.objects import Quantity, Price  # type: ignore

        instrument_id = InstrumentId.from_str(instrument_id_str)
        side = NTSide.BUY if req.side in ("long", "buy") else NTSide.SELL
        qty = Quantity(float(req.size_contracts), 2)
        price = Price(float(req.price), 2)
        tif = NT_TIF.GTC if req.time_in_force == "GTC" else NT_TIF.IOC
        # PostOnly 通过 time_in_force / post_only 标记（Nautilus 需在 OrderFactory 中指定）
        return {"instrument_id": instrument_id, "side": side, "quantity": qty, "price": price, "time_in_force": tif, "post_only": req.post_only, "client_order_id": req.client_order_id}

    def __repr__(self) -> str:
        return f"ExecutionEngine(mode_default={'PostOnly' if self.config.post_only_default else 'Mixed'}, marketable_thr={self.config.marketable_edge_thr*1e4:.1f}bps)"

    # ------------------------------------------------------------------ #
    # 别名（兼容不同调用习惯）
    # ------------------------------------------------------------------ #
    submit_order = submit_entry  # 兼容旧命名
    place_order = submit_entry
    send_order = submit_entry
    # manage_position 别名
    update_position = manage_position
    handle_position = manage_position
    # cancel_replace 别名
    replace_order = cancel_replace
    cancel_and_replace = cancel_replace
    amend_order = cancel_replace
