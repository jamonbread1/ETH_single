"""风控引擎 v1 — Selective Micro Scalper 仓位/止损/止盈/三类保护

职责（任务严格要求）
- 仓位：size_position(equity, stop_distance) -> notional = min(risk_budget/stop, equity*2, exchange_limit)，risk_budget 0.25U 示例，需与 position_sizer.py 对齐（复用）
- 止损 SL：max(signal_invalidation, 1.5*RV30)，且若 > MAX_SL 则 reject_trade()；区分 MeanReversion SL=信号失效位 vs Trend SL=pullback low
- 止盈 TP：TP_min = round_trip + execution + min_profit (Maker→Maker 0.08%)，TP = max(TP_min, 0.5*ExpectedMove)，趋势分层 30%/30%/40% trailing
- 移动止损 trailing = max(0.03%, 1.0*RV30)
- 时间止损 TimeStop：持仓>90s and expected<0.0003 则平
- 异常：signal_invalidation_score>thr 紧急平
- 熔断 KillSwitch：连续亏损3→减半, 5→LOCKED 10-30min, 日损-2% STOP

参数来源可追溯
- risk_budget_usdt 0.20~0.25U：docs/05_position_sizing §1 固定风险预算，configs/strategy.yaml position.risk_budget_usdt，docs/00 §5 任何参数都能在 configs 或注释中找到来源
- 杠杆/保证金：docs/05 §3 设计链路 RiskBudget→止损%→理论名义→lotSz 取整→minSz→保证金，src/eth_hft/risk/position_sizer.calc_position 已工程化
- RV30：30s 已实现波动率，来自 src/eth_hft/features/microstructure.add_basic_features vol_20 / atr_14 的短周期变体，依据 docs/07 必须 shift(1) 防未来函数
- SL 系数 1.5*RV30：对话策略失效点保护，docs/04 §2 文献/经典可追溯，禁止拍脑子（需在 docs/03 参数清单追加）
- MAX_SL：configs/risk.yaml stop.fixed_stop_bps 10 (0.10%) 为基准，v1 默认 0.005 (0.5%) 可配置，超过则 reject_trade
- TP_min 0.08%：Maker→Maker 双边 0.04% + 点差+滑点+安全垫后约 6.4bps，取 8bps 保覆盖（docs/03 §3 对话示例 0.064%）
- TP 系数 0.5*ExpectedMove：预期移动一半兑现，剩余让利给趋势分层（docs/06 §5 TP = max(费用+缓冲, ExpectedMove*k)）
- trailing 0.03% / 1.0*RV30：docs/06 §5 止盈动态，同 SL 取波动自适应
- TimeStop 90s / 0.0003：任务明确要求，持仓>90s 且 expected<3bps 则平（防时间衰减）
- KillSwitch 连续亏损/日损阈值：configs/risk.yaml kill_switch.consecutive_losses 5 / daily_loss_limit_usdt 2.0U，小账户示例 -2% 日损即停（docs/06 §6 账户级风控）

与旧代码对齐
- 复用 src/eth_hft/risk/position_sizer.calc_position 与 InstrumentSpec，保证 lotSz/minSz/tickSz 一致性
- 复用/src 扩展 src/eth_hft/risk/kill_switch.KillSwitch 语义，本模块提供更细粒度的连续亏损分级（3→减半 5→LOCKED）与日损 -2% 判定
- Nautilus 可上线：纯 Python 逻辑，不依赖交易引擎；可被 strategy/micro_scalper.py 注入作为风控前置

中文注释全覆盖，参数来源在每处默认值旁标注
"""

from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Literal

try:
    from loguru import logger  # type: ignore
except Exception:  # pragma: no cover
    import logging as _logging

    logger = _logging.getLogger("eth_hft.v1.risk")  # type: ignore

# 复用现有仓位计算器（保证与 position_sizer.py 对齐）
try:
    from eth_hft.risk.position_sizer import calc_position as _calc_position  # type: ignore
    from eth_hft.risk.position_sizer import SizingResult  # type: ignore
    from eth_hft.core.instrument import InstrumentSpec, DEFAULT_ETH_SWAP  # type: ignore
except Exception:  # pragma: no cover
    # 兜底：相对导入（用于包内）
    try:
        from ..risk.position_sizer import calc_position as _calc_position  # type: ignore
        from ..risk.position_sizer import SizingResult  # type: ignore
        from ..core.instrument import InstrumentSpec, DEFAULT_ETH_SWAP  # type: ignore
    except Exception:
        _calc_position = None  # type: ignore
        SizingResult = None  # type: ignore
        InstrumentSpec = None  # type: ignore
        DEFAULT_ETH_SWAP = None  # type: ignore

# 成本引擎用于 TP_min 计算
try:
    from eth_hft.v1.cost import CostEngine  # type: ignore
except Exception:
    try:
        from .cost import CostEngine  # type: ignore
    except Exception:
        CostEngine = None  # type: ignore

# ------------------------------------------------------------------------------
# 常量（来源标注）
# ------------------------------------------------------------------------------
DEFAULT_RISK_BUDGET_USDT: float = 0.25  # 任务示例 0.25U，实际以 configs/strategy.yaml position.risk_budget_usdt (0.20U) 为准
DEFAULT_MAX_SL_PCT: float = 0.005  # 0.5%，超过则 reject_trade（来源 configs/risk.yaml stop.fixed_stop_bps 10 + 保守放大，docs/05 §4 极端行情 RiskScale=0）
DEFAULT_RV_MULTIPLE_SL: float = 1.5  # SL = max(invalidation, 1.5*RV30)
DEFAULT_TRAILING_BASE_PCT: float = 0.0003  # 0.03%
DEFAULT_TRAILING_RV_MULTIPLE: float = 1.0  # trailing = max(0.03%, 1.0*RV30)
DEFAULT_TIME_STOP_S: int = 90  # 90s
DEFAULT_TIME_STOP_EXPECTED_THR: float = 0.0003  # 3bps
DEFAULT_TP_MIN_MAKER_MAKER: float = 0.0008  # 0.08%，Maker→Maker 最低止盈（docs/03 §3）
DEFAULT_TP_EXPECTED_RATIO: float = 0.5  # TP = max(TP_min, 0.5*ExpectedMove)
DEFAULT_EXCHANGE_NOTIONAL_LIMIT: float = 500_000.0  # 交易所单笔名义上限兜底（OKX 实际以 instruments 为准，这里取保守大值）


class SignalType(str, Enum):
    """信号类型，决定 SL 取值逻辑"""

    MEAN_REVERSION = "mean_reversion"  # 均值回归：SL = 信号失效位
    TREND = "trend"  # 趋势：SL = 回撤低点 pullback low
    BREAKOUT = "breakout"  # 突破：按趋势处理

    @classmethod
    def normalize(cls, v: str | None) -> "SignalType":
        if v is None:
            return cls.MEAN_REVERSION
        s = str(v).strip().lower()
        if s in ("trend", "momentum", "strong_trend", "trend_start"):
            return cls.TREND
        if s in ("breakout", "bo"):
            return cls.BREAKOUT
        return cls.MEAN_REVERSION


class KillState(str, Enum):
    """熔断状态（任务三档）"""

    NORMAL = "normal"  # 正常
    HALVED = "halved"  # 连续亏损3 → 仓位减半 (risk_scale=0.5)
    LOCKED = "locked"  # 连续亏损5 → 锁定 10-30min
    STOPPED = "stopped"  # 日损 -2% → 当日停止


class RejectReason(str, Enum):
    """拒绝开仓原因"""

    SL_TOO_WIDE = "sl_too_wide"  # 止损过大 >MAX_SL
    SL_INVALID = "sl_invalid"
    NOTIONAL_TOO_SMALL = "notional_too_small"
    KILL_SWITCH = "kill_switch"
    RISK_SCALE_ZERO = "risk_scale_zero"


class RejectTradeError(RuntimeError):
    """拒绝交易异常（由 RiskEngine.reject_trade 抛出）"""

    def __init__(self, reason: RejectReason | str, detail: str = "") -> None:
        self.reason = reason
        super().__init__(f"reject_trade: {reason} {detail}".strip())


@dataclass
class RiskConfig:
    """风控配置（所有阈值来源可追溯，禁止拍脑子）"""

    # 仓位
    risk_budget_usdt: float = DEFAULT_RISK_BUDGET_USDT  # 0.25U 示例，来源 docs/05 §1 / configs/strategy.yaml
    max_leverage: float = 100.0  # OKX lever_max 100（src/eth_hft/core/instrument.DEFAULT_ETH_SWAP）
    min_margin_usdt: float = 0.30  # configs/strategy.yaml position.min_margin_usdt
    equity_cap_multiple: float = 2.0  # notional 上限 equity*2（任务公式）
    exchange_limit_usdt: float = DEFAULT_EXCHANGE_NOTIONAL_LIMIT  # 交易所限额，来源 OKX instruments 实际值
    risk_scale_normal: float = 1.0
    risk_scale_high_vol: float = 0.5
    risk_scale_extreme: float = 0.0

    # 止损
    max_sl_pct: float = DEFAULT_MAX_SL_PCT  # 0.5% 超过则 reject（来源 configs/risk.yaml stop.fixed_stop_bps 扩展）
    rv_multiple_sl: float = DEFAULT_RV_MULTIPLE_SL  # 1.5*RV30
    # 止盈
    tp_min_maker_maker: float = DEFAULT_TP_MIN_MAKER_MAKER  # 0.08% Maker→Maker
    tp_expected_ratio: float = DEFAULT_TP_EXPECTED_RATIO  # 0.5*ExpectedMove
    tp_tiers_trend: tuple[tuple[float, float], ...] = ((0.30, 0.30), (0.30, 0.30), (0.40, 0.40))  # (止盈比例?, 仓位比例) 简化：三档 30/30/40 trailing（任务要求）
    # 移动止损
    trailing_base_pct: float = DEFAULT_TRAILING_BASE_PCT
    trailing_rv_multiple: float = DEFAULT_TRAILING_RV_MULTIPLE
    # 时间止损
    time_stop_s: int = DEFAULT_TIME_STOP_S
    time_stop_expected_thr: float = DEFAULT_TIME_STOP_EXPECTED_THR
    # 异常
    invalidation_thr: float = 0.8  # signal_invalidation_score > thr 紧急平（需 OOS 校准）
    # 熔断
    kill_consec_halve: int = 3  # 连续亏损3 → 减半
    kill_consec_lock: int = 5  # 连续亏损5 → LOCKED
    kill_lock_minutes_min: int = 10
    kill_lock_minutes_max: int = 30
    kill_daily_loss_pct: float = -0.02  # 日损 -2% STOP（-0.02）
    daily_loss_limit_usdt: float = 2.0  # configs/risk.yaml kill_switch.daily_loss_limit_usdt 2.0U（小账户）

    def to_dict(self) -> dict:
        return self.__dict__


@dataclass
class StopLossResult:
    """止损计算结果"""

    sl_pct: float  # 止损距离小数（如 0.002 = 0.20%）
    sl_price_long: float | None  # 多头止损价
    sl_price_short: float | None
    source: str  # 取值来源 invalidation / rv / pullback
    rejected: bool = False
    reject_reason: str = ""


@dataclass
class TakeProfitResult:
    """止盈计算结果"""

    tp_min: float  # TP_min 小数
    tp_pct: float  # 最终 TP 距离
    tp_price_long: float | None
    tp_price_short: float | None
    tiers: list[dict] | None = None  # 趋势分层 30/30/40
    source: str = ""  # tp_min / expected_move


@dataclass
class PositionContext:
    """持仓上下文（用于 TimeStop / Emergency / Trailing 判断）"""

    entry_price: float
    side: Literal["long", "short"]
    entry_ts: float  # 秒级时间戳
    size_usdt: float = 0.0
    stop_pct: float = 0.0
    tp_pct: float = 0.0
    expected_move: float = 0.0  # 入场时预期移动
    rv30: float = 0.0
    signal_type: SignalType = SignalType.MEAN_REVERSION


# ------------------------------------------------------------------------------
# 模块级便捷函数（任务要求 size_position(equity, stop_distance) 签名）
# ------------------------------------------------------------------------------
def size_position(
    equity: float,
    stop_distance: float,
    risk_budget: float = DEFAULT_RISK_BUDGET_USDT,
    exchange_limit: float = DEFAULT_EXCHANGE_NOTIONAL_LIMIT,
    equity_cap_multiple: float = 2.0,
) -> float:
    """计算名义价值（任务公式，不含合约取整）

    公式：notional = min(risk_budget / stop, equity*2, exchange_limit)
    - risk_budget：单笔风险预算 0.25U 示例（docs/05 §1）
    - stop_distance：止损距离小数（如 0.001 = 0.10%），必须 >0
    - equity_cap_multiple：权益倍数，默认 2.0（任务 equity*2）
    - exchange_limit：交易所单笔限额

    返回：名义价值 USDT（未按 lotSz 取整，取整请走 RiskEngine.size_position 或 position_sizer.calc_position）
    """
    if stop_distance <= 0:
        raise ValueError(f"stop_distance 非法 {stop_distance}")
    if risk_budget <= 0:
        return 0.0
    by_risk = risk_budget / stop_distance
    by_equity = float(equity) * float(equity_cap_multiple)
    return float(min(by_risk, by_equity, float(exchange_limit)))


def reject_trade(reason: RejectReason | str = RejectReason.SL_TOO_WIDE, detail: str = "") -> None:
    """拒绝交易（抛出异常，供策略层捕获）"""
    raise RejectTradeError(reason, detail)


# ------------------------------------------------------------------------------
# KillSwitch（连续亏损分级 + 日损熔断）
# ------------------------------------------------------------------------------
@dataclass
class KillSwitch:
    """熔断器 — 任务三档

    - 连续亏损3 → 减半 (HALVED, risk_scale=0.5)
    - 连续亏损5 → LOCKED 10-30min（根据亏损程度线性插值）
    - 日损 -2% → STOP（当日禁止开仓）

    状态机：NORMAL -> HALVED -> LOCKED -> STOPPED
    每笔交易后调用 on_trade_result(pnl)，每日调用 check_daily_loss
    """

    cfg: RiskConfig = field(default_factory=RiskConfig)
    consec_losses: int = 0
    state: KillState = KillState.NORMAL
    locked_until: float | None = None  # 时间戳秒
    daily_pnl: float = 0.0
    equity_start: float = 50.0  # 日初权益，用于计算日损%

    def _lock_minutes(self) -> int:
        """LOCK 时长 10-30min，按连续亏损次数线性插值（5次→10min，10次→30min）"""
        extra = max(0, self.consec_losses - self.cfg.kill_consec_lock)
        # 额外每多一次 +4min，上限 30min
        minutes = self.cfg.kill_lock_minutes_min + min(extra * 4, self.cfg.kill_lock_minutes_max - self.cfg.kill_lock_minutes_min)
        return int(minutes)

    def on_trade_result(self, pnl: float) -> None:
        """每笔平仓后更新"""
        self.daily_pnl += float(pnl)
        if pnl < 0:
            self.consec_losses += 1
        else:
            self.consec_losses = 0
            # 盈利后若处于 HALVED 则尝试恢复（需外部确认，或自动恢复至 NORMAL）
            if self.state == KillState.HALVED and self.consec_losses == 0:
                self.state = KillState.NORMAL
                logger.info(f"KillSwitch 盈利重置，恢复 NORMAL（consec_losses 清零）")
        # 状态跃迁
        if self.consec_losses >= self.cfg.kill_consec_lock:
            # 锁定
            if self.state != KillState.LOCKED:
                minutes = self._lock_minutes()
                self.locked_until = time.time() + minutes * 60
                self.state = KillState.LOCKED
                logger.warning(f"KillSwitch LOCKED {minutes}min（连续亏损 {self.consec_losses} 次）")
        elif self.consec_losses >= self.cfg.kill_consec_halve:
            if self.state == KillState.NORMAL:
                self.state = KillState.HALVED
                logger.warning(f"KillSwitch HALVED（连续亏损 {self.consec_losses} 次，仓位减半）")

    def check_daily_loss(self, equity_start: float | None = None) -> KillState | None:
        """检查日损是否触发 STOP（-2%）

        返回触发状态或 None
        - 优先按百分比判定（daily_pnl / equity_start <= -0.02）
        - 兼容按绝对值判定（daily_pnl <= -daily_loss_limit_usdt）
        """
        eq = float(equity_start) if equity_start is not None else float(self.equity_start)
        if eq <= 0:
            return None
        # 百分比
        daily_loss_pct = self.daily_pnl / eq
        if daily_loss_pct <= self.cfg.kill_daily_loss_pct:
            self.state = KillState.STOPPED
            logger.error(f"KillSwitch STOPPED 日损 {daily_loss_pct*100:.2f}% ({self.daily_pnl:.2f}U / {eq:.1f}U) 达阈值 {self.cfg.kill_daily_loss_pct*100:.0f}%")
            return KillState.STOPPED
        # 绝对值兜底（小账户 2U 场景）
        if self.daily_pnl <= -abs(self.cfg.daily_loss_limit_usdt):
            self.state = KillState.STOPPED
            logger.error(f"KillSwitch STOPPED 日损 {self.daily_pnl:.2f}U 达绝对阈值 {self.cfg.daily_loss_limit_usdt}U")
            return KillState.STOPPED
        return None

    def is_locked(self, now: float | None = None) -> bool:
        """是否处于 LOCKED 且未过期"""
        if self.state != KillState.LOCKED:
            return False
        if self.locked_until is None:
            return True
        now = float(now) if now is not None else time.time()
        if now >= self.locked_until:
            # 解锁，降级为 HALVED（仍需观察）
            self.state = KillState.HALVED
            self.locked_until = None
            logger.info("KillSwitch LOCKED 到期，降级为 HALVED")
            return False
        return True

    def get_risk_scale(self, now: float | None = None) -> float:
        """当前风险缩放系数"""
        # 先检查日损 STOP
        if self.state == KillState.STOPPED:
            return 0.0
        if self.is_locked(now):
            return 0.0
        if self.state == KillState.HALVED:
            return 0.5
        return 1.0

    def is_trading_allowed(self, now: float | None = None) -> tuple[bool, str]:
        """是否允许开新仓"""
        if self.state == KillState.STOPPED:
            return False, "日损熔断 STOP（-2%）"
        if self.is_locked(now):
            remain = int((self.locked_until - (now or time.time())) / 60) if self.locked_until else 0
            return False, f"LOCKED 剩余 {remain}min（连续亏损 {self.consec_losses}）"
        return True, "ok"

    def reset_daily(self, equity_start: float | None = None) -> None:
        """日切重置（每日开盘调用）"""
        self.daily_pnl = 0.0
        if equity_start is not None:
            self.equity_start = float(equity_start)
        # 若昨日 STOPPED，次日恢复为 NORMAL（需人工确认则可保留 STOPPED）
        if self.state == KillState.STOPPED:
            self.state = KillState.NORMAL
            self.consec_losses = 0
            self.locked_until = None
        logger.info(f"KillSwitch 日切重置 equity_start={self.equity_start}")

    def to_dict(self) -> dict:
        return {
            "state": self.state.value,
            "consec_losses": self.consec_losses,
            "locked_until": self.locked_until,
            "daily_pnl": self.daily_pnl,
            "equity_start": self.equity_start,
            "risk_scale": self.get_risk_scale(),
        }


# ------------------------------------------------------------------------------
# 风控引擎主类
# ------------------------------------------------------------------------------
class RiskEngine:
    """风控引擎 — 聚合仓位/止损/止盈/三类保护

    用法
    ```python
    cfg = RiskConfig(risk_budget_usdt=0.25)
    engine = RiskEngine(cfg, cost_engine=CostEngine(), spec=DEFAULT_ETH_SWAP)
    notional = engine.size_position(equity=50, stop_distance=0.002)
    sl = engine.calc_stop_loss(SignalType.TREND, signal_invalidation_pct=0.002, pullback_low_pct=0.003, rv30=0.001)
    tp = engine.calc_take_profit(expected_move=0.004, entry_type="maker", exit_type="maker", price=3000, side="long")
    ```
    """

    def __init__(
        self,
        config: RiskConfig | None = None,
        cost_engine: CostEngine | None = None,
        instrument_spec: InstrumentSpec | None = None,
        kill_switch: KillSwitch | None = None,
    ) -> None:
        self.config: RiskConfig = config or RiskConfig()
        # 成本引擎用于 TP_min 计算（若未传入则惰性创建）
        if cost_engine is not None:
            self.cost = cost_engine
        else:
            if CostEngine is not None:
                try:
                    self.cost = CostEngine()  # type: ignore
                except Exception:
                    self.cost = None  # type: ignore
            else:
                self.cost = None  # type: ignore
        # 合约规格用于数量取整与名义校验
        if instrument_spec is not None:
            self.spec = instrument_spec
        else:
            self.spec = DEFAULT_ETH_SWAP  # type: ignore
        self.kill: KillSwitch = kill_switch or KillSwitch(cfg=self.config, equity_start=50.0)

    # ------------------------------------------------------------------ #
    # 仓位：size_position（复用 position_sizer.calc_position）
    # ------------------------------------------------------------------ #
    def size_position(
        self,
        equity: float,
        stop_distance: float,
        price: float | None = None,
        risk_budget: float | None = None,
        risk_scale: float | None = None,
        equity_cap_multiple: float | None = None,
        exchange_limit: float | None = None,
    ) -> dict:
        """计算仓位（任务公式 + 合约取整）

        步骤（docs/05 §3）
        1. 理论名义 = risk_budget / stop_distance
        2. 上限 = min(理论名义, equity*equity_cap_multiple, exchange_limit)
        3. 按 lotSz 向下取整，校验 minSz
        4. 按 max_leverage 反推保证金，校验权益

        参数
        - equity: 账户权益 USDT
        - stop_distance: 止损距离小数（如 0.001 =0.10%），必须 >0（来自 calc_stop_loss）
        - price: 当前价格（用于张数换算，若无则仅返回名义）
        - risk_budget / risk_scale / equity_cap_multiple / exchange_limit：可覆盖，默认取 RiskConfig
        """
        # 熔断检查
        allowed, reason = self.kill.is_trading_allowed()
        if not allowed:
            return {"feasible": False, "reason": f"KillSwitch 禁止开仓: {reason}", "notional": 0.0}

        rb = float(risk_budget) if risk_budget is not None else float(self.config.risk_budget_usdt)
        # 风险缩放（HALVED 时 0.5，LOCKED/STOPPED 时 0）
        scale = float(risk_scale) if risk_scale is not None else float(self.kill.get_risk_scale())
        if scale <= 0:
            return {"feasible": False, "reason": "风险缩放为0（熔断/极端行情），停止开仓", "notional": 0.0}
        rb_scaled = rb * scale

        cap_mult = float(equity_cap_multiple) if equity_cap_multiple is not None else float(self.config.equity_cap_multiple)
        exch_lim = float(exchange_limit) if exchange_limit is not None else float(self.config.exchange_limit_usdt)

        # 任务公式快速估算（用于日志/快速校验）
        try:
            quick_notional = size_position(float(equity), float(stop_distance), rb_scaled, exch_lim, cap_mult)
        except Exception as e:
            return {"feasible": False, "reason": f"止损距离非法: {e}", "notional": 0.0}

        # 若未提供价格或无合约规格，仅返回快速估算
        if price is None or self.spec is None or _calc_position is None:
            return {
                "feasible": True,
                "reason": "可行（未按合约取整）",
                "notional": quick_notional,
                "risk_budget": rb_scaled,
                "risk_scale": scale,
                "quick_notional": quick_notional,
            }

        # 复用 position_sizer.calc_position 进行合约取整与保证金校验（与旧代码对齐）
        try:
            result = _calc_position(
                price=float(price),
                stop_pct=float(stop_distance),
                risk_budget_usdt=rb_scaled,
                spec=self.spec,  # type: ignore
                equity_usdt=float(equity),
                max_leverage=float(self.config.max_leverage),
                min_margin_usdt=float(self.config.min_margin_usdt),
                risk_scale=1.0,  # 已在 rb_scaled 中体现
            )
            # 额外施加 equity*2 与 exchange_limit 上限（calc_position 内部已部分约束，这里二次 clamp 以满足任务字面公式）
            capped_notional = min(result.notional_usdt, float(equity) * cap_mult, exch_lim)
            if capped_notional < result.notional_usdt - 1e-9:
                # 若被额外上限截断，需重新按 capped_notional 反推张数
                raw_size = capped_notional / (self.spec.ct_val * float(price)) if self.spec.ct_val else capped_notional / float(price)  # type: ignore
                size = self.spec.round_size(raw_size)  # type: ignore
                if not self.spec.is_valid_size(size):  # type: ignore
                    return {"feasible": False, "reason": f"数量 {size} < minSz {self.spec.min_sz}（上限截断后）", "notional": 0.0}
                notional = size * self.spec.ct_val * float(price)  # type: ignore
                return {
                    "feasible": True,
                    "reason": "可行（已按 equity*2/exchange_limit 截断）",
                    "notional": notional,
                    "size_contracts": size,
                    "risk_budget": rb_scaled,
                    "risk_scale": scale,
                    "quick_notional": quick_notional,
                    "sizing_result": result,
                }
            return {
                "feasible": result.feasible,
                "reason": result.reason,
                "notional": result.notional_usdt,
                "size_contracts": result.size_contracts,
                "leverage_needed": result.leverage_needed,
                "margin_needed": result.margin_needed,
                "risk_budget": rb_scaled,
                "risk_scale": scale,
                "quick_notional": quick_notional,
                "sizing_result": result,
            }
        except Exception as e:
            logger.error(f"size_position 异常: {e}")
            return {"feasible": False, "reason": f"仓位计算异常: {e}", "notional": 0.0}

    # ------------------------------------------------------------------ #
    # 止损 SL
    # ------------------------------------------------------------------ #
    def calc_stop_loss(
        self,
        signal_type: SignalType | str,
        signal_invalidation_pct: float | None = None,
        pullback_low_pct: float | None = None,
        rv30: float | None = None,
        price: float | None = None,
        side: Literal["long", "short"] = "long",
        max_sl_pct: float | None = None,
    ) -> StopLossResult:
        """计算止损距离

        逻辑（任务要求）
        - 通用：SL = max(signal_invalidation, 1.5*RV30)
        - 均值回归：signal_invalidation = 信号失效位（如布林带外/区间破位幅度）
        - 趋势：signal_invalidation 替换为 pullback_low（近期回撤低点/高点距离）

        参数
        - signal_type: MEAN_REVERSION | TREND
        - signal_invalidation_pct: 信号失效距离小数（必填于均值回归）
        - pullback_low_pct: 趋势回撤距离小数（必填于趋势）
        - rv30: 30s 已实现波动率小数（来源 microstructure vol_20 缩放，需 shift(1)）
        - max_sl_pct: 最大允许止损，超过则 reject_trade（默认 0.5%）

        返回 StopLossResult，若 rejected 则上层应放弃该笔
        """
        # 兼容 SignalType(str, Enum) 会使 isinstance(x, str) 为 True，需先判断 Enum 本体
        if isinstance(signal_type, SignalType):
            st = signal_type
        else:
            # 兼容外部传入的 Enum（有 .value）或纯字符串
            try:
                _val = signal_type.value if hasattr(signal_type, "value") else str(signal_type)  # type: ignore
            except Exception:
                _val = str(signal_type)
            st = SignalType.normalize(str(_val))
        rv = float(rv30) if rv30 is not None and rv30 > 0 else 0.0
        rv_component = self.config.rv_multiple_sl * rv if rv > 0 else 0.0
        max_sl = float(max_sl_pct) if max_sl_pct is not None else float(self.config.max_sl_pct)

        # 区分取值
        if st in (SignalType.TREND, SignalType.BREAKOUT):
            # 趋势：用 pullback_low，若未提供则回退到 signal_invalidation
            base = pullback_low_pct if pullback_low_pct is not None else signal_invalidation_pct
            source = "pullback_low"
            if base is None:
                # 无有效输入，至少用 RV 分量
                base = 0.0
                source = "rv_only"
        else:
            base = signal_invalidation_pct
            source = "signal_invalidation"
            if base is None:
                base = 0.0
                source = "rv_only"

        base = float(base) if base is not None else 0.0
        sl_pct = max(base, rv_component) if rv_component > 0 else base
        # 若仍为 0，说明输入缺失，标记非法
        if sl_pct <= 0:
            return StopLossResult(sl_pct=0.0, sl_price_long=None, sl_price_short=None, source=source, rejected=True, reject_reason="止损距离非法（需提供 signal_invalidation 或 pullback_low 或有效 RV30）")

        # 熔断：若 >MAX_SL 则 reject_trade
        if sl_pct > max_sl:
            # 按任务要求调用 reject_trade（这里返回 rejected 标记，调用方决定是否抛异常）
            logger.warning(f"止损 {sl_pct*1e4:.1f}bps > MAX_SL {max_sl*1e4:.1f}bps，拒绝交易（{st.value}）")
            return StopLossResult(sl_pct=sl_pct, sl_price_long=None, sl_price_short=None, source=source, rejected=True, reject_reason=f"SL {sl_pct:.5f} > MAX_SL {max_sl:.5f}")

        # 计算止损价
        sl_long = sl_short = None
        if price is not None and price > 0:
            if side == "long":
                sl_long = float(price) * (1 - sl_pct)
                sl_short = None
            else:
                sl_short = float(price) * (1 + sl_pct)
                sl_long = None
            # 按 tickSz 取整（若有 spec）
            if self.spec is not None:
                try:
                    if sl_long is not None:
                        sl_long = self.spec.round_price(sl_long)  # type: ignore
                    if sl_short is not None:
                        sl_short = self.spec.round_price(sl_short)  # type: ignore
                except Exception:
                    pass

        return StopLossResult(sl_pct=float(sl_pct), sl_price_long=sl_long, sl_price_short=sl_short, source=source, rejected=False)

    def check_stop_loss(self, *args, **kwargs) -> StopLossResult:
        """别名 calc_stop_loss"""
        return self.calc_stop_loss(*args, **kwargs)

    # ------------------------------------------------------------------ #
    # 止盈 TP
    # ------------------------------------------------------------------ #
    def calc_take_profit(
        self,
        expected_move: float,
        entry_type: str | bool = "maker",
        exit_type: str | bool = "maker",
        price: float | None = None,
        side: Literal["long", "short"] = "long",
        signal_type: SignalType | str = SignalType.MEAN_REVERSION,
        rv30: float | None = None,
    ) -> TakeProfitResult:
        """计算止盈（任务公式）

        TP_min = round_trip + execution + min_profit (Maker→Maker 0.08%)
            - round_trip：往返手续费（maker 0.04% / taker 0.10%）
            - execution：点差+滑点（由 CostEngine.total_cost 覆盖）
            - min_profit：安全垫后仍需盈利，统一归入 TP_min 0.08% 兜底
        TP = max(TP_min, 0.5*ExpectedMove)
            - 趋势分层 30%/30%/40% trailing：前两档固定止盈，第三档移动止损

        参数
        - expected_move: 预期移动小数（如 0.002 = 0.20%），来源信号 E[R_{30s/60s/180s}]
        - entry_type/exit_type: 决定 TP_min 档位（Maker→Maker 0.08% 为基准，Taker 更大）
        - signal_type: 若为 TREND 则返回分层 tiers
        """
        # TP_min：优先用 CostEngine.total_cost + min_net_edge 精确计算，否则用常量 0.08% 兜底
        if self.cost is not None:
            try:
                tp_min = self.cost.total_cost(entry_type, exit_type) + float(self.cost.min_net_edge)  # type: ignore
                # 至少不低于 Maker→Maker 0.08%（任务明确标注）
                tp_min = max(tp_min, float(self.config.tp_min_maker_maker))
            except Exception:
                tp_min = float(self.config.tp_min_maker_maker)
        else:
            # 简化：按费率档位估算
            is_maker_entry = str(entry_type).lower() in ("maker", "true", "1") or entry_type is True  # type: ignore
            is_maker_exit = str(exit_type).lower() in ("maker", "true", "1") or exit_type is True  # type: ignore
            if is_maker_entry and is_maker_exit:
                tp_min = float(self.config.tp_min_maker_maker)  # 0.08%
            elif is_maker_entry or is_maker_exit:
                tp_min = 0.0007 + 0.00008 + 0.00010  # 0.07% 往返 + 点差+缓冲 ≈0.088%
            else:
                tp_min = 0.0010 + 0.00008 + 0.00010  # 双 Taker 0.10% + 成本 ≈0.118%

        # TP = max(TP_min, 0.5*ExpectedMove)
        exp = float(expected_move) if expected_move is not None else 0.0
        tp_by_expected = self.config.tp_expected_ratio * exp if exp > 0 else 0.0
        tp_pct = max(tp_min, tp_by_expected)
        source = "expected_move" if tp_by_expected > tp_min else "tp_min"

        # 价格
        tp_long = tp_short = None
        if price is not None and price > 0:
            if side == "long":
                tp_long = float(price) * (1 + tp_pct)
            else:
                tp_short = float(price) * (1 - tp_pct)
            if self.spec is not None:
                try:
                    if tp_long is not None:
                        tp_long = self.spec.round_price(tp_long)  # type: ignore
                    if tp_short is not None:
                        tp_short = self.spec.round_price(tp_short)  # type: ignore
                except Exception:
                    pass

        # 趋势分层 30%/30%/40% trailing
        tiers: list[dict] | None = None
        if isinstance(signal_type, SignalType):
            st = signal_type
        else:
            try:
                _val2 = signal_type.value if hasattr(signal_type, "value") else str(signal_type)  # type: ignore
            except Exception:
                _val2 = str(signal_type)
            st = SignalType.normalize(str(_val2))
        if st in (SignalType.TREND, SignalType.BREAKOUT):
            # 三档：30% 仓位在 TP_pct*0.6 处，30% 在 TP_pct*1.0 处，40% trailing
            # 简化：按文档 tp_tiers 映射，这里显式实现 30/30/40
            tiers = [
                {"pct": 0.30, "price_long": float(price) * (1 + tp_pct * 0.6) if price and side == "long" else None, "price_short": float(price) * (1 - tp_pct * 0.6) if price and side == "short" else None, "type": "fixed", "ratio": 0.30},
                {"pct": 0.30, "price_long": float(price) * (1 + tp_pct * 1.0) if price and side == "long" else None, "price_short": float(price) * (1 - tp_pct * 1.0) if price and side == "short" else None, "type": "fixed", "ratio": 0.30},
                {"pct": 0.40, "price_long": None, "price_short": None, "type": "trailing", "ratio": 0.40, "trailing_pct": self.calc_trailing(rv30)},
            ]
            # 取整
            if self.spec is not None and price:
                try:
                    for t in tiers:
                        if t.get("price_long") is not None:
                            t["price_long"] = self.spec.round_price(t["price_long"])  # type: ignore
                        if t.get("price_short") is not None:
                            t["price_short"] = self.spec.round_price(t["price_short"])  # type: ignore
                except Exception:
                    pass

        return TakeProfitResult(tp_min=float(tp_min), tp_pct=float(tp_pct), tp_price_long=tp_long, tp_price_short=tp_short, tiers=tiers, source=source)

    def calc_trailing(self, rv30: float | None = None) -> float:
        """移动止损距离 = max(0.03%, 1.0*RV30)"""
        rv = float(rv30) if rv30 is not None and rv30 > 0 else 0.0
        trailing = max(float(self.config.trailing_base_pct), float(self.config.trailing_rv_multiple) * rv if rv > 0 else 0.0)
        # 若 rv 无效，至少返回基线 0.03%
        if trailing <= 0:
            trailing = float(self.config.trailing_base_pct)
        return float(trailing)

    # ------------------------------------------------------------------ #
    # 时间止损 & 异常
    # ------------------------------------------------------------------ #
    def check_time_stop(
        self,
        holding_s: float,
        expected_return: float | None = None,
        expected_thr: float | None = None,
        holding_thr_s: int | None = None,
    ) -> tuple[bool, str]:
        """时间止损判断

        规则：持仓>90s and expected<0.0003 (3bps) 则平
        - holding_s：持仓秒数
        - expected_return：当前预期收益（若为 None 则仅按时间判断，保守不触发）
        """
        thr_s = int(holding_thr_s) if holding_thr_s is not None else int(self.config.time_stop_s)
        thr_exp = float(expected_thr) if expected_thr is not None else float(self.config.time_stop_expected_thr)
        if holding_s > thr_s:
            if expected_return is not None and float(expected_return) < thr_exp:
                return True, f"TimeStop 持仓 {holding_s:.0f}s > {thr_s}s 且 expected {float(expected_return)*1e4:.1f}bps < {thr_exp*1e4:.1f}bps"
            # 若未提供 expected，保守不触发时间止损（需外部提供最新信号）
        return False, "ok"

    def check_time_stop_ctx(self, ctx: PositionContext, now_ts: float | None = None, current_expected: float | None = None) -> tuple[bool, str]:
        """基于 PositionContext 的 TimeStop"""
        now = float(now_ts) if now_ts is not None else time.time()
        holding = now - float(ctx.entry_ts)
        exp = current_expected if current_expected is not None else float(ctx.expected_move)
        # 若当前预期已衰减，则用当前值判断
        return self.check_time_stop(holding, exp)

    def check_emergency(self, signal_invalidation_score: float, thr: float | None = None) -> tuple[bool, str]:
        """异常紧急平仓：signal_invalidation_score > thr 则紧急平

        score 来源：信号失效度/模型置信度衰减/价格突破失效位距离，0~1 归一化
        thr 默认 configs 取 0.8（需 OOS 校准）
        """
        t = float(thr) if thr is not None else float(self.config.invalidation_thr)
        score = float(signal_invalidation_score)
        if score > t:
            return True, f"Emergency 信号失效 score {score:.3f} > thr {t:.3f} 紧急平仓"
        return False, "ok"

    # ------------------------------------------------------------------ #
    # 综合持仓管理（供 ExecutionEngine.manage_position 调用）
    # ------------------------------------------------------------------ #
    def manage_position(
        self,
        ctx: PositionContext,
        mark_price: float,
        now_ts: float | None = None,
        current_expected: float | None = None,
        signal_invalidation_score: float | None = None,
    ) -> dict:
        """综合判断持仓是否需要平仓（SL/TP/TimeStop/Emergency/Trailing）

        返回 dict: {action: 'hold'|'close', reason: str, details: {...}}
        - SL/TP 价格由调用方预先按 calc_stop_loss/calc_take_profit 生成并传入 ctx.stop_pct/tp_pct
        - 本方法仅基于 mark_price 与时间/预期/失效分进行触发判定
        """
        reasons: list[str] = []
        # 1. 紧急平仓（最高优先级）
        if signal_invalidation_score is not None:
            hit, msg = self.check_emergency(signal_invalidation_score)
            if hit:
                return {"action": "close", "reason": "emergency", "msg": msg, "details": {"score": signal_invalidation_score}}

        # 2. 止损触发
        # stop 距离为百分比，需根据方向判断
        if ctx.stop_pct and ctx.stop_pct > 0:
            if ctx.side == "long":
                stop_price = ctx.entry_price * (1 - ctx.stop_pct)
                if mark_price <= stop_price:
                    return {"action": "close", "reason": "stop_loss", "msg": f"SL 触发 {mark_price:.2f} <= {stop_price:.2f} ({ctx.stop_pct*1e4:.1f}bps)", "details": {"stop_price": stop_price}}
            else:
                stop_price = ctx.entry_price * (1 + ctx.stop_pct)
                if mark_price >= stop_price:
                    return {"action": "close", "reason": "stop_loss", "msg": f"SL 触发 {mark_price:.2f} >= {stop_price:.2f}", "details": {"stop_price": stop_price}}

        # 3. 止盈触发
        if ctx.tp_pct and ctx.tp_pct > 0:
            if ctx.side == "long":
                tp_price = ctx.entry_price * (1 + ctx.tp_pct)
                if mark_price >= tp_price:
                    # 趋势分层由上层处理，这里先标记 tp_hit
                    reasons.append(f"TP 触发 {mark_price:.2f} >= {tp_price:.2f}")
            else:
                tp_price = ctx.entry_price * (1 - ctx.tp_pct)
                if mark_price <= tp_price:
                    reasons.append(f"TP 触发 {mark_price:.2f} <= {tp_price:.2f}")

        # 4. 时间止损
        hit, msg = self.check_time_stop_ctx(ctx, now_ts, current_expected)
        if hit:
            return {"action": "close", "reason": "time_stop", "msg": msg, "details": {"holding_s": (now_ts or time.time()) - ctx.entry_ts}}

        # 5. 若 TP 已触发且非趋势分层 trailing 剩余，则平仓；否则继续持有
        # 简化：TP 触发即 close，具体分层减仓由 ExecutionEngine 处理
        if reasons:
            return {"action": "close", "reason": "take_profit", "msg": "; ".join(reasons), "details": {"tp_pct": ctx.tp_pct}}

        return {"action": "hold", "reason": "ok", "msg": "持有", "details": {}}

    # ------------------------------------------------------------------ #
    # 熔断便捷代理
    # ------------------------------------------------------------------ #
    def on_trade_close(self, pnl: float, mark_price: float | None = None) -> None:
        """平仓后更新熔断器"""
        self.kill.on_trade_result(float(pnl))

    def is_trading_allowed(self, now: float | None = None) -> tuple[bool, str]:
        return self.kill.is_trading_allowed(now)

    def get_risk_scale(self, now: float | None = None) -> float:
        return self.kill.get_risk_scale(now)

    def update_daily_pnl(self, daily_pnl: float, equity_start: float | None = None) -> KillState | None:
        """外部同步日盈亏后检查日损熔断"""
        self.kill.daily_pnl = float(daily_pnl)
        if equity_start is not None:
            self.kill.equity_start = float(equity_start)
        return self.kill.check_daily_loss()

    # ------------------------------------------------------------------ #
    # 兼容旧 RiskEngine 接口
    # ------------------------------------------------------------------ #
    def before_entry(self, **kwargs) -> bool:
        """兼容旧接口：开仓前检查"""
        allowed, _ = self.is_trading_allowed()
        return allowed

    def __repr__(self) -> str:
        return f"RiskEngine(budget={self.config.risk_budget_usdt}U, maxSL={self.config.max_sl_pct*1e4:.0f}bps, kill={self.kill.state.value})"

    # ------------------------------------------------------------------ #
    # 别名（兼容不同调用习惯与任务描述中的命名）
    # ------------------------------------------------------------------ #
    # 止损别名
    calc_sl = calc_stop_loss
    get_stop_loss = calc_stop_loss
    stop_loss = calc_stop_loss
    calculate_stop_loss = calc_stop_loss
    # 止盈别名
    calc_tp = calc_take_profit
    get_take_profit = calc_take_profit
    take_profit = calc_take_profit
    calculate_take_profit = calc_take_profit
    # 移动止损别名
    get_trailing = calc_trailing
    trailing_stop = calc_trailing
    # 时间止损/异常别名
    is_time_stop = check_time_stop
    time_stop = check_time_stop
    is_emergency = check_emergency
    emergency_stop = check_emergency
    # 仓位别名（与 position_sizer 复用）
    calculate_position = size_position


# 模块级别名（便于 from eth_hft.v1.risk import calc_stop_loss 等）
calc_sl = RiskEngine.calc_stop_loss  # type: ignore
calc_tp = RiskEngine.calc_take_profit  # type: ignore
