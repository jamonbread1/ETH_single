"""成本引擎 v1 — Selective Micro Scalper 成本闸门（Nautilus 可上线版）

职责
- 统一管理费率 / 点差 / 滑点 / 安全垫的成本分解
- 提供 round_trip_fee 与 net_edge 两大核心计算，严格按算法核心定义：
      net_edge = expected_return − entry_fee − exit_fee − spread_cost − slippage − safety_buffer
- 强制阈值 MIN_NET_EDGE 默认 1bps (0.0001)，可配置且必须标注【需样本外校准】

参数来源可追溯
- maker_fee 0.0002 / taker_fee 0.0005：OKX 官方永续普通用户费率（docs/03_cost_model.md §1，configs/config.example.yaml fees）
- spread_bps 0.8：历史 bbo-tbt 实测 spread/mid*1e4 中位数（docs/03 §2，configs/strategy.yaml cost.spread_bps）
- slippage_maker 0.6bps (0.00006) / slippage_taker 1.5bps (0.00015)：对话示例 + 可配置（docs/03 §2，src/eth_hft/core/fee_model.py FeeConfig）
- safety_buffer 1.0bps (0.00010)：75 分位数安全垫（同上）
- MIN_NET_EDGE 0.0001 (1bps)：对话最低预期阈值 max(成本, 6.4bps) 衍生，阈值本身需走样本外校准（docs/03 §3，docs/04_parameters.md §2/4 禁止拍脑子）
- min_edge_bps 1.5：configs/strategy.yaml cost.min_edge_bps，自然控频至 5~30 笔/天（docs/06 §5）

与旧代码对齐
- 复用语义与 src/eth_hft/core/fee_model.py 保持一致（round_trip / total_cost），本模块为 v1 独立演进，不直接继承但逻辑等价，便于 Nautilus 策略独立引入
- 单位统一用小数（非 bps），内部提供 _bps/_from_bps 转换，存储与配置文件 bps 互转

Nautilus 适配
- 纯 Python，不依赖 nautilus_trader 即可回测；若环境中存在 nautilus_trader，则可被 MicroScalperStrategy 直接注入
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

# 尝试 loguru，无则退化为标准 logging
try:
    from loguru import logger  # type: ignore
except Exception:  # pragma: no cover
    import logging as _logging

    logger = _logging.getLogger("eth_hft.v1.cost")  # type: ignore

# 订单类型字面量，大小写不敏感
OrderTypeStr = Literal["maker", "taker", "MAKER", "TAKER", "Maker", "Taker"]

# 默认阈值（需样本外校准）—— 对应任务要求 MIN_NET_EDGE 默认 0.0001
# 依据：docs/03 §3 阈值 = max(往返+点差+滑点+安全垫, 6.4bps)，仅当 net_edge > 1.5~3bps 才开仓
#      这里取保守下限 1bps 作为默认，策略层再按 OOS 校准覆盖（见 CostConfig.min_net_edge 注释）
DEFAULT_MIN_NET_EDGE: float = 0.0001  # 1bps
MIN_NET_EDGE: float = DEFAULT_MIN_NET_EDGE  # 模块级别名，保持与任务描述一致

# OKX 官方默认费率（来源 docs/03 §1）
DEFAULT_MAKER_FEE: float = 0.0002
DEFAULT_TAKER_FEE: float = 0.0005
# 默认成本项（来源 docs/03 §2，configs/strategy.yaml）
DEFAULT_SPREAD_COST: float = 0.00008      # 0.8bps
DEFAULT_SLIPPAGE_MAKER: float = 0.00006   # 0.6bps
DEFAULT_SLIPPAGE_TAKER: float = 0.00015   # 1.5bps
DEFAULT_SAFETY_BUFFER: float = 0.00010    # 1.0bps


def _bps(x: float) -> float:
    """小数 -> bps (1bps = 0.01%)"""
    return x * 1e4


def _from_bps(bps: float) -> float:
    """bps -> 小数"""
    return bps / 1e4


def _normalize_order_type(t: str | bool | None) -> str:
    """归一化订单类型为 'maker' | 'taker'，兼容 bool/字符串大小写"""
    if isinstance(t, bool):
        return "maker" if t else "taker"
    if t is None:
        return "maker"
    s = str(t).strip().lower()
    if s in ("maker", "m", "post_only", "post-only", "postonly", "limit_maker"):
        return "maker"
    if s in ("taker", "t", "market", "marketable", "ioc", "fok"):
        return "taker"
    # 默认按 maker 处理并告警
    logger.warning(f"未知订单类型 '{t}' 按 maker 处理")
    return "maker"


@dataclass
class CostConfig:
    """成本配置（可序列化，便于 configs/strategy.yaml 注入）

    属性
    - maker_fee / taker_fee：来源 OKX 官方 0.02%/0.05%
    - spread_cost：历史 bbo 点差中位数，单位小数（默认 0.00008 = 0.8bps）
    - slippage_maker / slippage_taker：Maker 0.6bps / Taker 1.5bps
    - slippage：统一滑点覆盖值，若设置则忽略 maker/taker 区分，优先使用该值（便于任务描述中 slippage 单参对齐）
    - safety_buffer：安全垫 1.0bps
    - min_net_edge：最低净边际，默认 1bps【需样本外校准】（见 docs/04 §4 变更流程）
        * 警示：禁止凭经验写死，必须通过 scripts/20_evaluate_factors.py Walk-Forward 与 scripts/30_run_backtest.py 在 OOS 上校准后写入 configs
    """

    maker_fee: float = DEFAULT_MAKER_FEE
    taker_fee: float = DEFAULT_TAKER_FEE
    spread_cost: float = DEFAULT_SPREAD_COST
    slippage: float | None = None  # 统一滑点，若非 None 则覆盖 maker/taker 区分
    slippage_maker: float = DEFAULT_SLIPPAGE_MAKER
    slippage_taker: float = DEFAULT_SLIPPAGE_TAKER
    safety_buffer: float = DEFAULT_SAFETY_BUFFER
    # 最低净边际，默认 1bps，需样本外校准（见类注释）
    min_net_edge: float = DEFAULT_MIN_NET_EDGE  # 【需样本外校准】OOS 校准前勿直接用于实盘放大

    def to_dict(self) -> dict:
        return {
            "maker_fee": self.maker_fee,
            "taker_fee": self.taker_fee,
            "spread_cost": self.spread_cost,
            "slippage": self.slippage,
            "slippage_maker": self.slippage_maker,
            "slippage_taker": self.slippage_taker,
            "safety_buffer": self.safety_buffer,
            "min_net_edge": self.min_net_edge,
            "min_net_edge_bps": _bps(self.min_net_edge),
        }

    @classmethod
    def from_bps(
        cls,
        maker_fee: float = DEFAULT_MAKER_FEE,
        taker_fee: float = DEFAULT_TAKER_FEE,
        spread_bps: float = 0.8,
        slippage_maker_bps: float = 0.6,
        slippage_taker_bps: float = 1.5,
        safety_buffer_bps: float = 1.0,
        min_net_edge_bps: float = 1.0,  # 1bps 需样本外校准
    ) -> "CostConfig":
        """以 bps 为单位构造（便于直接对接 configs/strategy.yaml 的 bps 配置）"""
        return cls(
            maker_fee=maker_fee,
            taker_fee=taker_fee,
            spread_cost=_from_bps(spread_bps),
            slippage_maker=_from_bps(slippage_maker_bps),
            slippage_taker=_from_bps(slippage_taker_bps),
            safety_buffer=_from_bps(safety_buffer_bps),
            min_net_edge=_from_bps(min_net_edge_bps),
        )


class CostEngine:
    """成本引擎

    示例
    ```python
    engine = CostEngine()  # 默认 OKX 费率 + 实测成本
    fee = engine.round_trip_fee("maker", "maker")  # 0.0004
    edge = engine.net_edge(0.001, "maker", "maker")  # 0.001 - 0.0004 - 0.00008 - 0.00006 - 0.00010
    ok = engine.passes(0.001, "maker", "maker")
    ```

    设计约束
    - 所有费率/成本均为小数（0.0001 = 1bps），与 OKX/Nautilus 保持一致
    - round_trip_fee 仅含手续费；net_edge 含手续费+点差+滑点+安全垫，严格按任务公式
    - MIN_NET_EDGE 可通过实例 min_net_edge 覆盖，模块常量保留用于文档追溯
    """

    # 类级别默认阈值（需样本外校准）
    MIN_NET_EDGE: float = DEFAULT_MIN_NET_EDGE

    def __init__(
        self,
        maker_fee: float = DEFAULT_MAKER_FEE,
        taker_fee: float = DEFAULT_TAKER_FEE,
        spread_cost: float = DEFAULT_SPREAD_COST,
        slippage: float | None = None,
        slippage_maker: float = DEFAULT_SLIPPAGE_MAKER,
        slippage_taker: float = DEFAULT_SLIPPAGE_TAKER,
        safety_buffer: float = DEFAULT_SAFETY_BUFFER,
        min_net_edge: float = DEFAULT_MIN_NET_EDGE,
        # 兼容任务描述中 spread/slippage/safety_buffer 简写
        spread: float | None = None,
        safety_buffer_bps: float | None = None,  # 若传入则覆盖
        min_edge_bps: float | None = None,
    ) -> None:
        """
        参数
        - maker_fee: Maker 费率小数，默认 0.0002（OKX 官方）
        - taker_fee: Taker 费率小数，默认 0.0005
        - spread_cost / spread: 点差成本小数，默认 0.00008（0.8bps，历史 bbo 中位数）
        - slippage: 统一滑点（若设置则覆盖 maker/taker 区分）
        - slippage_maker / slippage_taker: 分档滑点，默认 0.6bps/1.5bps
        - safety_buffer: 安全垫，默认 0.00010（1.0bps）
        - min_net_edge: 最低净边际，默认 0.0001 (1bps)【需样本外校准】

        兼容
        - spread 作为 spread_cost 别名
        - safety_buffer_bps 若提供则覆盖 safety_buffer
        - min_edge_bps 若提供则覆盖 min_net_edge
        """
        # 别名处理
        if spread is not None:
            spread_cost = spread
        if safety_buffer_bps is not None:
            safety_buffer = _from_bps(safety_buffer_bps)
        if min_edge_bps is not None:
            min_net_edge = _from_bps(min_edge_bps)

        self.maker_fee: float = float(maker_fee)
        self.taker_fee: float = float(taker_fee)
        self.spread_cost: float = float(spread_cost)
        self.slippage: float | None = float(slippage) if slippage is not None else None
        self.slippage_maker: float = float(slippage_maker)
        self.slippage_taker: float = float(slippage_taker)
        self.safety_buffer: float = float(safety_buffer)
        # 实例级阈值（需 OOS 校准），保留类常量可追溯
        self.min_net_edge: float = float(min_net_edge)

        # 基础校验（防拍脑子）
        for name, val in [
            ("maker_fee", self.maker_fee),
            ("taker_fee", self.taker_fee),
            ("spread_cost", self.spread_cost),
            ("safety_buffer", self.safety_buffer),
            ("min_net_edge", self.min_net_edge),
        ]:
            if val < 0 or val > 0.05:
                raise ValueError(f"{name}={val} 非法，需在 [0, 0.05] 内")

    # ------------------------------------------------------------------ #
    # 内部辅助
    # ------------------------------------------------------------------ #
    def _fee_for(self, order_type: str | bool | None) -> float:
        """根据订单类型返回单边费率"""
        t = _normalize_order_type(order_type)
        return self.maker_fee if t == "maker" else self.taker_fee

    def _effective_slippage(self, exit_type: str | bool | None, override: float | None = None) -> float:
        """确定有效滑点：override > 统一 slippage > 分档 maker/taker"""
        if override is not None:
            return float(override)
        if self.slippage is not None:
            return float(self.slippage)
        t = _normalize_order_type(exit_type)
        return self.slippage_maker if t == "maker" else self.slippage_taker

    def _effective_spread(self, override: float | None) -> float:
        return float(override) if override is not None else float(self.spread_cost)

    def _effective_buffer(self, override: float | None) -> float:
        return float(override) if override is not None else float(self.safety_buffer)

    # ------------------------------------------------------------------ #
    # 核心 API（按任务描述实现）
    # ------------------------------------------------------------------ #
    def round_trip_fee(
        self,
        entry_type: str | bool = "maker",
        exit_type: str | bool = "maker",
        *args,
        **kwargs,
    ) -> float:
        """往返手续费（仅手续费，不含点差/滑点/安全垫）

        参数
        - entry_type: 入场订单类型 'maker'|'taker' 或 bool(True=maker)
        - exit_type: 出场订单类型
        - 兼容别名：entry/exit（任务描述 round_trip_fee(entry,exit)），spread/slippage 透传忽略

        返回
        - 小数费率，如双 Maker 0.0004，双 Taker 0.001

        来源：OKX 官方 Maker 0.02% Taker 0.05%，往返双 Maker 0.04%（docs/03 §1）
        """
        # 兼容任务描述的 entry/exit 命名（kwargs 形式）
        if "entry" in kwargs:
            entry_type = kwargs.pop("entry")
        if "exit" in kwargs:
            exit_type = kwargs.pop("exit")
        # 兼容位置参数形式的别名（若调用为 round_trip_fee(entry, exit) 且 entry_type 已被占用）
        # 位置参数已通过 entry_type/exit_type 接收，无需额外处理
        # 额外兼容：若传入 entry_type 为 None 且 kwargs 含 entry_type 的别名
        if entry_type is None and "entry_type" in kwargs:
            entry_type = kwargs.pop("entry_type")
        if exit_type is None and "exit_type" in kwargs:
            exit_type = kwargs.pop("exit_type")
        entry_fee = self._fee_for(entry_type)
        exit_fee = self._fee_for(exit_type)
        return entry_fee + exit_fee

    def round_trip_fee_bps(self, entry_type: str | bool = "maker", exit_type: str | bool = "maker", **kwargs) -> float:
        """往返手续费 bps（兼容 entry/exit 别名）"""
        if "entry" in kwargs:
            entry_type = kwargs.pop("entry")
        if "exit" in kwargs:
            exit_type = kwargs.pop("exit")
        return _bps(self.round_trip_fee(entry_type, exit_type))

    def net_edge(
        self,
        expected_return: float | None = None,
        entry_type: str | bool = "maker",
        exit_type: str | bool = "maker",
        spread_cost: float | None = None,
        slippage: float | None = None,
        safety_buffer: float | None = None,
        *args,
        **kwargs,
    ) -> float:
        """净边际（核心公式）

        公式（任务严格要求）：
            net_edge = expected_return − entry_fee − exit_fee − spread_cost − slippage − safety_buffer

        参数
        - expected_return: 预期毛收益小数（如 0.001 = 0.10%）
        - entry_type / exit_type: 订单类型，影响 entry_fee/exit_fee 与默认 slippage 分档
        - spread_cost: 点差成本覆盖（None 则用实例默认值 0.00008）
        - slippage: 滑点覆盖（None 则按 exit_type 自动选 maker/taker 档）
        - safety_buffer: 安全垫覆盖（None 则用 0.00010）
        - 兼容别名：entry/exit、spread、expected、expected_return（位置/关键字均可）

        返回
        - 净边际小数，可正可负，若 > min_net_edge 则视为可交易
        """
        # 兼容部分调用方将 expected_return 作为第一位置参数后紧跟 entry/exit 的别名形式
        # 以及 kwargs 别名 entry/exit/spread 等
        if expected_return is None:
            # 尝试从 kwargs 或 args 中解析
            for k in ("expected_return", "expected", "gross", "expected_gross_return"):
                if k in kwargs:
                    expected_return = kwargs.pop(k)
                    break
            if expected_return is None and args:
                expected_return = args[0]
        if expected_return is None:
            raise TypeError("net_edge 缺少 expected_return 参数")
        # 别名映射
        if "entry" in kwargs:
            entry_type = kwargs.pop("entry")
        if "exit" in kwargs:
            exit_type = kwargs.pop("exit")
        if "spread" in kwargs and spread_cost is None:
            spread_cost = kwargs.pop("spread")
        if "spread_cost" in kwargs and spread_cost is None:
            spread_cost = kwargs.pop("spread_cost")
        if "safety_buffer" in kwargs and safety_buffer is None:
            safety_buffer = kwargs.pop("safety_buffer")
        # 兼容 safety_buffer_bps 形式
        if "safety_buffer_bps" in kwargs:
            safety_buffer = _from_bps(float(kwargs.pop("safety_buffer_bps")))
        entry_fee = self._fee_for(entry_type)
        exit_fee = self._fee_for(exit_type)
        eff_spread = self._effective_spread(spread_cost)
        eff_slippage = self._effective_slippage(exit_type, slippage)
        eff_buffer = self._effective_buffer(safety_buffer)
        return float(expected_return) - entry_fee - exit_fee - eff_spread - eff_slippage - eff_buffer

    def net_edge_bps(
        self,
        expected_return: float,
        entry_type: str | bool = "maker",
        exit_type: str | bool = "maker",
        spread_cost: float | None = None,
        slippage: float | None = None,
        safety_buffer: float | None = None,
    ) -> float:
        """净边际 bps"""
        return _bps(
            self.net_edge(expected_return, entry_type, exit_type, spread_cost, slippage, safety_buffer)
        )

    def passes(
        self,
        expected_return: float,
        entry_type: str | bool = "maker",
        exit_type: str | bool = "maker",
        spread_cost: float | None = None,
        slippage: float | None = None,
        safety_buffer: float | None = None,
        min_net_edge: float | None = None,
    ) -> bool:
        """是否通过成本过滤

        判定：net_edge > min_net_edge
        - min_net_edge 默认取实例值 0.0001 (1bps)，但需样本外校准（docs/04 §4）
        - 上层可按 OOS 扫描 1.0~3.0bps 后覆盖

        返回：True 可开仓，False 过滤
        """
        thr = float(min_net_edge) if min_net_edge is not None else float(self.min_net_edge)
        edge = self.net_edge(expected_return, entry_type, exit_type, spread_cost, slippage, safety_buffer)
        return edge > thr

    # 别名：与 fee_model.passes_cost_filter 语义对齐
    def passes_cost_filter(
        self,
        expected_return: float,
        entry_type: str | bool = "maker",
        exit_type: str | bool = "maker",
        **kwargs,
    ) -> bool:
        return self.passes(expected_return, entry_type, exit_type, **kwargs)

    def total_cost(
        self,
        entry_type: str | bool = "maker",
        exit_type: str | bool = "maker",
        spread_cost: float | None = None,
        slippage: float | None = None,
        safety_buffer: float | None = None,
    ) -> float:
        """总成本 = 往返手续费 + 点差 + 滑点 + 安全垫（即 net_edge 中扣除项之和）"""
        fee = self.round_trip_fee(entry_type, exit_type)
        eff_spread = self._effective_spread(spread_cost)
        eff_slippage = self._effective_slippage(exit_type, slippage)
        eff_buffer = self._effective_buffer(safety_buffer)
        return fee + eff_spread + eff_slippage + eff_buffer

    def required_gross_return(
        self,
        entry_type: str | bool = "maker",
        exit_type: str | bool = "maker",
        spread_cost: float | None = None,
        slippage: float | None = None,
        safety_buffer: float | None = None,
        min_net_edge: float | None = None,
    ) -> float:
        """达到阈值所需的最低毛收益 = 总成本 + min_net_edge"""
        thr = float(min_net_edge) if min_net_edge is not None else float(self.min_net_edge)
        return self.total_cost(entry_type, exit_type, spread_cost, slippage, safety_buffer) + thr

    def required_move_usdt(
        self,
        notional: float,
        entry_type: str | bool = "maker",
        exit_type: str | bool = "maker",
        **kwargs,
    ) -> float:
        """所需价格移动 USDT 绝对值 = 名义 * required_gross_return"""
        return float(notional) * self.required_gross_return(entry_type, exit_type, **kwargs)

    def breakdown(
        self,
        expected_return: float,
        entry_type: str | bool = "maker",
        exit_type: str | bool = "maker",
        spread_cost: float | None = None,
        slippage: float | None = None,
        safety_buffer: float | None = None,
    ) -> dict:
        """成本分解（用于日志/报表/校准分析）"""
        entry_fee = self._fee_for(entry_type)
        exit_fee = self._fee_for(exit_type)
        eff_spread = self._effective_spread(spread_cost)
        eff_slippage = self._effective_slippage(exit_type, slippage)
        eff_buffer = self._effective_buffer(safety_buffer)
        edge = float(expected_return) - entry_fee - exit_fee - eff_spread - eff_slippage - eff_buffer
        return {
            "expected_return": float(expected_return),
            "expected_bps": _bps(float(expected_return)),
            "entry_type": _normalize_order_type(entry_type),
            "exit_type": _normalize_order_type(exit_type),
            "entry_fee": entry_fee,
            "exit_fee": exit_fee,
            "round_trip_fee": entry_fee + exit_fee,
            "round_trip_bps": _bps(entry_fee + exit_fee),
            "spread_cost": eff_spread,
            "spread_bps": _bps(eff_spread),
            "slippage": eff_slippage,
            "slippage_bps": _bps(eff_slippage),
            "safety_buffer": eff_buffer,
            "buffer_bps": _bps(eff_buffer),
            "total_cost": entry_fee + exit_fee + eff_spread + eff_slippage + eff_buffer,
            "total_cost_bps": _bps(entry_fee + exit_fee + eff_spread + eff_slippage + eff_buffer),
            "net_edge": edge,
            "net_edge_bps": _bps(edge),
            "min_net_edge": float(self.min_net_edge),
            "min_net_edge_bps": _bps(float(self.min_net_edge)),
            "passes": edge > float(self.min_net_edge),
        }

    # 兼容旧接口
    def expected_net_edge(self, *args, **kwargs) -> float:
        """别名 net_edge，兼容 src/eth_hft/core/fee_model.expected_net_edge"""
        return self.net_edge(*args, **kwargs)

    def __repr__(self) -> str:
        return (
            f"CostEngine(maker={self.maker_fee:.4f}, taker={self.taker_fee:.4f}, "
            f"spread={self.spread_cost:.5f}, slip_m={self.slippage_maker:.5f}, "
            f"slip_t={self.slippage_taker:.5f}, buffer={self.safety_buffer:.5f}, "
            f"min_edge={self.min_net_edge:.5f}({_bps(self.min_net_edge):.2f}bps))"
        )


# 向后兼容别名：FeeConfig -> CostConfig (for shim)
FeeConfig = CostConfig  # type: ignore
