"""数据层 v1：统一市场状态管理（Selective Micro Scalper 专用）

设计目标：
- 承接 OKX WebSocket 三类原始数据：1m Bar、Trades、BBO
- 维护固定窗口：300 根 1m Bar（约 5 小时）、最近 180 秒 Trades（deque 50000）、BBO 最新 1 条
- 所有时间戳统一为毫秒 int（UTC ms），与 Nautilus 事件时序对齐
- 严格防御未来函数：所有查询必须带 decision_ts，且仅返回 ts <= decision_ts 的数据
- 提供 is_healthy 数据中断检测，供杀开关与 Regime 熔断调用
- 可被 Nautilus 策略、回测、实盘统一调用（无重量依赖，仅 Python 标准库 + dataclass）

时间语义：
- Bar.ts：该 1m Bar 的 close_time（毫秒），代表该 Bar 已完成时刻
- Trade.ts：逐笔成交时间（毫秒）
- BBO.ts：盘口快照时间（毫秒）
- decision_ts：策略决策时刻（毫秒），所有特征计算的右边界，特征的 source_end_ts 必须 <= decision_ts

线程安全：家用 PC 单线程事件驱动，无需锁；若多线程调用需外部加锁。
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Deque, Literal, Optional

# ==============================================================================
# 1. 基础数据结构（@dataclass，三类原始数据）
# ==============================================================================


@dataclass(frozen=True, slots=True)
class Bar:
    """1 分钟 K 线（已完成 Bar）

    属性：
        ts: Bar 结束时间（毫秒，UTC ms），即该 1m 的 close_time
        open/high/low/close: OHLC 价格
        volume: 成交量（基础货币数量或合约张数对应的成交额，取决于上游归一化）

    约束：
        - ts 必须为正整数毫秒
        - high >= low, high >= open/close, low <= open/close（弱校验，异常数据打日志但不抛错以保可用）
    """

    ts: int  # 毫秒
    open: float
    high: float
    low: float
    close: float
    volume: float

    def __post_init__(self) -> None:
        # 防御非法时间戳与价格
        if not isinstance(self.ts, int) or self.ts <= 0:
            raise ValueError(f"Bar.ts 非法: {self.ts}")
        # 价格/成交量 NaN/Inf 检测
        for name in ("open", "high", "low", "close", "volume"):
            v = getattr(self, name)
            if not isinstance(v, (int, float)):
                raise ValueError(f"Bar.{name} 类型非法: {v!r}")


@dataclass(frozen=True, slots=True)
class Trade:
    """逐笔成交

    属性：
        ts: 成交时间（毫秒）
        price: 成交价格
        qty: 成交数量（基础货币数量）
        side: 主动方向，buy=主动买（吃卖单）、sell=主动卖（吃买单）、unknown=未知

    来源：OKX trades 频道，side 由 OKX side 字段映射
    """

    ts: int
    price: float
    qty: float
    side: Literal["buy", "sell", "unknown"]

    def __post_init__(self) -> None:
        if not isinstance(self.ts, int) or self.ts <= 0:
            raise ValueError(f"Trade.ts 非法: {self.ts}")
        if self.side not in ("buy", "sell", "unknown"):
            raise ValueError(f"Trade.side 非法: {self.side}")


@dataclass(frozen=True, slots=True)
class BBO:
    """最优买卖一档（Best Bid/Offer）

    属性：
        ts: 快照时间（毫秒）
        bid: 最优买价
        ask: 最优卖价
        bid_size: 买一数量
        ask_size: 卖一数量

    衍生：
        mid = (bid+ask)/2
        spread = ask - bid
        spread_bps = spread / mid * 1e4
    """

    ts: int
    bid: float
    ask: float
    bid_size: float
    ask_size: float

    def __post_init__(self) -> None:
        if not isinstance(self.ts, int) or self.ts <= 0:
            raise ValueError(f"BBO.ts 非法: {self.ts}")
        if self.bid <= 0 or self.ask <= 0:
            raise ValueError(f"BBO 买卖价非法: bid={self.bid} ask={self.ask}")

    @property
    def mid(self) -> float:
        """中间价 mid = (bid+ask)/2"""
        return (self.bid + self.ask) / 2.0

    @property
    def spread(self) -> float:
        """绝对价差"""
        return self.ask - self.bid

    @property
    def spread_bps(self) -> float:
        """相对价差（bps），(ask-bid)/mid * 1e4"""
        m = self.mid
        if m == 0:
            return 0.0
        return self.spread / m * 1e4


# ==============================================================================
# 2. 聚合状态 MarketState（维护三类数据的时序窗口）
# ==============================================================================


@dataclass
class HealthStatus:
    """健康检查详情，供日志与熔断判定

    healthy: 是否健康
    reason: 不健康原因（健康时为 "ok"）
    last_bar_age_ms / last_bbo_age_ms / last_trade_age_ms: 各类数据距 decision_ts 的延迟
    bar_count / trade_count: 当前窗口内数量
    """

    healthy: bool
    reason: str
    last_bar_age_ms: Optional[int] = None
    last_bbo_age_ms: Optional[int] = None
    last_trade_age_ms: Optional[int] = None
    bar_count: int = 0
    trade_count: int = 0
    bbo_exists: bool = False


class MarketState:
    """市场状态聚合器（核心数据容器）

    维护：
        - 300 根 1m Bar：deque(maxlen=300)
        - Trades 最近 180 秒：deque(maxlen=50000)，超出 180s 的旧数据在写入与查询时惰性剔除
        - BBO 最新 1 条：单例保存，旧 BBO 直接覆盖

    未来函数防御：
        - 所有查询方法强制要求 decision_ts（若不传则取当前最新数据的时间最大值作为决策时刻）
        - 内部通过 _filter_* 只返回 ts <= decision_ts 的数据
        - price_at_or_before 等方法计算目标时刻 target = decision_ts - seconds*1000，再在历史中找 <= target 的最新价格

    可被 Nautilus 策略调用方式：
        state = MarketState()
        state.update_bar(Bar(...))
        state.update_trade(Trade(...))
        state.update_bbo(BBO(...))
        if not state.is_healthy(decision_ts):
            return  # 熔断
        price = state.price_at_or_before(10, decision_ts)
    """

    # 健康阈值（家用 PC 场景，可按需调参）
    MAX_BAR_DELAY_MS: int = 120_000  # 1m Bar 最长允许 120s 无更新（正常 60s 一根，容忍网络抖动）
    MAX_BBO_DELAY_MS: int = 10_000  # BBO 最长 10s 无更新即视为中断
    MAX_TRADE_DELAY_MS: int = 60_000  # Trades 若 60s 无新成交（极端低波动）仅告警，不直接判不健康（由调用方决定）
    TRADE_WINDOW_MS: int = 180_000  # Trades 窗口 180 秒

    def __init__(self) -> None:
        # 使用 deque 实现固定长度环形缓冲，O(1) 追加与淘汰
        self.bars: Deque[Bar] = deque(maxlen=300)  # 300 根 1m Bar，约 5 小时
        self.trades: Deque[Trade] = deque(maxlen=50_000)  # 50000 笔上限，实际受 180s 窗口约束
        self._bbo: Optional[BBO] = None  # BBO 仅保留最新 1 条

    # ------------------------------------------------------------------
    # 写入接口（由 WebSocket 回调或回测回放驱动）
    # ------------------------------------------------------------------

    def update_bar(self, bar: Bar) -> None:
        """追加 1m Bar（仅接受已完成的 Bar）

        - 自动按 ts 单调校验：若新 Bar ts <= 队尾 Bar ts，视为乱序/重复，丢弃或按序插入
        - 实际采用最简策略：乱序 Bar 直接丢弃并告警（保证窗口单调）
        """
        if self.bars and bar.ts <= self.bars[-1].ts:
            # 乱序或重复，丢弃（回测中可能因重放顺序问题触发）
            # 为避免刷日志，仅在必要时可接入 loguru
            return
        self.bars.append(bar)

    def update_trade(self, trade: Trade) -> None:
        """追加逐笔成交，并惰性剔除超出 180s 窗口的旧数据

        - 剔除策略：以最新 trade.ts 为基准，队首早于 180s 的全部弹出
        - 若乱序（新 trade.ts < 队尾），仍追加但后续查询会按 decision_ts 过滤，不影响正确性
        """
        self.trades.append(trade)
        # 惰性淘汰：以最新 ts 为基准，剔除队首过期数据
        cutoff = trade.ts - self.TRADE_WINDOW_MS
        while self.trades and self.trades[0].ts < cutoff:
            self.trades.popleft()

    def update_bbo(self, bbo: BBO) -> None:
        """更新 BBO（仅保留最新 1 条，旧值直接覆盖）

        - 若新 BBO ts < 旧 BBO ts，视为乱序，丢弃
        """
        if self._bbo is not None and bbo.ts < self._bbo.ts:
            return
        self._bbo = bbo

    # ------------------------------------------------------------------
    # 内部辅助：未来函数防御过滤
    # ------------------------------------------------------------------

    def _bars_le(self, decision_ts: int) -> list[Bar]:
        """返回所有 ts <= decision_ts 的 Bar（已按 ts 升序）"""
        # deque 本身有序，直接线性过滤（300 根，开销可忽略）
        return [b for b in self.bars if b.ts <= decision_ts]

    def _trades_le(self, decision_ts: int) -> list[Trade]:
        """返回所有 ts <= decision_ts 且在 [decision_ts-180s, decision_ts] 内的 Trade"""
        # 先按 decision_ts 过滤未来，再按 180s 窗口
        cutoff = decision_ts - self.TRADE_WINDOW_MS
        return [t for t in self.trades if cutoff <= t.ts <= decision_ts]

    def _bbo_le(self, decision_ts: int) -> Optional[BBO]:
        """返回 ts <= decision_ts 的最新 BBO，否则 None"""
        if self._bbo is None:
            return None
        if self._bbo.ts <= decision_ts:
            return self._bbo
        return None

    def _resolve_decision_ts(self, decision_ts: Optional[int]) -> Optional[int]:
        """若外部未传 decision_ts，则取三类数据中最大 ts 作为决策时刻

        - 适用于单测或简化调用；实盘/回测应显式传入事件时间
        """
        if decision_ts is not None:
            return decision_ts
        candidates: list[int] = []
        if self.bars:
            candidates.append(self.bars[-1].ts)
        if self.trades:
            candidates.append(self.trades[-1].ts)
        if self._bbo is not None:
            candidates.append(self._bbo.ts)
        if not candidates:
            return None
        return max(candidates)

    # ------------------------------------------------------------------
    # 查询接口（全部防御未来函数）
    # ------------------------------------------------------------------

    def get_bars(self, decision_ts: Optional[int] = None) -> list[Bar]:
        """获取决策时刻可见的全部 Bar（ts <= decision_ts）"""
        dts = self._resolve_decision_ts(decision_ts)
        if dts is None:
            return []
        return self._bars_le(dts)

    def get_trades(self, decision_ts: Optional[int] = None) -> list[Trade]:
        """获取决策时刻可见的全部 Trades（180s 窗口内且 ts <= decision_ts）"""
        dts = self._resolve_decision_ts(decision_ts)
        if dts is None:
            return []
        return self._trades_le(dts)

    def get_bbo(self, decision_ts: Optional[int] = None) -> Optional[BBO]:
        """获取决策时刻可见的最新 BBO（ts <= decision_ts）"""
        dts = self._resolve_decision_ts(decision_ts)
        if dts is None:
            return None
        return self._bbo_le(dts)

    def get_latest_bar(self, decision_ts: Optional[int] = None) -> Optional[Bar]:
        """获取决策时刻可见的最新一根 Bar"""
        bars = self.get_bars(decision_ts)
        return bars[-1] if bars else None

    def get_price(self, decision_ts: Optional[int] = None) -> Optional[float]:
        """获取决策时刻的当前价格（price_at_or_before(0) 的别名）

        优先级：Trade 最新价 > BBO mid > Bar close
        """
        return self.price_at_or_before(0, decision_ts)

    def price_at_or_before(self, seconds: int | float, decision_ts: Optional[int] = None) -> Optional[float]:
        """查询 seconds 秒前的价格（防御未来函数核心）

        公式：target_ts = decision_ts - seconds*1000
              返回历史中 ts <= target_ts 的最新价格点

        价格源优先级（秒级精度场景）：
            1. Trades：最能反映秒级动量，优先取 trades 中 <= target_ts 的最后一笔 price
            2. BBO mid：若无 trades，取 BBO mid
            3. Bar close：若前两者皆无，取 Bar close

        参数：
            seconds: 回溯秒数（0 表示当前，10 表示 10 秒前）
            decision_ts: 决策时刻（毫秒）；若 None 则取当前最大 ts

        返回：
            float 价格；若历史不足返回 None（调用方需处理为 NaN）
        """
        if seconds < 0:
            raise ValueError(f"seconds 必须 >=0, 得到 {seconds}")
        dts = self._resolve_decision_ts(decision_ts)
        if dts is None:
            return None
        target_ts = dts - int(seconds * 1000)

        # 1) 优先在 Trades 中查找（秒级最精确）
        # 扫描全部 trades，取 ts <= target_ts 的最新一笔（按 ts 最大）
        best_trade: Optional[Trade] = None
        for t in self.trades:
            if t.ts <= target_ts and t.ts <= dts:
                if best_trade is None or t.ts >= best_trade.ts:
                    best_trade = t
        if best_trade is not None:
            return best_trade.price

        # 2) 回退到 BBO mid
        bbo = self._bbo_le(target_ts)  # 注意用 target_ts 而非 dts，避免未来
        # 上行已用 target_ts 过滤，若无则尝试用 dts 的 BBO 但需其 ts <= target_ts
        if bbo is not None:
            return bbo.mid
        # 若 target_ts 时刻无 BBO，尝试取 decision_ts 时刻的 BBO？不允许（会引入未来）
        # 所以此处不再回退

        # 3) 回退到 Bar close（分钟级）
        bars = self._bars_le(target_ts)
        if bars:
            return bars[-1].close

        # 若 target_ts 前完全无数据，返回 None
        return None

    def price_and_ts_at_or_before(
        self, seconds: int | float, decision_ts: Optional[int] = None
    ) -> tuple[Optional[float], Optional[int]]:
        """同 price_at_or_before，但同时返回价格对应的原始 ts（供审计）"""
        if seconds < 0:
            raise ValueError(f"seconds 必须 >=0, 得到 {seconds}")
        dts = self._resolve_decision_ts(decision_ts)
        if dts is None:
            return None, None
        target_ts = dts - int(seconds * 1000)

        best_trade: Optional[Trade] = None
        for t in self.trades:
            if t.ts <= target_ts and t.ts <= dts:
                if best_trade is None or t.ts >= best_trade.ts:
                    best_trade = t
        if best_trade is not None:
            return best_trade.price, best_trade.ts

        bbo = self._bbo_le(target_ts)
        if bbo is not None:
            return bbo.mid, bbo.ts

        bars = self._bars_le(target_ts)
        if bars:
            return bars[-1].close, bars[-1].ts

        return None, None

    def get_bars_in_window(self, window_ms: int, decision_ts: Optional[int] = None) -> list[Bar]:
        """获取决策时刻前 window_ms 内的 Bar（ts ∈ [decision_ts-window_ms, decision_ts]）"""
        dts = self._resolve_decision_ts(decision_ts)
        if dts is None:
            return []
        lo = dts - window_ms
        return [b for b in self.bars if lo <= b.ts <= dts]

    def get_trades_in_window(self, window_ms: int, decision_ts: Optional[int] = None) -> list[Trade]:
        """获取决策时刻前 window_ms 内的 Trades（已含 180s 窗口过滤）"""
        dts = self._resolve_decision_ts(decision_ts)
        if dts is None:
            return []
        lo = dts - window_ms
        return [t for t in self.trades if lo <= t.ts <= dts]

    # ------------------------------------------------------------------
    # 健康检查（数据中断检测）
    # ------------------------------------------------------------------

    def is_healthy(self, decision_ts: Optional[int] = None) -> bool:
        """数据健康检查（布尔快捷版）

        判定：
            - 无任何 Bar → 不健康（无法计算 1m 维度的所有因子）
            - 最新 Bar 距 decision_ts > MAX_BAR_DELAY_MS → 不健康（K 线流中断）
            - BBO 存在但距 decision_ts > MAX_BBO_DELAY_MS → 不健康（盘口中断）
            - BBO 完全缺失 → 在 V1 中视为不健康（OBI/Microprice 无法计算），但若策略允许可放宽

        Trades 中断不直接判不健康（低波动时可能无成交），由上游 Regime/风控综合判断。

        参数：
            decision_ts: 决策时刻；若 None 则取最大 ts
        """
        return self.health_status(decision_ts).healthy

    def health_status(self, decision_ts: Optional[int] = None) -> HealthStatus:
        """详细健康检查，返回结构化结果供日志与熔断使用"""
        dts = self._resolve_decision_ts(decision_ts)
        if dts is None:
            return HealthStatus(
                healthy=False,
                reason="无任何数据（bars/trades/bbo 均为空）",
                bar_count=0,
                trade_count=0,
                bbo_exists=False,
            )

        bar_count = len(self._bars_le(dts))
        trade_count = len(self._trades_le(dts))
        bbo = self._bbo_le(dts)

        # Bar 检查
        bars_le = self._bars_le(dts)
        if not bars_le:
            return HealthStatus(
                healthy=False,
                reason="无可见 Bar（ts <= decision_ts 的 Bar 为空）",
                bar_count=bar_count,
                trade_count=trade_count,
                bbo_exists=bbo is not None,
            )
        last_bar_ts = bars_le[-1].ts
        last_bar_age = dts - last_bar_ts
        if last_bar_age > self.MAX_BAR_DELAY_MS:
            return HealthStatus(
                healthy=False,
                reason=f"Bar 中断：last_bar_age={last_bar_age}ms > {self.MAX_BAR_DELAY_MS}ms",
                last_bar_age_ms=last_bar_age,
                bar_count=bar_count,
                trade_count=trade_count,
                bbo_exists=bbo is not None,
            )

        # BBO 检查（若 BBO 缺失，在严格模式下判不健康；此处 V1 严格）
        if bbo is None:
            # 若从未收到 BBO，视为不健康（避免 OBI/Microprice 用脏数据）
            if self._bbo is None:
                return HealthStatus(
                    healthy=False,
                    reason="BBO 缺失（从未收到盘口）",
                    last_bar_age_ms=last_bar_age,
                    bar_count=bar_count,
                    trade_count=trade_count,
                    bbo_exists=False,
                )
            # 有 BBO 但其 ts > dts（未来），也视为不健康（时钟异常）
            return HealthStatus(
                healthy=False,
                reason="BBO 时间戳在决策时刻之后（时钟/排序异常）",
                last_bar_age_ms=last_bar_age,
                bar_count=bar_count,
                trade_count=trade_count,
                bbo_exists=False,
            )

        last_bbo_age = dts - bbo.ts
        if last_bbo_age > self.MAX_BBO_DELAY_MS:
            return HealthStatus(
                healthy=False,
                reason=f"BBO 中断：last_bbo_age={last_bbo_age}ms > {self.MAX_BBO_DELAY_MS}ms",
                last_bar_age_ms=last_bar_age,
                last_bbo_age_ms=last_bbo_age,
                bar_count=bar_count,
                trade_count=trade_count,
                bbo_exists=True,
            )

        # Trades 延迟仅记录，不直接判不健康
        last_trade_age: Optional[int] = None
        trades_le = self._trades_le(dts)
        if trades_le:
            last_trade_age = dts - trades_le[-1].ts
        else:
            # 无成交时，last_trade_age 视为 None，healthy 仍为 True
            last_trade_age = None

        return HealthStatus(
            healthy=True,
            reason="ok",
            last_bar_age_ms=last_bar_age,
            last_bbo_age_ms=last_bbo_age,
            last_trade_age_ms=last_trade_age,
            bar_count=bar_count,
            trade_count=trade_count,
            bbo_exists=True,
        )

    # ------------------------------------------------------------------
    # 便捷属性与调试
    # ------------------------------------------------------------------

    @property
    def bbo(self) -> Optional[BBO]:
        """最新 BBO（不带未来防御，调试用）；策略侧请用 get_bbo(decision_ts)"""
        return self._bbo

    def bar_count(self, decision_ts: Optional[int] = None) -> int:
        """决策时刻可见的 Bar 数量"""
        return len(self.get_bars(decision_ts))

    def trade_count(self, decision_ts: Optional[int] = None) -> int:
        """决策时刻可见的 Trade 数量（180s 窗口内）"""
        return len(self.get_trades(decision_ts))

    def to_dict(self, decision_ts: Optional[int] = None) -> dict:
        """调试用：导出当前状态摘要"""
        dts = self._resolve_decision_ts(decision_ts)
        hs = self.health_status(dts) if dts is not None else None
        bbo = self.get_bbo(dts)
        return {
            "decision_ts": dts,
            "bars": len(self.get_bars(dts)) if dts is not None else 0,
            "trades": len(self.get_trades(dts)) if dts is not None else 0,
            "bbo": {"bid": bbo.bid, "ask": bbo.ask, "mid": bbo.mid} if bbo else None,
            "healthy": hs.healthy if hs else False,
            "reason": hs.reason if hs else "no data",
        }


__all__ = ["Bar", "Trade", "BBO", "MarketState", "HealthStatus"]
