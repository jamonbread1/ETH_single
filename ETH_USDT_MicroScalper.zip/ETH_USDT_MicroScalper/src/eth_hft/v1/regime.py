"""Regime Engine V1 — 选择性 Micro Scalper 状态机

依据：算法核心.txt #14~#17, #41
    + docs/03_cost_model.md, docs/04_parameters.md
    + 讨论稿：RANGE/TREND/EXTREME/LOCKED 四级过滤

设计目标：可上线、事件驱动、Nautilus 可回放
- 规则优先于 ML，稳定可解释
- 所有阈值集中于 RegimeConfig，可在 configs/system.yaml 覆盖
- detect_regime(state, features) 纯函数，无副作用，便于单测
- is_tradeable(regime, side) 供 strategy.py 做开仓许可判断

防未来函数：
- 特征必须已 shift(1)，调用方保证 feature_end_ts <= decision_ts
- 本模块不做任何 rolling 均值计算，仅读取传入的已计算特征
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum
from typing import Any, Dict, Optional
import math

try:
    from loguru import logger
except Exception:  # 回退
    import logging
    logger = logging.getLogger(__name__)


# ============================================================
# 1. Enum Regime — 算法核心.txt #41 原样
# ============================================================
class Regime(IntEnum):
    """市场状态（与算法核心.txt #41 一致）

    RANGE=1      震荡平稳，适合均值回归
    TREND_UP=2   上行趋势，顺势做多
    TREND_DOWN=3 下行趋势，顺势做空
    EXTREME=4    极端行情，禁止逆势
    LOCKED=5     熔断锁定，禁止一切新开仓
    """
    RANGE = 1
    TREND_UP = 2
    TREND_DOWN = 3
    EXTREME = 4
    LOCKED = 5

    def __str__(self) -> str:  # 便于日志
        return self.name


# ============================================================
# 2. 配置 — 所有魔法数字唯一来源，可被 yaml 覆盖
# ============================================================
@dataclass
class RegimeConfig:
    """Regime 阈值配置
    
    标注来源（满足 docs/04_parameters.md）：
    - 官方/公开：latency 500ms 来自 kill_switch 设计
    - 数据驱动：spread/RV 倍数需在 scripts/21_标定成本.py 中用历史分位数标定，此处为工程默认值
    - 文献/经典：ATR 相关沿用经典 14 周期
    - 算法核心.txt：所有倍数/百分比直接来自原文 #14~#17
    """

    # --- RANGE 判断 (算法核心 #14) ---
    range_rv_ratio_thr: float = 2.0  # 来源：算法核心 #14 RV ratio <2
    range_m30_thr: float = 0.0015  # 来源：经验/数据驱动，|M30|<0.15% 视为震荡，需回测标定（strategy.yaml regime.range_m30_thr）
    range_intensity_thr: float = 2.5  # 来源：算法核心 #14 Intensity<2.5
    range_5m_range_multiple_thr: float = 2.5  # 5m 振幅 < 2.5*中位数视为“正常”，数据驱动

    # --- TREND 判断 (算法核心 #15) ---
    trend_m60_thr: float = 0.0012  # |M60|>0.12% 视为趋势形成，数据驱动，文中 trend_threshold
    trend_volume_ratio_thr: float = 1.3  # 来源：算法核心 #15 VolumeRatio>1.3
    trend_cvd_thr: float = 0.12  # |CVD30 imbalance|>0.12 视为主动单边，数据驱动（CVD 标准化后阈值）
    trend_intensity_thr: float = 1.2  # 来源：算法核心 #15 Intensity>1.2

    # --- EXTREME 判断 (算法核心 #16) ---
    extreme_rv_multiple: float = 4.0  # RV30>4*RV_normal，来源：KillSwitch atr_multiple=4.0（docs/03）
    extreme_ret_1m_thr: float = 0.008  # |1m ret|>0.8% 视为极端，来源：算法核心 #16
    extreme_spread_multiple: float = 3.0  # spread>3*median，来源：KillSwitch spread_multiple=3.0
    extreme_intensity_thr: float = 5.0  # Intensity>5，来源：算法核心 #16

    # --- LOCKED 判断 (算法核心 #17) ---
    locked_consecutive_losses: int = 5  # 连续亏损>=5，来源：risk.yaml kill_switch.consecutive_losses
    locked_daily_loss_pct: float = 0.02  # 日亏损>=2% equity，来源：算法核心 #17
    locked_daily_loss_usdt: Optional[float] = None  # 若设为数值（如 2.0U），则按 USDT 判断，优先级高于 pct
    locked_latency_ms: float = 500.0  # 延迟>500ms，来源：算法核心 #17 / risk.yaml
    locked_data_stale_ms: float = 3000.0  # 数据中断阈值：超过 3s 未更新视为中断，家用 WS 经验值
    locked_cooldown_losses: int = 10  # 连续亏损达 10 次进入更长冷却（risk.yaml cooldown_losses）


# ============================================================
# 3. 输入结构 — 兼容 dict 与对象，便于 Nautilus / 回测调用
# ============================================================
@dataclass
class MarketFeatures:
    """用于 regime 判断的市场特征快照（均为已完成时刻 <=decision_ts）

    约定：所有字段已 shift(1)，不含未来。
    字段缺失时视为 NaN，detect_regime 会降级处理并告警。
    """
    # 动量
    m10: float = float("nan")
    m30: float = float("nan")
    m60: float = float("nan")
    ret_1m: float = float("nan")  # 1m 收益率，用于极端判断

    # 波动率
    rv_30s: float = float("nan")
    rv_normal: float = float("nan")  # RV 中位数/正常值
    rv_ratio: float = float("nan")  # RV30 / median，若无则用 rv_30s/rv_normal

    # 量能
    intensity: float = float("nan")  # Trade Intensity = V10 / Median(V10)
    volume_ratio: float = float("nan")  # Volume1m / MA20

    # 订单流
    cvd_30s: float = float("nan")  # CVD30 imbalance 或原始差值（归一后）
    # 若传入原始买卖量差，可用 buy/sell 计算；此处直接用 imbalance [-1,1]

    # 盘口
    spread: float = float("nan")  # 当前 spread（bps 或小数均可，需与 median 同单位）
    spread_median: float = float("nan")
    # 价格位置
    price: float = float("nan")
    high_5m: float = float("nan")
    low_5m: float = float("nan")
    range_5m: float = float("nan")  # high_5m - low_5m
    range_5m_median: float = float("nan")

    # 扩展：ATR 等（可选）
    atr: float = float("nan")
    atr_median: float = float("nan")


@dataclass
class SystemState:
    """账户/系统健康状态（用于 LOCKED 判断）"""
    consecutive_losses: int = 0  # 连续亏损笔数
    daily_loss_pct: float = 0.0  # 当日亏损占 equity 比例（负数表示亏损，如 -0.025）
    daily_loss_usdt: float = 0.0  # 当日亏损 USDT（负数）
    latency_ms: float = 0.0  # 最新行情/订单往返延迟
    data_healthy: bool = True  # 数据是否健康（WS 是否存活）
    data_gap_ms: float = 0.0  # 距上次有效行情的间隔
    equity_usdt: float = 50.0  # 账户权益，用于 pct 换算
    # 可选：是否处于冷却
    cooldown_until_ms: int = 0


# ============================================================
# 4. 工具
# ============================================================
def _get(obj: Any, key: str, default: float = float("nan")) -> float:
    """兼容 dict / dataclass / 对象取值"""
    if obj is None:
        return default
    if isinstance(obj, dict):
        v = obj.get(key, default)
        return default if v is None else v
    # dataclass / object
    if hasattr(obj, key):
        v = getattr(obj, key)
        return default if v is None else v
    # 尝试按 dict 风格取
    try:
        return obj[key]  # type: ignore
    except Exception:
        return default


def _is_nan(x: Any) -> bool:
    try:
        return x is None or (isinstance(x, float) and math.isnan(x))
    except Exception:
        return False


def _abs_gt(x: float, thr: float) -> bool:
    """abs(x) > thr 且 x 非 NaN"""
    if _is_nan(x) or _is_nan(thr):
        return False
    return abs(float(x)) > float(thr)


def _ratio(a: float, b: float, default: float = float("nan")) -> float:
    if _is_nan(a) or _is_nan(b) or b == 0:
        return default
    return float(a) / float(b)


# ============================================================
# 5. 核心：detect_regime
# ============================================================
def detect_regime(
    state: Any,
    features: Any,
    config: Optional[RegimeConfig] = None,
    *,
    now_ms: Optional[int] = None,
) -> Regime:
    """按算法核心.txt #14~#17 规则判断 Regime

    优先级（高→低）：LOCKED > EXTREME > TREND > RANGE
    - LOCKED：账户/系统级熔断，最高优先，直接禁止开仓
    - EXTREME：市场极端，禁止逆势（MeanReversion）
    - TREND：满足趋势四条件且方向一致
    - RANGE：震荡平稳四条件

    参数:
        state: SystemState 或 dict，含 consecutive_losses/daily_loss/latency/data_healthy
        features: MarketFeatures 或 dict，含 m30/m60/rv/intensity/volume_ratio/cvd/spread 等
        config: RegimeConfig 阈值，若为空用默认值
        now_ms: 当前时间戳（用于 cooldown 判断，可选）

    返回:
        Regime 枚举

    示例（strategy.py）:
        regime = detect_regime(state, features)
        if not is_tradeable(regime, side="long"):
            return
        if regime == Regime.RANGE:
            score, direction = mean_reversion_signal(features, rolling_stats)
    """
    cfg = config or RegimeConfig()

    # ---------- 提取 state ----------
    consec = int(_get(state, "consecutive_losses", 0) or 0)
    daily_pct = float(_get(state, "daily_loss_pct", 0.0) or 0.0)
    daily_usdt = float(_get(state, "daily_loss_usdt", 0.0) or 0.0)
    latency = float(_get(state, "latency_ms", 0.0) or 0.0)
    data_healthy = _get(state, "data_healthy", True)
    if _is_nan(data_healthy):
        data_healthy = True
    data_gap = float(_get(state, "data_gap_ms", 0.0) or 0.0)
    equity = float(_get(state, "equity_usdt", 50.0) or 50.0)
    cooldown_until = int(_get(state, "cooldown_until_ms", 0) or 0)

    # daily_loss_pct 若未提供但提供了 USDT，可换算
    if daily_pct == 0.0 and daily_usdt != 0.0 and equity > 0:
        daily_pct = daily_usdt / equity

    # ---------- 提取 features ----------
    m10 = float(_get(features, "m10", _get(features, "M10", float("nan"))) or 0.0) if not _is_nan(_get(features, "m10", float("nan"))) else float(_get(features, "m10", float("nan")))
    # 更稳健：直接用 _get 保留 NaN
    m10 = _get(features, "m10", _get(features, "M10", float("nan")))
    m30 = _get(features, "m30", _get(features, "M30", float("nan")))
    m60 = _get(features, "m60", _get(features, "M60", float("nan")))
    ret_1m = _get(features, "ret_1m", _get(features, "ret1m", _get(features, "ret_1m", float("nan"))))
    # 兼容 ret_1m 可能是 "m60" 的别名？保持独立
    if _is_nan(ret_1m):
        ret_1m = _get(features, "ret_1m", _get(features, "return_1m", float("nan")))

    rv_30s = _get(features, "rv_30s", _get(features, "rv30", _get(features, "RV30", float("nan"))))
    rv_normal = _get(features, "rv_normal", _get(features, "rv_median", _get(features, "rvNormal", float("nan"))))
    rv_ratio = _get(features, "rv_ratio", _get(features, "rvRatio", float("nan")))
    if _is_nan(rv_ratio):
        rv_ratio = _ratio(rv_30s, rv_normal, float("nan"))

    intensity = _get(features, "intensity", _get(features, "trade_intensity", float("nan")))
    volume_ratio = _get(features, "volume_ratio", _get(features, "volumeRatio", float("nan")))
    cvd_30s = _get(features, "cvd_30s", _get(features, "cvd30", _get(features, "CVD30", float("nan"))))
    spread = _get(features, "spread", float("nan"))
    spread_median = _get(features, "spread_median", _get(features, "spreadMedian", _get(features, "spread_median_bps", float("nan"))))
    # 兼容 bps：若 spread 与 median 均以 bps 给出，比值不变
    price = _get(features, "price", _get(features, "close", float("nan")))
    high_5m = _get(features, "high_5m", _get(features, "high5m", float("nan")))
    low_5m = _get(features, "low_5m", _get(features, "low5m", float("nan")))
    range_5m = _get(features, "range_5m", _get(features, "range5m", float("nan")))
    range_5m_median = _get(features, "range_5m_median", _get(features, "range5mMedian", float("nan")))
    if _is_nan(range_5m) and not _is_nan(high_5m) and not _is_nan(low_5m):
        range_5m = float(high_5m) - float(low_5m)

    # ---------- 1) LOCKED 最高优先 ----------
    # 连续亏损>=5 或 日亏损>=2% 或 延迟>500ms 或 数据中断 → LOCKED
    locked_reasons = []
    if consec >= cfg.locked_consecutive_losses:
        locked_reasons.append(f"consec_loss {consec}>={cfg.locked_consecutive_losses}")
    # 日损判断：支持 USDT 与 pct 双轨
    daily_loss_trigger = False
    if cfg.locked_daily_loss_usdt is not None:
        # 按 USDT
        if daily_usdt <= -abs(cfg.locked_daily_loss_usdt):
            daily_loss_trigger = True
            locked_reasons.append(f"daily_loss {daily_usdt:.2f}U <= -{cfg.locked_daily_loss_usdt}U")
    else:
        if daily_pct <= -abs(cfg.locked_daily_loss_pct):
            daily_loss_trigger = True
            locked_reasons.append(f"daily_loss {daily_pct*100:.2f}% <= -{cfg.locked_daily_loss_pct*100:.0f}%")
    # 延迟
    if not _is_nan(latency) and latency > cfg.locked_latency_ms:
        locked_reasons.append(f"latency {latency:.0f}ms > {cfg.locked_latency_ms:.0f}ms")
    # 数据中断
    if data_healthy is False:
        locked_reasons.append("data_healthy=False")
    if not _is_nan(data_gap) and data_gap > cfg.locked_data_stale_ms:
        locked_reasons.append(f"data_gap {data_gap:.0f}ms > {cfg.locked_data_stale_ms:.0f}ms")
    # 冷却中
    if now_ms is not None and cooldown_until and now_ms < cooldown_until:
        locked_reasons.append(f"cooldown until={cooldown_until} now={now_ms}")

    if locked_reasons:
        logger.warning(f"[Regime] LOCKED triggered: {'; '.join(locked_reasons)}")
        return Regime.LOCKED

    # ---------- 2) EXTREME 次优先 ----------
    # 任意一条满足即 EXTREME：RV30>4*normal 或 |1m ret|>0.8% 或 spread>3*median 或 intensity>5
    extreme_reasons = []
    if not _is_nan(rv_ratio) and rv_ratio > cfg.extreme_rv_multiple:
        extreme_reasons.append(f"RV_ratio={rv_ratio:.2f}>{cfg.extreme_rv_multiple}")
    elif not _is_nan(rv_30s) and not _is_nan(rv_normal) and rv_normal != 0 and (rv_30s / rv_normal) > cfg.extreme_rv_multiple:
        extreme_reasons.append(f"RV30/RV_normal>{cfg.extreme_rv_multiple}")
    if not _is_nan(ret_1m) and abs(float(ret_1m)) > cfg.extreme_ret_1m_thr:
        extreme_reasons.append(f"|ret1m|={abs(float(ret_1m))*100:.2f}%>{cfg.extreme_ret_1m_thr*100:.2f}%")
    if not _is_nan(spread) and not _is_nan(spread_median) and spread_median not in (0, 0.0) and (float(spread) / float(spread_median)) > cfg.extreme_spread_multiple:
        extreme_reasons.append(f"spread/median={float(spread)/float(spread_median):.2f}>{cfg.extreme_spread_multiple}")
    if not _is_nan(intensity) and float(intensity) > cfg.extreme_intensity_thr:
        extreme_reasons.append(f"intensity={intensity:.2f}>{cfg.extreme_intensity_thr}")

    if extreme_reasons:
        logger.warning(f"[Regime] EXTREME triggered: {'; '.join(extreme_reasons)} - MeanReversion blocked")
        return Regime.EXTREME

    # ---------- 3) TREND ----------
    # 条件：abs(M60)>thr 且 volume_ratio>1.3 且 abs(CVD30)>thr 且 intensity>1.2 → 再分 UP/DOWN
    # 需四条件同时满足才视为趋势，否则不轻易切趋势（防抖）
    trend_m60_ok = _abs_gt(m60, cfg.trend_m60_thr)
    trend_vol_ok = (not _is_nan(volume_ratio) and float(volume_ratio) > cfg.trend_volume_ratio_thr)
    trend_cvd_ok = _abs_gt(cvd_30s, cfg.trend_cvd_thr)
    trend_int_ok = (not _is_nan(intensity) and float(intensity) > cfg.trend_intensity_thr)

    is_trend = trend_m60_ok and trend_vol_ok and trend_cvd_ok and trend_int_ok
    if is_trend:
        # 方向由 M60 与 CVD 的符号共同决定；若冲突则以 M60 为主
        direction = 0
        if not _is_nan(m60):
            direction = 1 if float(m60) > 0 else -1
        # CVD 符号校验：若 CVD 与 M60 反向，降低置信但仍按 M60
        if not _is_nan(cvd_30s):
            cvd_sign = 1 if float(cvd_30s) > 0 else -1
            if cvd_sign != direction:
                logger.debug(f"[Regime] Trend dir conflict M60={m60} CVD={cvd_30s}, use M60")
        if direction > 0:
            logger.info(f"[Regime] TREND_UP M60={m60:.4f} volR={volume_ratio:.2f} CVD={cvd_30s:.3f} int={intensity:.2f}")
            return Regime.TREND_UP
        else:
            logger.info(f"[Regime] TREND_DOWN M60={m60:.4f} volR={volume_ratio:.2f} CVD={cvd_30s:.3f} int={intensity:.2f}")
            return Regime.TREND_DOWN

    # ---------- 4) RANGE ----------
    # 条件：RV_ratio<2 且 abs(M30)<thr 且 intensity<2.5 且 5m range 正常
    range_rv_ok = (_is_nan(rv_ratio) or float(rv_ratio) < cfg.range_rv_ratio_thr)
    # 若 rv_ratio 缺失，尝试用 rv_30s/rv_normal 已在上面算过；仍缺则放宽
    range_m30_ok = (_is_nan(m30) or abs(float(m30)) < cfg.range_m30_thr)
    range_int_ok = (_is_nan(intensity) or float(intensity) < cfg.range_intensity_thr)
    # 5m range 正常：range_5m / median < thr，或缺失则视为正常
    range_5m_ok = True
    if not _is_nan(range_5m) and not _is_nan(range_5m_median) and range_5m_median not in (0, 0.0):
        ratio = float(range_5m) / float(range_5m_median)
        range_5m_ok = ratio < cfg.range_5m_range_multiple_thr
        if not range_5m_ok:
            logger.debug(f"[Regime] 5m range abnormal ratio={ratio:.2f}>{cfg.range_5m_range_multiple_thr}")
    # 若缺少 5m range 数据，默认视为正常（不因缺数据误判 EXTREME）

    if range_rv_ok and range_m30_ok and range_int_ok and range_5m_ok:
        return Regime.RANGE

    # ---------- 5) 回退 ----------
    # 未满足趋势四条件、也未完全满足震荡四条件时，倾向保持 RANGE（保守），
    # 除非动量已显趋势迹象（M60 阈值接近），则按动量方向给 TREND 弱信号
    # 此处回退为 RANGE，避免在震荡边缘频繁切 TREND 导致追涨杀跌
    logger.debug(
        f"[Regime] fallback RANGE (rv_ratio={rv_ratio} m30={m30} int={intensity} "
        f"range5m_ok={range_5m_ok} trend_parts=[m60:{trend_m60_ok} vol:{trend_vol_ok} cvd:{trend_cvd_ok} int:{trend_int_ok}])"
    )
    return Regime.RANGE


# ============================================================
# 6. 交易许可 — is_tradeable
# ============================================================
def is_tradeable(
    regime: Regime,
    side: Optional[str] = None,
    strategy_type: Optional[str] = None,
) -> bool:
    """判断当前 Regime 是否允许开仓

    规则（算法核心 #16~#17 + docs/05_position_sizing）：
    - LOCKED：任何 side/策略均禁止 → can_open=False
    - EXTREME：禁止 MeanReversion（逆势），仅允许顺势或空仓观望
    - TREND_UP：仅允许做多（或平空），禁止逆势做空
    - TREND_DOWN：仅允许做空（或平多），禁止逆势做多
    - RANGE：允许双向，但需配合 alpha 信号（本函数仅做 Regime 层过滤）

    参数:
        regime: Regime 枚举
        side: "long"/"short"/"buy"/"sell"/None（None 表示不区分方向，仅问是否可开新仓）
        strategy_type: "mean_reversion" | "trend" | "breakout" | None
                       当 EXTREME 时，若为 mean_reversion 则一律禁止

    返回:
        bool 是否允许开新仓（平仓不受此限，调用方自行处理）

    供 strategy.py 使用:
        if not is_tradeable(regime, side="long", strategy_type="mean_reversion"):
            return
    """
    # 统一 side
    if side is not None:
        side = str(side).lower().strip()
        if side in ("buy", "long", "1", "l"):
            side = "long"
        elif side in ("sell", "short", "-1", "s"):
            side = "short"
        else:
            side = side  # 保留原值，unknown 视为 None

    if strategy_type is not None:
        strategy_type = str(strategy_type).lower().strip()

    # LOCKED：熔断
    if regime == Regime.LOCKED:
        return False

    # EXTREME：禁止均值回归
    if regime == Regime.EXTREME:
        if strategy_type == "mean_reversion" or strategy_type == "mr":
            logger.info("[Regime] EXTREME: MeanReversion blocked")
            return False
        # 若未指定策略类型，为安全起见，EXTREME 下默认禁止所有新开仓中的“逆势”信号
        # 但允许趋势策略的顺势开仓 — 调用方需显式传入 strategy_type="trend" 才能通过
        # 若 side/strategy_type 均未指定，保守返回 False，迫使上层明确意图
        if strategy_type is None and side is None:
            # 模糊查询：EXTREME 下不建议盲目开仓
            return False
        # 若是趋势策略，允许
        if strategy_type in ("trend", "trend_continuation", "breakout"):
            return True
        # 若仅指定 side 但未指定策略类型，生产环境建议返回 False 以强制显式，
        # 此处为兼容历史 is_tradeable(regime, side) 调用，默认放行但告警
        # 如需更严，可改为 return False
        logger.debug(f"[Regime] EXTREME side={side} strategy_type={strategy_type} regarded tradeable (caller must ensure trend-following)")
        return True

    # TREND 方向过滤
    if regime == Regime.TREND_UP:
        if side == "short":
            logger.debug("[Regime] TREND_UP: short blocked (counter-trend)")
            return False
        return True
    if regime == Regime.TREND_DOWN:
        if side == "long":
            logger.debug("[Regime] TREND_DOWN: long blocked (counter-trend)")
            return False
        return True

    # RANGE：双向允许（具体由 alpha 信号决定）
    if regime == Regime.RANGE:
        return True

    # 未知 regime，保守禁止
    return False


def can_open_position(regime: Regime) -> bool:
    """便捷：是否允许开任意新仓（不区分方向）"""
    return is_tradeable(regime, side=None, strategy_type=None) or regime in (Regime.RANGE, Regime.TREND_UP, Regime.TREND_DOWN)


def regime_allows_mean_reversion(regime: Regime) -> bool:
    """EXTREME/LOCKED 禁止均值回归，其余允许"""
    return regime not in (Regime.EXTREME, Regime.LOCKED)


def regime_allows_trend(regime: Regime) -> bool:
    """LOCKED 禁止一切，EXTREME 仅允许趋势（需顺势）"""
    return regime != Regime.LOCKED


# ============================================================
# 7. 兼容层 — 供旧代码 features/regime.py 调用
# ============================================================
def detect_regime_legacy(row, atr_median: float):  # pragma: no cover
    """兼容旧接口：row 为 pd.Series，仅做 ATR 快速映射"""
    try:
        import pandas as pd  # noqa
        atr = row.get("atr_14", float("nan")) if hasattr(row, "get") else float("nan")
        if atr is None or (isinstance(atr, float) and math.isnan(atr)) or atr_median in (0, None) or (isinstance(atr_median, float) and math.isnan(atr_median)):
            return Regime.RANGE
        ratio = float(atr) / float(atr_median)
        if ratio > 4:
            return Regime.EXTREME
        if ratio > 2.5:
            # 近似为趋势
            return Regime.TREND_UP  # 旧逻辑无方向，先给 UP，调用方可再细分
        if ratio > 2:
            return Regime.RANGE
        return Regime.RANGE
    except Exception:
        return Regime.RANGE
