"""特征层 v1：8 因子计算 + zscore 防泄漏 + 审计时间戳

因子来源（严格按 算法核心.txt）：
    1. momentum: M10/M30/M60 = Pt / P_{t-10/30/60} - 1          —— 价格动量
    2. CVD: buy_volume / sell_volume / imbalance + ΔCVD       —— 逐笔主动买卖流量
    3. Trade Intensity: V10 / median(V10_past)                —— 成交强度（突发检测）
    4. Volume Expansion: volume_ratio = vol_1m / MA20(vol_1m) —— 量能扩张
    5. OBI: (bid_size - ask_size)/(bid_size + ask_size)       —— 盘口失衡
    6. Microprice: (ask*bid_size+bid*ask_size)/(bid_size+ask_size), MPD=(micro-mid)/mid —— 微观价格偏离
    7. Volatility: RV30/RV60 = realized_vol(returns_1s, 30/60), VolRatio = RV30/median(RV30)
    8. Position: (P - Low5m)/(High5m - Low5m)                 —— 5 分钟价格位置

防泄漏与审计：
    - 所有因子仅使用 ts <= decision_ts 的数据（通过 MarketState 过滤）
    - 每个因子返回 FeatureRecord，记录 source_start_ts / source_end_ts / decision_ts，供 assert feature_end <= decision_ts 审计
    - zscore 采用 shift(1).rolling 防泄漏：当前值不参与当前均值/方差计算

可被 Nautilus 策略调用：
    from eth_hft.v1.data import MarketState
    from eth_hft.v1.features import FeatureEngine
    engine = FeatureEngine()
    feats = engine.compute(state, decision_ts)
    # feats["m10"].value, feats["m10"].zscore, feats["m10"].source_start_ts
"""
from __future__ import annotations

import math
from collections import deque
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

try:
    from .data import MarketState, Bar, Trade, BBO
except ImportError:  # 兼容直接脚本运行
    from eth_hft.v1.data import MarketState, Bar, Trade, BBO  # type: ignore

# ==============================================================================
# 0. 通用审计结构与 zscore 工具（防泄漏核心）
# ==============================================================================


@dataclass(frozen=True, slots=True)
class FeatureRecord:
    """单因子审计记录

    属性：
        name: 因子名（如 m10、cvd_imbalance、obi 等）
        value: 因子原始值（float，缺失为 nan）
        zscore: 标准化后值（基于历史 shift(1) 窗口，若历史不足为 nan）
        source_start_ts: 计算该因子所用数据的最早时间戳（毫秒，<= decision_ts）
        source_end_ts: 计算该因子所用数据的最晚时间戳（毫秒，<= decision_ts）
        decision_ts: 决策时刻（毫秒）
    """

    name: str
    value: float
    zscore: float
    source_start_ts: Optional[int]
    source_end_ts: Optional[int]
    decision_ts: int


def zscore_series(series: pd.Series, window: int = 60, min_periods: int = 20) -> pd.Series:
    """对序列做滚动 zscore（严格 shift(1).rolling 防泄漏）

    公式：
        z_t = (x_t - mean(x_{t-window .. t-1})) / std(x_{t-window .. t-1})

    等价于 pandas 的 series.shift(1).rolling(window).mean/std
    防止当前值 x_t 泄露到自己的标准化中。

    参数：
        series: 待标准化序列（按时间升序）
        window: 滚动窗口长度
        min_periods: 最小样本数，不足则返回 NaN

    返回：
        与输入等长的 zscore 序列，首 window 行为 NaN
    """
    if series.empty:
        return series
    # 兼容：min_periods 不能大于 window，否则 pandas 抛错
    eff_min = min(min_periods, window)
    # shift(1) 是防泄漏关键：均值/方差仅用 t 之前的历史
    rolled_mean = series.shift(1).rolling(window=window, min_periods=eff_min).mean()
    rolled_std = series.shift(1).rolling(window=window, min_periods=eff_min).std(ddof=1)
    # 避免除 0：std 过小置 NaN
    rolled_std = rolled_std.mask(rolled_std < 1e-12)
    return (series - rolled_mean) / rolled_std


def zscore_value(current: float, history: deque | list[float], window: int = 60) -> float:
    """增量版 zscore：用历史窗口计算当前值的 zscore（不含当前值本身）

    与 zscore_series 等价的在线版本，适用于流式 FeatureEngine。
    history 中应仅含 t 之前的因子值（shift 语义由调用方保证：先算 zscore 再 append）。

    返回：
        float，历史不足或 std==0 时返回 nan
    """
    if history is None or len(history) < 2:
        return float("nan")
    arr = list(history)[-window:]  # 取最近 window 个
    if len(arr) < 2:
        return float("nan")
    # 过滤 nan
    arr_clean = [x for x in arr if x is not None and not (isinstance(x, float) and math.isnan(x))]
    if len(arr_clean) < 2:
        return float("nan")
    mean = float(np.mean(arr_clean))
    std = float(np.std(arr_clean, ddof=1)) if len(arr_clean) >= 2 else float("nan")
    if std < 1e-12 or math.isnan(std):
        return float("nan")
    if math.isnan(current):
        return float("nan")
    return (current - mean) / std


def realized_vol(returns: np.ndarray | list[float] | pd.Series, window: int) -> float:
    """已实现波动率（Realized Volatility）

    公式（与 算法核心.txt 一致）：
        RV_window = sqrt(sum_{i=1}^{window} r_i^2)
    其中 r_i 为 1s 对数或简单收益率，此处用简单收益率 r = P_t/P_{t-1} -1

    与 ATR 的区别：RV 基于秒级已实现收益，对短期波动更敏感，适合 30s/60s 微观窗口。

    参数：
        returns: 1s 收益率序列（按时间升序）
        window: 窗口长度（如 30、60）

    返回：
        float，窗口内收益率平方和的平方根；若数据不足返回 nan
    """
    if returns is None:
        return float("nan")
    arr = np.asarray(returns, dtype=float)
    # 去除 nan
    arr = arr[~np.isnan(arr)]
    if len(arr) < window:
        # 数据不足：若完全无数据返回 nan，否则用现有数据计算（宽松）
        if len(arr) == 0:
            return float("nan")
        # 严格版应返回 nan，此处为提升可用性用实际长度
        window = len(arr)
        if window < 2:
            return float("nan")
    tail = arr[-window:]
    return float(np.sqrt(np.sum(tail ** 2)))


# ==============================================================================
# 1. FeatureEngine：8 因子统一入口
# ==============================================================================


class FeatureEngine:
    """特征引擎（有状态，维护 zscore/median 所需历史）

    状态维护：
        - 各因子的历史值队列（用于 zscore 的 shift(1).rolling）
        - V10 历史（用于 Intensity 的 median）
        - RV30 历史（用于 VolRatio 的 median）

    无状态替代：也可每次从 MarketState 回溯计算 median（更重），
    此处采用增量历史 + 回退扫描的混合策略，保证回测与实盘一致。

    参数：
        zscore_window: zscore 滚动窗口（默认 60）
        zscore_min_periods: zscore 最小样本（默认 20）
        intensity_history_len: Intensity median 窗口（默认 30，对应 5 分钟的 10s 桶）
        vol_median_window: VolRatio median 窗口（默认 100）
    """

    def __init__(
        self,
        zscore_window: int = 60,
        zscore_min_periods: int = 20,
        intensity_history_len: int = 30,
        vol_median_window: int = 100,
    ) -> None:
        self.zscore_window = zscore_window
        self.zscore_min_periods = zscore_min_periods
        self.intensity_history_len = intensity_history_len
        self.vol_median_window = vol_median_window

        # 因子历史（用于 zscore），key -> deque(maxlen=zscore_window)
        # 覆盖 8 组因子的所有子因子
        factor_keys = [
            "m10",
            "m30",
            "m60",
            "cvd_imbalance",
            "cvd_delta",
            "intensity",
            "volume_ratio",
            "obi",
            "mpd",
            "microprice",
            "rv30",
            "rv60",
            "vol_ratio",
            "position_5m",
        ]
        self._hist: Dict[str, deque] = {k: deque(maxlen=zscore_window) for k in factor_keys}

        # 额外：V10 原始量与 RV30 原始波动的历史（用于 median）
        self._v10_hist: deque = deque(maxlen=intensity_history_len)
        self._rv30_hist: deque = deque(maxlen=vol_median_window)

    # ------------------------------------------------------------------
    # 内部小工具
    # ------------------------------------------------------------------

    @staticmethod
    def _safe_div(numer: float, denom: float, default: float = float("nan")) -> float:
        """安全除法，分母过小返回 default"""
        if denom is None or abs(denom) < 1e-12:
            return default
        return numer / denom

    def _compute_z(self, key: str, value: float) -> float:
        """计算指定 key 的 zscore（基于历史，不含当前值）"""
        hist = self._hist.get(key)
        if hist is None:
            return float("nan")
        # 历史不足 min_periods 时返回 nan（与 pandas rolling 语义一致）
        if len(hist) < self.zscore_min_periods:
            return float("nan")
        return zscore_value(value, hist, window=self.zscore_window)

    def _update_hist(self, key: str, value: float) -> None:
        """将当前值推入历史（在 zscore 计算之后调用，保证 shift(1)）"""
        if key in self._hist and value is not None and not (isinstance(value, float) and math.isnan(value) and False):
            # 允许 nan 也入队？为保持与 pandas 一致，nan 不应参与后续均值/方差，
            # 但此处选择过滤 nan 入队，避免污染历史
            if isinstance(value, float) and math.isnan(value):
                return
            self._hist[key].append(value)

    # ------------------------------------------------------------------
    # 主入口
    # ------------------------------------------------------------------

    def compute(self, state: MarketState, decision_ts: Optional[int] = None) -> Dict[str, FeatureRecord]:
        """计算全部 8 组因子（共 ~15 个子因子），返回审计字典

        参数：
            state: 市场状态（已按事件驱动更新）
            decision_ts: 决策时刻（毫秒）；若 None 则取 state 内最大 ts

        返回：
            Dict[str, FeatureRecord]，key 包含：
                m10, m30, m60,
                cvd_buy_volume, cvd_sell_volume, cvd_imbalance, cvd_delta,
                intensity, volume_ratio,
                obi, microprice, mpd,
                rv30, rv60, vol_ratio,
                position_5m
            每个 value 含原始值、zscore、source_start/end、decision_ts

        未来函数审计：
            调用方可断言：rec.source_end_ts <= decision_ts 且 rec.source_start_ts <= rec.source_end_ts
        """
        # 解析决策时刻（防御未来：若外部未传则取状态内最大可见时间）
        dts = state._resolve_decision_ts(decision_ts)  # type: ignore[attr-defined]
        if dts is None:
            raise ValueError("MarketState 为空，无法确定 decision_ts")

        result: Dict[str, FeatureRecord] = {}

        # 依次计算 8 组因子（顺序与文档一致，便于对照）
        # 每组因子内部先算 raw，再算 zscore，最后再将 raw 推入历史（保证 shift(1)）

        # ------------------------------------------------------------------
        # 1. Momentum：M10/M30/M60 = Pt / P_{t-10/30/60} - 1
        # 公式来源：算法核心.txt Factor 1
        # ------------------------------------------------------------------
        momentum_records = self._compute_momentum(state, dts)
        result.update(momentum_records)

        # ------------------------------------------------------------------
        # 2. CVD：30s 窗口的 buy/sell/imbalance + ΔCVD
        # 公式来源：算法核心.txt Factor 2
        #   CVD_T = sum(BuyVolume) - sum(SellVolume)
        #   imbalance = (buy - sell)/(buy + sell)
        #   ΔCVD = CVD30_t - CVD30_{t-10s}（流量增量，判断买卖压是否在增强）
        # ------------------------------------------------------------------
        cvd_records = self._compute_cvd(state, dts)
        result.update(cvd_records)

        # ------------------------------------------------------------------
        # 3. Trade Intensity：V10 / median(V10_past)
        # 公式来源：算法核心.txt Factor 3
        # ------------------------------------------------------------------
        intensity_rec = self._compute_intensity(state, dts)
        result[intensity_rec.name] = intensity_rec

        # ------------------------------------------------------------------
        # 4. Volume Expansion：volume_ratio = vol_1m / MA20(vol_1m)
        # 公式来源：算法核心.txt Factor 4
        # ------------------------------------------------------------------
        vol_exp_rec = self._compute_volume_expansion(state, dts)
        result[vol_exp_rec.name] = vol_exp_rec

        # ------------------------------------------------------------------
        # 5. OBI：(bid_size - ask_size)/(bid_size + ask_size)
        # 公式来源：算法核心.txt Factor 5
        # ------------------------------------------------------------------
        obi_rec = self._compute_obi(state, dts)
        result[obi_rec.name] = obi_rec

        # ------------------------------------------------------------------
        # 6. Microprice：(ask*bid_size + bid*ask_size)/(bid_size+ask_size)，MPD=(micro-mid)/mid
        # 公式来源：算法核心.txt Factor 6
        # ------------------------------------------------------------------
        micro_recs = self._compute_microprice(state, dts)
        result.update(micro_recs)

        # ------------------------------------------------------------------
        # 7. Volatility：RV30/RV60 = realized_vol(returns_1s, 30/60)，VolRatio = RV30/median(RV30)
        # 公式来源：算法核心.txt Factor 7
        # ------------------------------------------------------------------
        vol_recs = self._compute_volatility(state, dts)
        result.update(vol_recs)

        # ------------------------------------------------------------------
        # 8. Position：(P - Low5m)/(High5m - Low5m)
        # 公式来源：算法核心.txt Factor 8
        # ------------------------------------------------------------------
        pos_rec = self._compute_position(state, dts)
        result[pos_rec.name] = pos_rec

        # ------------------------------------------------------------------
        # 统一更新历史（必须在 zscore 计算后，避免当前值泄露）
        # ------------------------------------------------------------------
        # 注意：cvd 有多个子因子，仅对 imbalance/delta 做 zscore 历史
        for key in ["m10", "m30", "m60", "cvd_imbalance", "cvd_delta", "intensity", "volume_ratio", "obi", "mpd", "microprice", "rv30", "rv60", "vol_ratio", "position_5m"]:
            if key in result:
                self._update_hist(key, result[key].value)

        # V10 与 RV30 的 median 历史已在各自子方法内增量维护，此处无需重复

        return result

    # ------------------------------------------------------------------
    # 8 组因子的具体实现（每个方法均含中文注释与公式来源）
    # ------------------------------------------------------------------

    def _compute_momentum(self, state: MarketState, dts: int) -> Dict[str, FeatureRecord]:
        """因子 1：动量（Momentum）

        公式：
            M10 = Pt / P_{t-10s} - 1
            M30 = Pt / P_{t-30s} - 1
            M60 = Pt / P_{t-60s} - 1

        实现：
            Pt  = price_at_or_before(0, dts)
            P10 = price_at_or_before(10, dts)  依此类推
            若任一价格缺失则该动量为 NaN（审计时 source_start/end 仍记录目标窗口）

        审计：
            source_start_ts = dts - seconds*1000（理论窗口起点）
            source_end_ts   = dts（决策时刻）
            实际找到的价格 ts 必然 <= source_end_ts，满足未来函数审计
        """
        out: Dict[str, FeatureRecord] = {}
        # 当前价格（0 秒前）
        now_price = state.price_at_or_before(0, dts)
        # 若当前价格缺失，三个动量均无法计算
        for seconds, name in [(10, "m10"), (30, "m30"), (60, "m60")]:
            past_price = state.price_at_or_before(seconds, dts)
            source_start = dts - int(seconds * 1000)
            source_end = dts
            if now_price is None or past_price is None or abs(past_price) < 1e-12:
                raw = float("nan")
            else:
                raw = now_price / past_price - 1.0
            z = self._compute_z(name, raw)
            out[name] = FeatureRecord(
                name=name,
                value=float(raw) if not math.isnan(raw) else float("nan"),
                zscore=float(z) if not math.isnan(z) else float("nan"),
                source_start_ts=source_start,
                source_end_ts=source_end,
                decision_ts=dts,
            )
        return out

    def _compute_cvd(self, state: MarketState, dts: int) -> Dict[str, FeatureRecord]:
        """因子 2：累计成交量差（CVD）与增量 ΔCVD

        定义：
            CVD_30s = sum(buy_qty) - sum(sell_qty)  在窗口 [dts-30s, dts] 内
            buy_volume  = sum(buy_qty)
            sell_volume = sum(sell_qty)
            imbalance   = (buy - sell)/(buy + sell)  ∈ [-1, 1]，0 表示均衡

        增量 ΔCVD：
            ΔCVD = CVD_imbalance_t - CVD_imbalance_{t-10s}
            即当前 30s 流量失衡与 10 秒前的流量失衡之差，捕捉“流量是否在改善/恶化”
            若历史不足则为 NaN，策略侧应做容错。

        审计：
            source_start = dts - 30000，source_end = dts（当前窗口）
            ΔCVD 的 source 覆盖 [dts-40000, dts]（当前与对比窗口的并集），但为简化审计仍记为 [dts-40000, dts]
        """
        out: Dict[str, FeatureRecord] = {}
        window_ms = 30_000
        # 当前窗口
        trades = state.get_trades_in_window(window_ms, dts)
        buy = sum(t.qty for t in trades if t.side == "buy")
        sell = sum(t.qty for t in trades if t.side == "sell")
        total = buy + sell
        imbalance = 0.0 if total == 0 else (buy - sell) / total

        # ΔCVD：对比 10 秒前的 CVD imbalance
        # 取 [dts-40s, dts-10s] 的 30s 窗口作为“过去”窗口
        past_dts = dts - 10_000
        past_trades = state.get_trades_in_window(window_ms, past_dts)
        past_buy = sum(t.qty for t in past_trades if t.side == "buy")
        past_sell = sum(t.qty for t in past_trades if t.side == "sell")
        past_total = past_buy + past_sell
        past_imb = 0.0 if past_total == 0 else (past_buy - past_sell) / past_total
        # 若任一窗口无交易，imbalance 虽为 0，但 delta 仍可计算；若窗口完全缺失则 delta 置 nan
        # 判定：若当前与过去窗口均无交易，delta 无意义置 0；若仅一侧无，delta = 当前 - 过去
        if not trades and not past_trades:
            delta = 0.0
            # 若完全无交易，imbalance 记 0，delta 记 0 更稳健（避免 nan 传播）
        elif not trades or not past_trades:
            delta = imbalance - past_imb
        else:
            delta = imbalance - past_imb

        # 统一审计时戳
        source_start = dts - window_ms
        source_end = dts

        # 分别封装 4 个子因子（buy/sell/imbalance/delta），其中 buy/sell 为原始量，zscore 仅对 imbalance/delta 有意义
        for name, raw in [
            ("cvd_buy_volume", float(buy)),
            ("cvd_sell_volume", float(sell)),
            ("cvd_imbalance", float(imbalance)),
            ("cvd_delta", float(delta)),
        ]:
            # buy/sell 的 zscore 可选，此处也计算（基于各自历史）
            # 若历史字典未包含该 key，则 zscore 为 nan（已初始化 imbalance/delta，buy/sell 需动态处理）
            if name not in self._hist:
                # 动态扩容历史（首次出现）
                self._hist[name] = deque(maxlen=self.zscore_window)
            z = self._compute_z(name, raw) if name in self._hist else float("nan")
            out[name] = FeatureRecord(
                name=name,
                value=float(raw),
                zscore=float(z) if not math.isnan(z) else float("nan"),
                source_start_ts=source_start,
                source_end_ts=source_end,
                decision_ts=dts,
            )
        return out

    def _compute_intensity(self, state: MarketState, dts: int) -> FeatureRecord:
        """因子 3：成交强度（Trade Intensity）

        公式：
            Intensity = V10 / median(V10_past)
            V10 = 最近 10 秒成交量（sum qty）
            median(V10_past) = 过去 5 分钟内各 10s 桶成交量的中位数（30 个样本）

        解释：
            Intensity ≈ 0.8 表示成交平淡，≈ 4.6 表示突发大量交易，对趋势启动识别非常重要。

        实现（双路径）：
            - 优先用增量历史 _v10_hist 的 median（O(1)，适合实盘）
            - 若历史不足（冷启动），则回退到扫描 state 中过去 5 分钟的 10s 桶中位数（保证回测可复现）

        审计：
            source_start = dts - 10s（当前 V10 窗口起点）
            source_end   = dts
            但 median 的数据源覆盖 [dts-310s, dts-10s]，审计上仍记为 [dts-310s, dts] 以包含全量
        """
        # 当前 V10
        cur_trades = state.get_trades_in_window(10_000, dts)
        v10 = float(sum(t.qty for t in cur_trades))

        # 计算分母 median
        median_val: Optional[float] = None
        if len(self._v10_hist) >= 10:
            # 增量路径：用历史队列的中位数
            arr = np.array(list(self._v10_hist), dtype=float)
            # 过滤 nan（理论上 V10 不会 nan）
            arr = arr[~np.isnan(arr)]
            if len(arr) >= 5:
                median_val = float(np.median(arr))
        else:
            # 冷启动扫描路径：过去 5 分钟（300s）切 10s 桶，共 30 桶（不含当前）
            # 桶定义： [dts - (i+1)*10s, dts - i*10s)  i=1..30
            buckets: list[float] = []
            for i in range(1, 31):
                bucket_end = dts - i * 10_000
                bucket_start = bucket_end - 10_000
                bucket_trades = [t for t in state.get_trades(dts) if bucket_start <= t.ts < bucket_end]
                # 也可用 get_trades_in_window 但需指定 end，这里直接过滤
                vol = sum(t.qty for t in bucket_trades)
                buckets.append(float(vol))
            # 去除全 0 冷启动的干扰：若全 0 则 median 为 0，后续除法需保护
            if buckets:
                median_val = float(np.median(np.array(buckets, dtype=float)))
            else:
                median_val = None

        # 计算 Intensity
        if median_val is None or median_val < 1e-12:
            # 分母过小：若当前 V10 也极小则 Intensity 记 1.0（无突发），否则记 nan 避免误判
            if v10 < 1e-12:
                intensity = 0.0
            else:
                # 过去中位数为 0 但当前有量，视为强度极高， capped
                intensity = float("nan") if not self._v10_hist else float(v10 / max(median_val if median_val else 1e-12, 1e-12))
                # 若 median 仍为 0，返回一个较大的强度值但不溢出
                if math.isnan(intensity) or math.isinf(intensity):
                    intensity = 5.0  # capped 极值，代表突发
        else:
            intensity = v10 / median_val

        # 审计时戳：当前窗口起点到决策时刻
        source_start = dts - 10_000
        source_end = dts

        z = self._compute_z("intensity", float(intensity) if not math.isnan(intensity) else float("nan"))

        # 维护历史（在 zscore 之后）
        # 注意：无论 intensity 是否 nan，只要 v10 有效就推入 V10 历史（用于下次 median）
        self._v10_hist.append(v10)

        return FeatureRecord(
            name="intensity",
            value=float(intensity),
            zscore=float(z) if not math.isnan(z) else float("nan"),
            source_start_ts=source_start,
            source_end_ts=source_end,
            decision_ts=dts,
        )

    def _compute_volume_expansion(self, state: MarketState, dts: int) -> FeatureRecord:
        """因子 4：量能扩张（Volume Expansion）

        公式：
            VolumeRatio = Volume_1m / MA20(Volume_1m)
            Volume_1m = 最新一根已完成 1m Bar 的 volume（ts <= dts）
            MA20 = 前 20 根 Bar 的 volume 均值（不含当前 Bar，shift(1) 防泄漏）

        解释：
            >1 表示放量，<1 表示缩量；配合趋势与 CVD 判断突破有效性。

        审计：
            source_start = MA20 窗口中最早 Bar 的 ts
            source_end   = 最新 Bar 的 ts（<= dts）
            若 Bar 数量不足则按实际可用数量计算，source_start 为最早可用 Bar ts
        """
        bars = state.get_bars(dts)
        if not bars:
            return FeatureRecord(
                name="volume_ratio",
                value=float("nan"),
                zscore=float("nan"),
                source_start_ts=None,
                source_end_ts=dts,
                decision_ts=dts,
            )
        # 最新 Bar 为当前 1m 量
        latest = bars[-1]
        cur_vol = float(latest.volume)

        # MA20：取最新 Bar 之前的 20 根（shift(1)）
        # 若总数不足 21，则取除最新外全部
        if len(bars) >= 2:
            # 排除最新
            prev_bars = bars[:-1]
            window = prev_bars[-20:]  # 最近 20 根（不含当前）
            if window:
                ma20 = float(np.mean([float(b.volume) for b in window]))
                source_start = window[0].ts
            else:
                ma20 = float("nan")
                source_start = latest.ts
        else:
            ma20 = float("nan")
            source_start = latest.ts

        source_end = latest.ts
        if math.isnan(ma20) or ma20 < 1e-12:
            raw = float("nan") if math.isnan(ma20) else cur_vol / max(ma20, 1e-12)
            if math.isnan(raw) or math.isinf(raw):
                raw = float("nan")
        else:
            raw = cur_vol / ma20

        z = self._compute_z("volume_ratio", raw)
        return FeatureRecord(
            name="volume_ratio",
            value=float(raw),
            zscore=float(z) if not math.isnan(z) else float("nan"),
            source_start_ts=source_start,
            source_end_ts=source_end,
            decision_ts=dts,
        )

    def _compute_obi(self, state: MarketState, dts: int) -> FeatureRecord:
        """因子 5：盘口失衡（Order Book Imbalance, OBI）

        公式（V1 仅用 BBO 一档）：
            OBI = (BidSize - AskSize) / (BidSize + AskSize)  ∈ [-1, 1]
            >0 买压强，<0 卖压强

        注意：
            OBI 不是方向信号本身，只是辅助信息，需配合 CVD/Momentum 使用。

        审计：
            source_start = source_end = BBO.ts（单点快照）
        """
        bbo = state.get_bbo(dts)
        if bbo is None:
            return FeatureRecord(
                name="obi",
                value=float("nan"),
                zscore=float("nan"),
                source_start_ts=None,
                source_end_ts=None,
                decision_ts=dts,
            )
        denom = bbo.bid_size + bbo.ask_size
        if denom <= 0:
            raw = 0.0
        else:
            raw = (bbo.bid_size - bbo.ask_size) / denom
        z = self._compute_z("obi", float(raw))
        return FeatureRecord(
            name="obi",
            value=float(raw),
            zscore=float(z) if not math.isnan(z) else float("nan"),
            source_start_ts=bbo.ts,
            source_end_ts=bbo.ts,
            decision_ts=dts,
        )

    def _compute_microprice(self, state: MarketState, dts: int) -> Dict[str, FeatureRecord]:
        """因子 6：微观价格（Microprice）与偏离 MPD

        公式：
            MicroPrice = (Ask*BidSize + Bid*AskSize) / (BidSize + AskSize)
            Mid        = (Bid + Ask)/2
            MPD        = (MicroPrice - Mid)/Mid

        解释：
            MicroPrice 是以对边数量加权的“公平价”，MPD 反映盘口数量导致的微观偏离，
            正值表示买压使微观价高于中间价。

        审计：
            source_start = source_end = BBO.ts
        """
        out: Dict[str, FeatureRecord] = {}
        bbo = state.get_bbo(dts)
        if bbo is None:
            for name in ["microprice", "mpd"]:
                out[name] = FeatureRecord(
                    name=name,
                    value=float("nan"),
                    zscore=float("nan"),
                    source_start_ts=None,
                    source_end_ts=None,
                    decision_ts=dts,
                )
            return out

        total = bbo.bid_size + bbo.ask_size
        mid = bbo.mid
        if total <= 0:
            micro = mid
        else:
            micro = (bbo.ask * bbo.bid_size + bbo.bid * bbo.ask_size) / total
        mpd = 0.0 if abs(mid) < 1e-12 else (micro - mid) / mid

        for name, raw in [("microprice", float(micro)), ("mpd", float(mpd))]:
            z = self._compute_z(name, raw)
            out[name] = FeatureRecord(
                name=name,
                value=float(raw),
                zscore=float(z) if not math.isnan(z) else float("nan"),
                source_start_ts=bbo.ts,
                source_end_ts=bbo.ts,
                decision_ts=dts,
            )
        return out

    def _compute_volatility(self, state: MarketState, dts: int) -> Dict[str, FeatureRecord]:
        """因子 7：波动率（Realized Volatility）

        公式：
            RV30 = realized_vol(returns_1s, 30)  最近 30 秒已实现波动
            RV60 = realized_vol(returns_1s, 60)  最近 60 秒已实现波动
            VolRatio = RV30 / median(RV30_past)

        其中 returns_1s 为 1 秒收益率序列：r_t = P_t / P_{t-1} - 1
        RV = sqrt(sum(r_i^2))

        实现：
            - 采样 1s 价格序列：对过去 60 秒每秒取 price_at_or_before
            - 计算 60 个收益率（61 个价格点）
            - 取尾部 30/60 计算 RV
            - VolRatio 分母为 RV30 历史中位数（_rv30_hist）

        审计：
            source_start = dts - 60s（1s 序列起点）
            source_end   = dts
        """
        out: Dict[str, FeatureRecord] = {}
        # 采样 1s 价格序列（61 点，60 收益），按时间升序：p0 = dts-60s, ..., p60 = dts
        # price_at_or_before(offset) 中 offset 为秒数，offset=60 表示 60s 前
        prices: list[Optional[float]] = []
        for offset in range(60, -1, -1):  # 60,59,...,0 → 60s前到当前
            p, _ = state.price_and_ts_at_or_before(offset, dts)  # type: ignore[attr-defined]
            prices.append(p)
        # 此时 prices[0]=60s前价格，prices[-1]=当前价格，已为升序，无需再反转

        # 计算收益率
        returns: list[float] = []
        for i in range(1, len(prices)):
            prev = prices[i - 1]
            cur = prices[i]
            if prev is None or cur is None or abs(prev) < 1e-12:
                returns.append(float("nan"))
            else:
                returns.append(cur / prev - 1.0)

        # 过滤 nan 后计算 RV
        # 使用 realized_vol 辅助，但此处已展开
        rv30 = realized_vol(np.array(returns, dtype=float), window=30)
        rv60 = realized_vol(np.array(returns, dtype=float), window=60)

        # VolRatio = RV30 / median(RV30 历史)
        if len(self._rv30_hist) >= 10:
            arr = np.array(list(self._rv30_hist), dtype=float)
            arr = arr[~np.isnan(arr)]
            median_rv = float(np.median(arr)) if len(arr) >= 5 else None
        else:
            median_rv = None

        if median_rv is None or median_rv < 1e-12:
            if math.isnan(rv30) or rv30 < 1e-12:
                vol_ratio = float("nan")
            else:
                # 冷启动分母为 0，返回 nan 或 capped
                vol_ratio = float("nan")
        else:
            vol_ratio = rv30 / median_rv if not math.isnan(rv30) else float("nan")

        source_start = dts - 60_000
        source_end = dts

        # 维护 RV30 历史（在计算 VolRatio 之后，避免当前泄露）
        if not math.isnan(rv30):
            self._rv30_hist.append(float(rv30))

        for name, raw in [("rv30", float(rv30)), ("rv60", float(rv60)), ("vol_ratio", float(vol_ratio))]:
            z = self._compute_z(name, raw)
            out[name] = FeatureRecord(
                name=name,
                value=float(raw) if not (isinstance(raw, float) and math.isnan(raw) and False) else float("nan"),
                zscore=float(z) if not math.isnan(z) else float("nan"),
                source_start_ts=source_start,
                source_end_ts=source_end,
                decision_ts=dts,
            )
            # 确保 nan 也正确处理
            # 上行已处理，补充对 nan 的显式保留
            if math.isnan(raw):
                out[name] = FeatureRecord(
                    name=name,
                    value=float("nan"),
                    zscore=float("nan"),
                    source_start_ts=source_start,
                    source_end_ts=source_end,
                    decision_ts=dts,
                )
        return out

    def _compute_position(self, state: MarketState, dts: int) -> FeatureRecord:
        """因子 8：价格位置（Position in 5m Range）

        公式：
            Position = (P - Low5m) / (High5m - Low5m)
            P       = 当前价格（decision_ts）
            High5m  = 过去 5 分钟（300s）内所有 1m Bar 的最高 high
            Low5m   = 同窗口最低 low

        解释：
            0   → 当前接近 5 分钟低点（超卖/支撑）
            0.5 → 中间
            1   → 当前接近 5 分钟高点（超买/阻力）
            在震荡（RANGE）模式中特别有效，用于均值回归入场过滤。

        审计：
            source_start = 窗口内最早 Bar.ts（或 dts-300s 若无 Bar）
            source_end   = 窗口内最晚 Bar.ts（或 dts）
        """
        window_ms = 5 * 60_000
        bars = state.get_bars_in_window(window_ms, dts)
        price = state.price_at_or_before(0, dts)

        if not bars or price is None:
            return FeatureRecord(
                name="position_5m",
                value=float("nan"),
                zscore=float("nan"),
                source_start_ts=dts - window_ms,
                source_end_ts=dts,
                decision_ts=dts,
            )

        high = max(float(b.high) for b in bars)
        low = min(float(b.low) for b in bars)
        source_start = bars[0].ts
        source_end = bars[-1].ts

        denom = high - low
        if abs(denom) < 1e-12:
            raw = 0.5  # 区间为 0，视为中位
        else:
            raw = (price - low) / denom
            # 截断到 [0,1] 外允许小幅溢出（如突破），但为稳定性 clamp 到 [-0.2, 1.2]
            # 策略侧可自行处理突破信号，此处不硬截断，保留原始值
            # raw = max(-0.5, min(1.5, raw))

        z = self._compute_z("position_5m", float(raw))
        return FeatureRecord(
            name="position_5m",
            value=float(raw),
            zscore=float(z) if not math.isnan(z) else float("nan"),
            source_start_ts=source_start,
            source_end_ts=source_end,
            decision_ts=dts,
        )


__all__ = ["FeatureRecord", "FeatureEngine", "zscore_series", "zscore_value", "realized_vol"]
