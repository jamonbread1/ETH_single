"""v1 核心算法：Regime + Alpha + Data + Features
可被 strategy.py / 回测 / 实盘统一调用

说明：regime/alpha 为可选模块（逐步实现），data/features 为已上线核心，
此处采用可选导入以保证 `from eth_hft.v1.data import MarketState` 在子模块缺失时仍可工作。
"""
from __future__ import annotations

# 核心数据与特征（必备）
try:
    from .data import Bar, Trade, BBO, MarketState, HealthStatus  # noqa: F401
except Exception as _e:  # pragma: no cover
    Bar = Trade = BBO = MarketState = HealthStatus = None  # type: ignore

try:
    from .features import FeatureRecord, FeatureEngine, zscore_series, zscore_value, realized_vol  # noqa: F401
except Exception as _e:  # pragma: no cover
    FeatureRecord = FeatureEngine = None  # type: ignore

# 可选：Regime / Alpha（未实现时不阻断 data/features 的导入）
try:
    from .regime import Regime, RegimeConfig, SystemState, MarketFeatures, detect_regime, is_tradeable  # noqa: F401
except Exception:
    Regime = RegimeConfig = SystemState = MarketFeatures = detect_regime = is_tradeable = None  # type: ignore

try:
    from .alpha import AlphaConfig, mean_reversion_signal, trend_signal  # noqa: F401
except Exception:
    AlphaConfig = mean_reversion_signal = trend_signal = None  # type: ignore

# 成本 / 风控 / 执行（Selective Micro Scalper 核心）
try:
    from .cost import CostEngine, CostConfig, DEFAULT_MIN_NET_EDGE, MIN_NET_EDGE  # noqa: F401
except Exception:
    CostEngine = CostConfig = DEFAULT_MIN_NET_EDGE = MIN_NET_EDGE = None  # type: ignore

try:
    from .risk import RiskEngine, RiskConfig, KillSwitch, KillState, SignalType, size_position, reject_trade  # noqa: F401
except Exception:
    RiskEngine = RiskConfig = KillSwitch = KillState = SignalType = size_position = reject_trade = None  # type: ignore

try:
    from .execution import ExecutionEngine, ExecutionConfig, Signal, OrderRequest, PositionState  # noqa: F401
except Exception:
    ExecutionEngine = ExecutionConfig = Signal = OrderRequest = PositionState = None  # type: ignore

__all__ = [
    "Bar",
    "Trade",
    "BBO",
    "MarketState",
    "HealthStatus",
    "FeatureRecord",
    "FeatureEngine",
    "zscore_series",
    "zscore_value",
    "realized_vol",
    "Regime",
    "RegimeConfig",
    "SystemState",
    "MarketFeatures",
    "detect_regime",
    "is_tradeable",
    "AlphaConfig",
    "mean_reversion_signal",
    "trend_signal",
    "CostEngine",
    "CostConfig",
    "DEFAULT_MIN_NET_EDGE",
    "MIN_NET_EDGE",
    "RiskEngine",
    "RiskConfig",
    "KillSwitch",
    "KillState",
    "SignalType",
    "size_position",
    "reject_trade",
    "ExecutionEngine",
    "ExecutionConfig",
    "Signal",
    "OrderRequest",
    "PositionState",
]
