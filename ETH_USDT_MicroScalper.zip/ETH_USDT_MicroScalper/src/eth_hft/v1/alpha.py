"""Alpha Engine V1 — 震荡均值回归 + 趋势延续

依据：算法核心.txt #18~#21, #51
    + docs/04_parameters.md（权重标注来源）
    + 讨论稿：RANGE 用反转，TREND 用顺势，EXTREME 停逆势

设计目标：可上线、纯函数、无未来、权重可配置、zscore 归一需传入 rolling 统计

防未来函数：
- 所有输入特征必须已 shift(1)，即 feature_end <= decision_ts
- zscore 的 rolling 均值/方差必须仅用历史窗口（调用方用 shift(1).rolling 计算）
- 本模块不做任何全量标准化

Nautilus 事件驱动示例：
    features = feature_engine.compute(state)  # 已 shift
    rolling = feature_engine.rolling_stats(window=300)  # 历史 300 根的均值/方差，已 shift
    score_mr, dir_mr = mean_reversion_signal(features, rolling_stats=rolling, config=cfg)
    score_tr, dir_tr = trend_signal(features, rolling_stats=rolling, config=cfg)

权重来源标注见 AlphaWeights 注释（算法核心 #19/#21 原值）
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Tuple
import math

try:
    from loguru import logger
except Exception:
    import logging
    logger = logging.getLogger(__name__)


# ============================================================
# 0. 工具
# ============================================================
def _get(obj: Any, key: str, default: Any = float("nan")) -> Any:
    if obj is None:
        return default
    if isinstance(obj, dict):
        return obj.get(key, default)
    if hasattr(obj, key):
        v = getattr(obj, key)
        return default if v is None else v
    try:
        return obj[key]  # type: ignore
    except Exception:
        return default


def _is_nan(x: Any) -> bool:
    return x is None or (isinstance(x, float) and math.isnan(x))


def _clip(x: float, lo: float = -3.0, hi: float = 3.0) -> float:
    return max(lo, min(hi, float(x)))


def _zscore(
    value: float,
    mean: float,
    std: float,
    *,
    default_std: float = 1.0,
    clip: float = 3.0,
) -> float:
    """z = (value - mean)/std，含缺失与除零保护"""
    if _is_nan(value):
        return 0.0
    if _is_nan(mean):
        mean = 0.0
    if _is_nan(std) or std == 0 or abs(float(std)) < 1e-12:
        std = default_std
    z = (float(value) - float(mean)) / float(std)
    if clip is not None:
        z = _clip(z, -clip, clip)
    if math.isnan(z) or math.isinf(z):
        return 0.0
    return float(z)


def _z_from_stats(
    value: float,
    stats: Optional[Dict[str, Any]],
    key: str,
    default_std: float,
    *,
    fallback_value: Optional[float] = None,
) -> float:
    """从 rolling_stats 中取 (mean,std) 计算 z；缺失则用 value/default_std"""
    if stats is None:
        # 无统计时，用原始值 / 默认波动 做近似 z
        if _is_nan(value):
            return 0.0
        return _clip(float(value) / default_std, -3, 3)
    # stats 支持多种形态：
    # 1) {"m10": (mean,std)}  2) {"m10": {"mean":..,"std":..}}  3) {"m10_mean":..,"m10_std":..}
    # 4) {"means": {"m10":..}, "stds": {"m10":..}}
    # 优先尝试形态1/2
    if key in stats:
        v = stats[key]
        if isinstance(v, (list, tuple)) and len(v) >= 2:
            return _zscore(value, float(v[0]), float(v[1]), default_std=default_std)
        if isinstance(v, dict) and "mean" in v and "std" in v:
            return _zscore(value, float(v["mean"]), float(v["std"]), default_std=default_std)
        # 若直接是标量，视为已 z 化的值
        if isinstance(v, (int, float)):
            # 这种情况下 value 已在外部归一，直接返回 value 的 clip
            pass
    # 形态3
    mean_key = f"{key}_mean"
    std_key = f"{key}_std"
    if mean_key in stats and std_key in stats:
        return _zscore(value, float(stats[mean_key]), float(stats[std_key]), default_std=default_std)
    # 形态4
    if "means" in stats and "stds" in stats:
        means = stats["means"]
        stds = stats["stds"]
        if isinstance(means, dict) and isinstance(stds, dict) and key in means and key in stds:
            return _zscore(value, float(means[key]), float(stds[key]), default_std=default_std)
    # 兜底
    if _is_nan(value):
        return 0.0
    return _clip(float(value) / default_std, -3, 3)


# 默认波动估计（用于无 rolling_stats 时的 fallback z）
# 来源：历史 1s/1m 波动经验，需在 scripts/21_标定后以实测分位数覆盖
_DEFAULT_STDS: Dict[str, float] = {
    "m10": 0.0008,          # 10s 动量 0.08% 1σ
    "m30": 0.0012,          # 30s 动量 0.12% 1σ
    "m60": 0.0018,          # 60s 动量 0.18% 1σ
    "cvd": 0.25,            # CVD imbalance 标准化差 0.25
    "cvd30": 0.25,
    "obi": 0.30,            # OBI 1σ≈0.3
    "mpd": 0.00005,         # MPD 0.5bps 1σ (若传入 bps 则用 0.5)
    "mpd_bps": 0.5,
    "intensity": 0.80,      # Intensity 1σ≈0.8
    "volume_ratio": 0.60,   # VolumeRatio 1σ≈0.6
}


# ============================================================
# 1. 权重配置 — 标注来源（算法核心 #19/#21）
# ============================================================
@dataclass
class AlphaWeightsMR:
    """Mean Reversion 权重（算法核心 #19 原值）

    Score_MR_long = 0.30*z(-M10)+0.20*z(-M30)+0.25*z(CVD)+0.15*z(OBI)+0.10*z(MPD)
    来源：算法核心.txt #19 权重即文中默认值，V1 先用固定权重，V2 用 LightGBM/IC 加权覆盖（见 docs/04）
    - w_m10: 0.30  短期超跌最敏感
    - w_m30: 0.20  30s 辅助，防单点噪音
    - w_cvd: 0.25  资金流反转权重高
    - w_obi: 0.15  盘口改善
    - w_mpd: 0.10  微价偏离
    """
    w_m10: float = 0.30  # 来源：算法核心 #19
    w_m30: float = 0.20  # 来源：算法核心 #19
    w_cvd: float = 0.25  # 来源：算法核心 #19
    w_obi: float = 0.15  # 来源：算法核心 #19
    w_mpd: float = 0.10  # 来源：算法核心 #19


@dataclass
class AlphaWeightsTrend:
    """Trend 权重（算法核心 #21 原值）

    Score_trend_long =0.30*z(M30)+0.20*z(M60)+0.25*z(CVD)+0.15*z(intensity)+0.10*z(volume_ratio)
    来源：算法核心.txt #21
    """
    w_m30: float = 0.30  # 来源：算法核心 #21
    w_m60: float = 0.20  # 来源：算法核心 #21
    w_cvd: float = 0.25  # 来源：算法核心 #21
    w_intensity: float = 0.15  # 来源：算法核心 #21
    w_volume_ratio: float = 0.10  # 来源：算法核心 #21


@dataclass
class AlphaConfig:
    """Alpha 总配置（可在 configs/strategy.yaml 中覆盖）"""
    # 权重
    mr: AlphaWeightsMR = field(default_factory=AlphaWeightsMR)
    trend: AlphaWeightsTrend = field(default_factory=AlphaWeightsTrend)

    # --- MeanReversion 阈值（算法核心 #18，1m单数据源下放宽至0.35/0.65以保证5~30笔/天） ---
    mr_position_low: float = 0.35  # 原0.25过严，1m回测仅极端才触发，现0.35
    mr_position_high: float = 0.65  # 原0.75
    mr_m10_thr: float = 0.00025  # 原0.0004=0.04%，现0.025%以增加信号
    mr_cvd_improve_thr: float = -0.08  # CVD30>-thr 视为卖压衰减（改善），数据驱动
    mr_cvd_delta_thr: float = 0.0  # ΔCVD>0 视为改善（需传入 cvd_delta）
    mr_obi_thr: float = 0.0  # OBI>0（做多）/ OBI<0（做空）
    mr_mpd_thr: float = 0.0  # MPD>0（做多）/ MPD<0（做空），单位与特征一致

    # --- Trend 阈值（算法核心 #20） ---
    trend_intensity_thr: float = 1.5  # Intensity>1.5
    trend_volume_ratio_thr: float = 1.5  # VolumeRatio>1.5
    # 突破后回撤区间：0.03%~0.08%
    trend_pullback_low: float = 0.0003
    trend_pullback_high: float = 0.0008
    trend_breakout_lookback: int = 5  # 5m high 突破需在最近 N 根内发生（1m bar 计）
    # 方向性阈值（已在信号内用 >0 判断，此处可放宽为极小正数防噪音）
    trend_momentum_thr: float = 0.0  # M30>0 / M60>0


# ============================================================
# 2. 特征提取 helpers
# ============================================================
def _extract_mr_features(features: Any) -> Dict[str, float]:
    """统一提取 MR 所需特征，兼容多种命名"""
    def g(*keys):
        for k in keys:
            v = _get(features, k, float("nan"))
            if not _is_nan(v):
                return float(v)
        return float("nan")

    out: Dict[str, float] = {}
    out["position_5m"] = g("position_5m", "position5m", "pos5m", "position")
    out["m10"] = g("m10", "M10", "mom10", "ret_10s")
    out["m30"] = g("m30", "M30", "mom30", "ret_30s")
    out["cvd30"] = g("cvd30", "cvd_30s", "cvd", "CVD30")
    out["cvd_delta"] = g("cvd_delta", "cvdDelta", "delta_cvd", "cvd_change")
    # 若没有 delta，可用 cvd_30s 与前值差近似；缺失时视为 0
    out["obi"] = g("obi", "OBI", "obi_5", "bbo_imbalance")
    out["mpd"] = g("mpd", "MPD", "microprice_deviation", "micro_price_dev")
    # 兼容 bps：若传入 mpd_bps，转换为小数
    mpd_bps = _get(features, "mpd_bps", float("nan"))
    if not _is_nan(mpd_bps) and _is_nan(out["mpd"]):
        out["mpd"] = float(mpd_bps) / 1e4
    # 若均无，尝试从 bid/ask/bid_size/ask_size 推导（可选）
    return out


def _extract_trend_features(features: Any) -> Dict[str, float]:
    def g(*keys):
        for k in keys:
            v = _get(features, k, float("nan"))
            if not _is_nan(v):
                return float(v)
        return float("nan")

    out: Dict[str, float] = {}
    out["m30"] = g("m30", "M30", "mom30")
    out["m60"] = g("m60", "M60", "mom60")
    out["cvd30"] = g("cvd30", "cvd_30s", "cvd", "CVD30")
    out["intensity"] = g("intensity", "trade_intensity", "tradeIntensity")
    out["volume_ratio"] = g("volume_ratio", "volumeRatio", "vol_ratio")
    out["price"] = g("price", "close", "mid_price", "mid")
    out["high_5m"] = g("high_5m", "high5m", "high_5m", "high5")
    out["low_5m"] = g("low_5m", "low5m", "low_5m", "low5")
    # 可选：最近突破标记（由特征层提供）
    out["breakout_recent"] = g("breakout_recent", "breakout_flag", "has_breakout")
    # 若未提供，可用 price 与 high_5m 距离近似
    return out


# ============================================================
# 3. Mean Reversion 信号
# ============================================================
def _check_mr_long(feat: Dict[str, float], cfg: AlphaConfig) -> Tuple[bool, str]:
    """检查 MR 做多条件（算法核心 #18）

    规则：
      Position5m<0.25 and M10<-0.04% and CVD30改善 and OBI>0 and MPD>0
    CVD 改善 = CVD30 > thr 且 delta>0（或至少不恶化）
    """
    pos = feat["position_5m"]
    m10 = feat["m10"]
    cvd = feat["cvd30"]
    delta = feat["cvd_delta"]
    obi = feat["obi"]
    mpd = feat["mpd"]

    # 1m单数据源下CVD/OBI/MPD常缺失，改为按可用特征加权，不直接拒单
    # 仅 pos/m10 为必备（1m可算），其余缺失则跳过该分项并在计分时重归一
    if _is_nan(pos) or _is_nan(m10):
        return False, "核心特征缺失(pos/m10)"

    if not (pos < cfg.mr_position_low):
        return False, f"pos5m={pos:.3f}>={cfg.mr_position_low}"
    if not (m10 < -abs(cfg.mr_m10_thr)):
        return False, f"m10={m10*100:.3f}%>=-{cfg.mr_m10_thr*100:.2f}%"
    # CVD/OBI/MPD 1m下常缺失，改为可选加分项：缺失则跳过，不拒单
    # 若 cvd 非NaN则检查，否则视为中性通过
    if not _is_nan(cvd):
        cvd_ok = cvd > cfg.mr_cvd_improve_thr
        if not cvd_ok:
            return False, f"cvd={cvd:.3f}<={cfg.mr_cvd_improve_thr}"
        if not _is_nan(delta) and not (delta > cfg.mr_cvd_delta_thr):
            return False, f"cvd_delta={delta:.3f}<={cfg.mr_cvd_delta_thr}"
    if not _is_nan(obi) and not (obi > cfg.mr_obi_thr):
        return False, f"obi={obi:.3f}<={cfg.mr_obi_thr}"
    if not _is_nan(mpd) and not (mpd > cfg.mr_mpd_thr):
        return False, f"mpd={mpd:.6f}<={cfg.mr_mpd_thr}"
    return True, "ok"


def _check_mr_short(feat: Dict[str, float], cfg: AlphaConfig) -> Tuple[bool, str]:
    """对称：做空

    规则：
      Position5m>0.75 and M10>+0.04% and CVD30<-thr 且 delta<0 and OBI<0 and MPD<0
    """
    pos = feat["position_5m"]
    m10 = feat["m10"]
    cvd = feat["cvd30"]
    delta = feat["cvd_delta"]
    obi = feat["obi"]
    mpd = feat["mpd"]

    if _is_nan(pos) or _is_nan(m10):
        return False, "核心特征缺失(pos/m10)"

    if not (pos > cfg.mr_position_high):
        return False, f"pos5m={pos:.3f}<={cfg.mr_position_high}"
    if not (m10 > abs(cfg.mr_m10_thr)):
        return False, f"m10={m10*100:.3f}%<={cfg.mr_m10_thr*100:.2f}%"
    # 对称：CVD 恶化（空头方向）— 缺失则跳过
    if not (cvd < -cfg.mr_cvd_improve_thr):  # 这里沿用同一阈值的对称
        # 更严格：cvd < +thr 的相反数
        if not (cvd < abs(cfg.mr_cvd_improve_thr) * -1 and False):
            pass
        # 简化：cvd < 0.08? 使用对称阈值
        if not (cvd < -cfg.mr_cvd_improve_thr if cfg.mr_cvd_improve_thr < 0 else cvd < 0.08):
            # 通用对称：cvd < +0.08 反向
            pass
    # 明确对称阈值：空头要求 cvd < +0.08? 实为 cvd < 0.08? 但逻辑是卖压增强
    # 使用 -mr_cvd_improve_thr 的对称：
    # mr_cvd_improve_thr 默认 -0.08，多头要求 cvd > -0.08，空头要求 cvd < +0.08
    # CVD/OBI/MPD 缺失则跳过（1m兼容）
    if not _is_nan(cvd):
        if cfg.mr_cvd_improve_thr < 0:
            if not (cvd < -cfg.mr_cvd_improve_thr):
                return False, f"cvd={cvd:.3f}>={-cfg.mr_cvd_improve_thr:.3f}"
        else:
            if not (cvd < cfg.mr_cvd_improve_thr):
                return False, f"cvd={cvd:.3f}>={cfg.mr_cvd_improve_thr}"
    if not _is_nan(delta) and not (delta < -cfg.mr_cvd_delta_thr):
        return False, f"cvd_delta={delta:.3f}>={-cfg.mr_cvd_delta_thr}"
    if not _is_nan(obi) and not (obi < -cfg.mr_obi_thr):
        return False, f"obi={obi:.3f}>={-cfg.mr_obi_thr}"
    if not _is_nan(mpd) and not (mpd < -cfg.mr_mpd_thr):
        return False, f"mpd={mpd:.6f}>={-cfg.mr_mpd_thr}"
    return True, "ok"


def _score_mr(
    feat: Dict[str, float],
    rolling_stats: Optional[Dict[str, Any]],
    cfg: AlphaConfig,
    direction: int,
) -> float:
    """计算 MR 分数（已满足方向条件后）

    Long:  0.30*z(-M10)+0.20*z(-M30)+0.25*z(CVD)+0.15*z(OBI)+0.10*z(MPD)
    Short: 0.30*z(M10)+0.20*z(M30)+0.25*z(-CVD)+0.15*z(-OBI)+0.10*z(-MPD)
           即对称取反，保证分数越大越利好该方向
    """
    m10 = feat["m10"]
    m30 = feat["m30"]
    cvd = feat["cvd30"]
    obi = feat["obi"]
    mpd = feat["mpd"]

    w = cfg.mr

    if direction == 1:  # long
        z_m10 = _z_from_stats(-float(m10), rolling_stats, "m10", _DEFAULT_STDS["m10"])
        z_m30 = _z_from_stats(-float(m30), rolling_stats, "m30", _DEFAULT_STDS["m30"])
        z_cvd = _z_from_stats(float(cvd), rolling_stats, "cvd", _DEFAULT_STDS["cvd"])
        # MPD 若以小数存储，需要选对 default
        mpd_key = "mpd"
        mpd_std = _DEFAULT_STDS["mpd"]
        # 若 mpd 绝对值 <0.01，视为小数；否则可能已是 bps
        if abs(float(mpd)) > 0.01:
            mpd_key = "mpd_bps"
            mpd_std = _DEFAULT_STDS["mpd_bps"]
        z_obi = _z_from_stats(float(obi), rolling_stats, "obi", _DEFAULT_STDS["obi"])
        z_mpd = _z_from_stats(float(mpd), rolling_stats, mpd_key, mpd_std)
        score = w.w_m10 * z_m10 + w.w_m30 * z_m30 + w.w_cvd * z_cvd + w.w_obi * z_obi + w.w_mpd * z_mpd
        return float(score)

    if direction == -1:  # short 对称
        z_m10 = _z_from_stats(float(m10), rolling_stats, "m10", _DEFAULT_STDS["m10"])
        z_m30 = _z_from_stats(float(m30), rolling_stats, "m30", _DEFAULT_STDS["m30"])
        z_cvd = _z_from_stats(-float(cvd), rolling_stats, "cvd", _DEFAULT_STDS["cvd"])
        mpd_key = "mpd"
        mpd_std = _DEFAULT_STDS["mpd"]
        if abs(float(mpd)) > 0.01:
            mpd_key = "mpd_bps"
            mpd_std = _DEFAULT_STDS["mpd_bps"]
        z_obi = _z_from_stats(-float(obi), rolling_stats, "obi", _DEFAULT_STDS["obi"])
        z_mpd = _z_from_stats(-float(mpd), rolling_stats, mpd_key, mpd_std)
        score = w.w_m10 * z_m10 + w.w_m30 * z_m30 + w.w_cvd * z_cvd + w.w_obi * z_obi + w.w_mpd * z_mpd
        return float(score)

    return 0.0


def mean_reversion_signal(
    features: Any,
    rolling_stats: Optional[Dict[str, Any]] = None,
    config: Optional[AlphaConfig] = None,
) -> Tuple[float, int]:
    """震荡均值回归信号（RANGE 专用）

    条件（算法核心 #18）：
      Long:  Position5m<0.25 and M10<-0.04% and CVD30改善 and OBI>0 and MPD>0
      Short: Position5m>0.75 and M10>+0.04% and CVD30恶化 and OBI<0 and MPD<0

    分数（算法核心 #19）：
      Long:  Score_MR_long = 0.30*z(-M10)+0.20*z(-M30)+0.25*z(CVD)+0.15*z(OBI)+0.10*z(MPD)
      Short: 对称

    zscore 需传入 rolling 均值/方差（仅用历史，调用方 shift(1).rolling 计算）
      rolling_stats 示例：
        {
          "m10": (mean, std),
          "m30": {"mean":..., "std":...},
          "m10_mean": 0.0001, "m10_std": 0.0008,
          "means": {"m10":...}, "stds": {"m10":...},
        }
      若为 None，则用 _DEFAULT_STDS 做 fallback（已标注需实测标定）

    返回:
        (score, direction)
        score: float 标准化分数，>0 表示有利，绝对值越大越强（建议阈值 0.5~1.0，需回测标定）
        direction: 1=做多, -1=做空, 0=无信号

    供 strategy.py 调用:
        score, direction = mean_reversion_signal(features, rolling_stats)
        if direction != 0 and score > 0.8:
            # 配合 is_tradeable(Regime.RANGE) 再做成本过滤
    """
    cfg = config or AlphaConfig()
    feat = _extract_mr_features(features)

    long_ok, long_reason = _check_mr_long(feat, cfg)
    short_ok, short_reason = _check_mr_short(feat, cfg)

    # 若双向同时满足（极少），选分数更高者
    if long_ok and short_ok:
        s_long = _score_mr(feat, rolling_stats, cfg, 1)
        s_short = _score_mr(feat, rolling_stats, cfg, -1)
        if s_long >= s_short:
            logger.debug(f"[MR] both triggered pick long s={s_long:.3f} vs short s={s_short:.3f}")
            return float(s_long), 1
        else:
            logger.debug(f"[MR] both triggered pick short s={s_short:.3f} vs long s={s_long:.3f}")
            return float(s_short), -1

    if long_ok:
        score = _score_mr(feat, rolling_stats, cfg, 1)
        logger.debug(f"[MR] long triggered score={score:.3f} feat={feat}")
        return float(score), 1

    if short_ok:
        score = _score_mr(feat, rolling_stats, cfg, -1)
        logger.debug(f"[MR] short triggered score={score:.3f} feat={feat}")
        return float(score), -1

    # 无信号：可返回 0 分，或返回最接近的分数供监控（此处返回 0,0 保持纯净）
    logger.debug(f"[MR] no signal long:{long_reason} short:{short_reason}")
    return 0.0, 0


def mean_reversion_signal_detailed(
    features: Any,
    rolling_stats: Optional[Dict[str, Any]] = None,
    config: Optional[AlphaConfig] = None,
) -> Dict[str, Any]:
    """详细版（供回测/监控，返回分数与分项 z）"""
    cfg = config or AlphaConfig()
    feat = _extract_mr_features(features)
    score_long = _score_mr(feat, rolling_stats, cfg, 1)
    score_short = _score_mr(feat, rolling_stats, cfg, -1)
    long_ok, long_reason = _check_mr_long(feat, cfg)
    short_ok, short_reason = _check_mr_short(feat, cfg)
    # 分项 z 供报表
    z_m10_l = _z_from_stats(-feat["m10"] if not _is_nan(feat["m10"]) else 0, rolling_stats, "m10", _DEFAULT_STDS["m10"])
    z_m30_l = _z_from_stats(-feat["m30"] if not _is_nan(feat["m30"]) else 0, rolling_stats, "m30", _DEFAULT_STDS["m30"])
    z_cvd_l = _z_from_stats(feat["cvd30"], rolling_stats, "cvd", _DEFAULT_STDS["cvd"])
    z_obi_l = _z_from_stats(feat["obi"], rolling_stats, "obi", _DEFAULT_STDS["obi"])
    z_mpd_l = _z_from_stats(feat["mpd"], rolling_stats, "mpd", _DEFAULT_STDS["mpd"])
    return {
        "feat": feat,
        "score_long": score_long,
        "score_short": score_short,
        "long_ok": long_ok,
        "short_ok": short_ok,
        "long_reason": long_reason,
        "short_reason": short_reason,
        "z_breakdown_long": {"m10": z_m10_l, "m30": z_m30_l, "cvd": z_cvd_l, "obi": z_obi_l, "mpd": z_mpd_l},
    }


# ============================================================
# 4. Trend 信号
# ============================================================
def _check_trend_long(feat: Dict[str, float], cfg: AlphaConfig, features_raw: Any = None) -> Tuple[bool, str]:
    """检查趋势做多条件（算法核心 #20）

    规则（TREND_UP）：
      M30>0 and M60>0 and CVD30>0 and Intensity>1.5 and VolumeRatio>1.5
      and 突破5m high后回撤0.03-0.08%再启动

    回撤逻辑：
      - 若特征层已提供 breakout_recent 标记，直接用；
      - 否则用 price / high_5m 距离近似：dist = (high_5m - price)/price
        要求 0.0003 <= dist <= 0.0008，且 price 接近 high_5m（说明刚突破后小回撤）
        若 high_5m 缺失，则放宽该条件（仅告警，不硬拦截，便于 1m 回测）
    """
    m30 = feat["m30"]
    m60 = feat["m60"]
    cvd = feat["cvd30"]
    inten = feat["intensity"]
    vol = feat["volume_ratio"]
    price = feat["price"]
    high_5m = feat["high_5m"]

    # 1m单数据源下CVD/Intensity/Volume常缺失，改为按可用特征加权，至少需m30/m60
    if _is_nan(m30) or _is_nan(m60):
        return False, "核心特征缺失(m30/m60)"

    if not (m30 > cfg.trend_momentum_thr):
        return False, f"m30={m30*100:.3f}%<={cfg.trend_momentum_thr}"
    if not (m60 > cfg.trend_momentum_thr):
        return False, f"m60={m60*100:.3f}%<={cfg.trend_momentum_thr}"
    # CVD/Intensity/Volume 1m下常缺失，缺失则跳过该分项，不拒单
    if not _is_nan(cvd) and not (cvd > 0):
        return False, f"cvd={cvd:.3f}<=0"
    if not _is_nan(inten) and not (inten > cfg.trend_intensity_thr):
        return False, f"intensity={inten:.2f}<={cfg.trend_intensity_thr}"
    if not _is_nan(vol) and not (vol > cfg.trend_volume_ratio_thr):
        return False, f"volRatio={vol:.2f}<={cfg.trend_volume_ratio_thr}"

    # 突破回撤检查
    breakout_recent = feat.get("breakout_recent", float("nan"))
    if not _is_nan(breakout_recent) and breakout_recent > 0:
        # 特征层已确认近期突破
        pass
    else:
        # 用 price/high_5m 近似
        if not _is_nan(price) and not _is_nan(high_5m) and high_5m not in (0, 0.0):
            # 若 price 已超过 high_5m，视为刚突破（dist 为负），允许直接入场（避免错过）
            # 若 price 在 high_5m 下方 0.03-0.08%，视为回撤后启动
            dist = (float(high_5m) - float(price)) / float(price) if price != 0 else float("nan")
            if not _is_nan(dist):
                if dist < -0.001:  # price 已远超 high_5m 0.1% 以上，可能是追高，放宽但告警
                    logger.debug(f"[Trend] price far above high_5m dist={dist*100:.3f}%, relax pullback")
                elif dist < 0:
                    # 刚突破，未回撤，直接允许
                    pass
                elif 0 <= dist < cfg.trend_pullback_low:
                    return False, f"pullback shallow dist={dist*100:.3f}%<{cfg.trend_pullback_low*100:.2f}% (insufficient)"
                elif dist > cfg.trend_pullback_high:
                    return False, f"pullback deep dist={dist*100:.3f}%>{cfg.trend_pullback_high*100:.2f}% (below zone)"
                # 0.03-0.08% 区间内通过
            # price 缺失或 high_5m 缺失则跳过检查
        else:
            logger.debug("[Trend] missing price/high_5m, skip breakout pullback check (relaxed for 1m)")

    return True, "ok"


def _check_trend_short(feat: Dict[str, float], cfg: AlphaConfig) -> Tuple[bool, str]:
    """对称：趋势做空（TREND_DOWN）

    规则：
      M30<0 and M60<0 and CVD30<0 and Intensity>1.5 and VolumeRatio>1.5
      and 跌破5m low后回抽0.03-0.08%
    """
    m30 = feat["m30"]
    m60 = feat["m60"]
    cvd = feat["cvd30"]
    inten = feat["intensity"]
    vol = feat["volume_ratio"]
    price = feat["price"]
    low_5m = feat["low_5m"]

    if _is_nan(m30) or _is_nan(m60):
        return False, "核心特征缺失(m30/m60)"

    if not (m30 < -cfg.trend_momentum_thr):
        return False, f"m30={m30*100:.3f}%>={-cfg.trend_momentum_thr}"
    if not (m60 < -cfg.trend_momentum_thr):
        return False, f"m60={m60*100:.3f}%>={-cfg.trend_momentum_thr}"
    if not _is_nan(cvd) and not (cvd < 0):
        return False, f"cvd={cvd:.3f}>=0"
    if not _is_nan(inten) and not (inten > cfg.trend_intensity_thr):
        return False, f"intensity={inten:.2f}<={cfg.trend_intensity_thr}"
    if not _is_nan(vol) and not (vol > cfg.trend_volume_ratio_thr):
        return False, f"volRatio={vol:.2f}<={cfg.trend_volume_ratio_thr}"

    # 回抽检查（对称）
    breakout_recent = feat.get("breakout_recent", float("nan"))
    if not _is_nan(breakout_recent) and breakout_recent < 0:
        pass
    else:
        if not _is_nan(price) and not _is_nan(low_5m) and price not in (0, 0.0):
            dist = (float(price) - float(low_5m)) / float(price) if price != 0 else float("nan")
            if not _is_nan(dist):
                if dist < -0.001:
                    logger.debug(f"[TrendShort] price far below low_5m dist={dist*100:.3f}%")
                elif dist < 0:
                    pass
                elif 0 <= dist < cfg.trend_pullback_low:
                    return False, f"pullback shallow short dist={dist*100:.3f}%<{cfg.trend_pullback_low*100:.2f}%"
                elif dist > cfg.trend_pullback_high:
                    return False, f"pullback deep short dist={dist*100:.3f}%>{cfg.trend_pullback_high*100:.2f}%"
    return True, "ok"


def _score_trend(
    feat: Dict[str, float],
    rolling_stats: Optional[Dict[str, Any]],
    cfg: AlphaConfig,
    direction: int,
) -> float:
    """Trend 分数（算法核心 #21）

    Long:  0.30*z(M30)+0.20*z(M60)+0.25*z(CVD)+0.15*z(Intensity)+0.10*z(VolumeRatio)
    Short: 取反（M30/CVD 为负值时，z(-M30) 越大越强）
    """
    m30 = feat["m30"]
    m60 = feat["m60"]
    cvd = feat["cvd30"]
    inten = feat["intensity"]
    vol = feat["volume_ratio"]
    w = cfg.trend

    if direction == 1:
        z_m30 = _z_from_stats(float(m30), rolling_stats, "m30", _DEFAULT_STDS["m30"])
        z_m60 = _z_from_stats(float(m60), rolling_stats, "m60", _DEFAULT_STDS["m60"])
        z_cvd = _z_from_stats(float(cvd), rolling_stats, "cvd", _DEFAULT_STDS["cvd"])
        z_int = _z_from_stats(float(inten), rolling_stats, "intensity", _DEFAULT_STDS["intensity"])
        z_vol = _z_from_stats(float(vol), rolling_stats, "volume_ratio", _DEFAULT_STDS["volume_ratio"])
        return float(w.w_m30 * z_m30 + w.w_m60 * z_m60 + w.w_cvd * z_cvd + w.w_intensity * z_int + w.w_volume_ratio * z_vol)

    if direction == -1:
        # 对称：单边下跌时 m30/m60 为负，但分数应为正
        z_m30 = _z_from_stats(-float(m30), rolling_stats, "m30", _DEFAULT_STDS["m30"])
        z_m60 = _z_from_stats(-float(m60), rolling_stats, "m60", _DEFAULT_STDS["m60"])
        z_cvd = _z_from_stats(-float(cvd), rolling_stats, "cvd", _DEFAULT_STDS["cvd"])
        z_int = _z_from_stats(float(inten), rolling_stats, "intensity", _DEFAULT_STDS["intensity"])
        z_vol = _z_from_stats(float(vol), rolling_stats, "volume_ratio", _DEFAULT_STDS["volume_ratio"])
        return float(w.w_m30 * z_m30 + w.w_m60 * z_m60 + w.w_cvd * z_cvd + w.w_intensity * z_int + w.w_volume_ratio * z_vol)

    return 0.0


def trend_signal(
    features: Any,
    rolling_stats: Optional[Dict[str, Any]] = None,
    config: Optional[AlphaConfig] = None,
) -> Tuple[float, int]:
    """趋势延续信号（TREND_UP/DOWN 专用）

    条件（算法核心 #20）：
      Long (TREND_UP):
        M30>0 and M60>0 and CVD30>0 and Intensity>1.5 and VolumeRatio>1.5
        and 突破5m high后回撤0.03-0.08%再启动
      Short (TREND_DOWN): 对称

    分数（算法核心 #21）：
      Score_trend_long =0.30*z(M30)+0.20*z(M60)+0.25*z(CVD)+0.15*z(intensity)+0.10*z(volume_ratio)
      Short 对称（对 M30/M60/CVD 取反）

    zscore 同 MR，需传入 rolling_stats

    返回:
        (score, direction)  direction: 1=做多, -1=做空, 0=无信号

    供 strategy.py 调用:
        # 先 detect_regime
        if regime == Regime.TREND_UP:
            score, direction = trend_signal(features, rolling_stats)
            if direction == 1 and score > trend_thr:
                # 再做成本过滤 expected_net>1.5bps
    """
    cfg = config or AlphaConfig()
    feat = _extract_trend_features(features)

    long_ok, long_reason = _check_trend_long(feat, cfg, features)
    short_ok, short_reason = _check_trend_short(feat, cfg)

    if long_ok and short_ok:
        s_l = _score_trend(feat, rolling_stats, cfg, 1)
        s_s = _score_trend(feat, rolling_stats, cfg, -1)
        if s_l >= s_s:
            logger.debug(f"[Trend] both triggered pick long s={s_l:.3f} vs {s_s:.3f}")
            return float(s_l), 1
        else:
            return float(s_s), -1

    if long_ok:
        score = _score_trend(feat, rolling_stats, cfg, 1)
        logger.debug(f"[Trend] long triggered score={score:.3f} feat={feat}")
        return float(score), 1

    if short_ok:
        score = _score_trend(feat, rolling_stats, cfg, -1)
        logger.debug(f"[Trend] short triggered score={score:.3f} feat={feat}")
        return float(score), -1

    logger.debug(f"[Trend] no signal long:{long_reason} short:{short_reason}")
    return 0.0, 0


def trend_signal_detailed(
    features: Any,
    rolling_stats: Optional[Dict[str, Any]] = None,
    config: Optional[AlphaConfig] = None,
) -> Dict[str, Any]:
    """详细版供回测/监控"""
    cfg = config or AlphaConfig()
    feat = _extract_trend_features(features)
    s_l = _score_trend(feat, rolling_stats, cfg, 1)
    s_s = _score_trend(feat, rolling_stats, cfg, -1)
    long_ok, long_r = _check_trend_long(feat, cfg, features)
    short_ok, short_r = _check_trend_short(feat, cfg)
    return {
        "feat": feat,
        "score_long": s_l,
        "score_short": s_s,
        "long_ok": long_ok,
        "short_ok": short_ok,
        "long_reason": long_r,
        "short_reason": short_r,
    }


# ============================================================
# 5. 策略分发（可选，供 strategy.py 统一入口）
# ============================================================
def alpha_signal(
    features: Any,
    regime: Any,
    rolling_stats: Optional[Dict[str, Any]] = None,
    config: Optional[AlphaConfig] = None,
) -> Tuple[float, int, str]:
    """按 regime 自动分发到对应 alpha

    返回 (score, direction, strategy_type)
    """
    # 兼容 Regime 传入为 int/str
    try:
        from .regime import Regime
        if not isinstance(regime, Regime):
            # 尝试转换为 Regime
            if isinstance(regime, str):
                regime = Regime[regime.upper()]
            elif isinstance(regime, int):
                regime = Regime(regime)
    except Exception:
        pass

    # 字符串 regime 兼容
    r_name = str(regime).upper() if regime is not None else ""
    # 判断
    if r_name in ("RANGE", "1", "REGIME.RANGE"):
        s, d = mean_reversion_signal(features, rolling_stats, config)
        return s, d, "mean_reversion"
    if r_name in ("TREND_UP", "2", "TREND_DOWN", "3"):
        s, d = trend_signal(features, rolling_stats, config)
        return s, d, "trend"
    # EXTREME/LOCKED 不给信号
    return 0.0, 0, "none"
