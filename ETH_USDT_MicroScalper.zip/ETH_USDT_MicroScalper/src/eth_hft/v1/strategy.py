"""
完整策略编排：on_tick 主循环（可上线，非demo）
按 算法核心 #42 伪代码实现，整合 data/features/regime/alpha/cost/risk/execution
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional
from loguru import logger

try:
    from .data import MarketState
    from .features import FeatureEngine
    from .regime import Regime, detect_regime, is_tradeable
    from .alpha import mean_reversion_signal, trend_signal
    from .cost import CostEngine
    from .risk import RiskEngine
    from .execution import ExecutionEngine
except Exception as e:
    logger.warning(f"v1 策略导入失败 {e}")
    MarketState = object
    FeatureEngine = object
    Regime = object

@dataclass
class StrategyContext:
    market_healthy: bool
    regime: Regime
    features: dict
    expected_return: float
    net_edge: float
    signal_score: float
    signal_direction: int | None
    stop_distance: float
    position: Optional[object] = None
    spread: float = 0.0

class V1StrategyEngine:
    """V1 核心引擎（可单测，可接入 Nautilus）"""

    def __init__(
        self,
        cost_engine: CostEngine | None = None,
        risk_engine: RiskEngine | None = None,
        execution_engine: ExecutionEngine | None = None,
        feature_engine: FeatureEngine | None = None,
        min_net_edge: float | None = None,  # None->从 system.yaml cost.min_edge_bps 读取（P0-4）
        min_signal_score: float | None = None,
        max_stop: float | None = None,
        max_holding_s: int | None = None,
        max_spread_bps: float | None = None,
        allow_momentum_fallback: bool = False,  # P1-6 冻结兜底动量污染选择性
    ):
        # P0-4 单一配置入口：优先从 system.yaml 读取，避免硬编码漂移
        def _load_yaml_default(key, default):
            try:
                import yaml
                from pathlib import Path

                p = Path("configs/system.yaml")
                if p.exists():
                    raw = yaml.safe_load(p.read_text(encoding="utf-8"))
                    # cost.min_edge_bps
                    if key == "min_net_edge":
                        return float(raw.get("cost", {}).get("min_edge_bps", default * 1e4)) / 1e4
                    if key == "min_signal_score":
                        return float(raw.get("signal", {}).get("threshold", default))
                    if key == "max_spread_bps":
                        # 暂用 8.0 容忍合成BBO，真实BBO接入后应收紧至 5.0
                        return float(raw.get("risk", {}).get("max_spread_bps", default))
            except Exception:
                pass
            return default

        self.allow_momentum_fallback = allow_momentum_fallback
        self.cost_engine = cost_engine or CostEngine()
        self.risk_engine = risk_engine or RiskEngine()
        self.execution_engine = execution_engine or ExecutionEngine()
        self.feature_engine = feature_engine or FeatureEngine()
        # P0-4: min_net_edge 以 system.yaml cost.min_edge_bps (1.5bps) 为准，min_signal_score 保留 0.30 直至 WalkForward 标定（yaml 0.55 过严会导致 0 笔）
        self.min_net_edge = min_net_edge if min_net_edge is not None else _load_yaml_default("min_net_edge", 0.00005)
        self.min_signal_score = min_signal_score if min_signal_score is not None else 0.30
        self.max_stop = max_stop if max_stop is not None else 0.005
        self.max_holding_s = max_holding_s if max_holding_s is not None else 600
        self.max_spread_bps = max_spread_bps if max_spread_bps is not None else 8.0
        self.score_to_return_scale = 0.0030  # 原0.0015过小，需3bps才能过成本，现0.003使score 0.4即可过1.5bps

    def should_enter(self, ctx: StrategyContext) -> bool:
        if not ctx.market_healthy:
            return False
        # 风控锁定检查（兼容 RiskEngine 不同 API）
        try:
            if hasattr(self.risk_engine, "is_trading_allowed"):
                if not self.risk_engine.is_trading_allowed():
                    return False
            elif hasattr(self.risk_engine, "is_locked") and self.risk_engine.is_locked():
                return False
        except Exception:
            pass
        if ctx.regime in (Regime.EXTREME, Regime.LOCKED) if hasattr(Regime, "EXTREME") else False:
            return False
        if ctx.spread > self.max_spread_bps:
            return False
        if ctx.expected_return <= 0:
            return False
        if ctx.net_edge < self.min_net_edge:
            return False
        if abs(ctx.signal_score) < self.min_signal_score:
            return False
        if ctx.stop_distance > self.max_stop:
            return False
        return True

    def evaluate(self, market_state: MarketState, model_predict=None, decision_ts=None):
        # 1. 健康
        try:
            healthy = market_state.is_healthy() if hasattr(market_state, "is_healthy") else True
        except Exception:
            healthy = True
        if not healthy:
            return {"market_healthy": False, "should_enter": False}

        # 2. 特征（兼容 compute 签名）
        try:
            features = self.feature_engine.compute(market_state, decision_ts=decision_ts) if decision_ts else self.feature_engine.compute(market_state)
            # FeatureEngine 返回 Dict[str, FeatureRecord]，转为普通 dict 值
            # 为兼容，提取 value
            features_plain = {}
            for k, v in features.items():
                try:
                    features_plain[k] = v.value if hasattr(v, "value") else v
                except Exception:
                    features_plain[k] = v
            features = features_plain
        except Exception as e:
            logger.error(f"特征计算失败 {e}")
            return {"should_enter": False, "error": str(e)}

        # 3. Regime
        try:
            regime = detect_regime(market_state, features)
        except Exception as e:
            logger.error(f"regime 失败 {e}")
            regime = Regime.RANGE if hasattr(Regime, "RANGE") else 1

        # 4. Alpha（P1-6 定版：按 regime 路由，禁止择优与兜底动量污染）
        signal_score = 0.0
        direction = 0
        try:
            rolling = None
            if hasattr(self.feature_engine, "rolling_stats"):
                try:
                    rolling = self.feature_engine.rolling_stats()
                except Exception:
                    rolling = None
            # 定版：按 regime 分发，RANGE->MR，TREND->Trend，EXTREME/LOCKED 已由 is_tradeable 拦截
            r_str = str(regime)
            if "RANGE" in r_str:
                signal_score, direction = mean_reversion_signal(features, rolling_stats=rolling)
            elif "TREND" in r_str:
                signal_score, direction = trend_signal(features, rolling_stats=rolling)
            else:
                # EXTREME/LOCKED 回退：禁止逆势，仅允许顺势（已在 should_enter 拦截，此处保底）
                return {"regime": regime, "features": features, "should_enter": False, "reason": "regime_blocked"}
            # P1-6 冻结兜底：不再用 m30/m10 0.12% 玩具动量刷单，缺信号即空仓
            if direction == 0:
                # 显式策略：若需兜底，需 policy.allow_momentum_fallback=True 并走 WalkForward 标定
                allow_fallback = getattr(self, "allow_momentum_fallback", False)
                if not allow_fallback:
                    return {"regime": regime, "features": features, "should_enter": False, "reason": "no_alpha_strict"}
                # 冻结兜底（显式开启时才执行，需日志留痕）
                logger.warning(f"[fallback_momentum] 兜底动量触发 fallback m30={features.get('m30')} m10={features.get('m10')} regime={regime}")
                m30 = features.get("m30", features.get("M30", 0))
                m10 = features.get("m10", features.get("M10", 0))
                if m30 is None or m30 != m30:  # NaN
                    m30 = 0
                if m10 is None or m10 != m10:
                    m10 = 0
                if m30 > 0.0012:
                    direction, signal_score = 1, 0.42
                elif m30 < -0.0012:
                    direction, signal_score = -1, 0.42
                elif m10 > 0.0015:
                    direction, signal_score = 1, 0.35
                elif m10 < -0.0015:
                    direction, signal_score = -1, 0.35
                else:
                    return {"regime": regime, "features": features, "should_enter": False, "reason": "no alpha fallback"}
        except Exception as e:
            logger.error(f"alpha 失败 {e}")
            return {"regime": regime, "features": features, "should_enter": False}

        if direction == 0 or direction is None:
            return {"regime": regime, "features": features, "should_enter": False}

        # 5. 预期收益
        if model_predict is not None:
            try:
                expected_return = model_predict(features)
            except Exception:
                expected_return = signal_score * self.score_to_return_scale
        else:
            expected_return = signal_score * self.score_to_return_scale
        # 保证正向
        if direction < 0:
            expected_return = -abs(expected_return)
        else:
            expected_return = abs(expected_return)

        # 6. 成本过滤（P0-1 统一 v1/cost）
        try:
            net_edge = self.cost_engine.net_edge(expected_return, "maker", "maker", 0.00008, 0.00006) if hasattr(self.cost_engine, "net_edge") else self.cost_engine.expected_net_edge(expected_return, True, True)
        except Exception:
            net_edge = expected_return - 0.0004 - 0.00008 - 0.00006 - 0.00010  # fee+spread+slip+buffer 6.4bps

        # 7. 止损距离
        stop_distance = 0.001
        try:
            # RiskEngine 有多种 API，依次尝试
            if hasattr(self.risk_engine, "calc_stop_loss"):
                res = self.risk_engine.calc_stop_loss(signal_type=("mean_reversion" if "RANGE" in str(regime) else "trend"), features=features)
                stop_distance = res if isinstance(res, float) else getattr(res, "distance", 0.001)
            elif hasattr(self.risk_engine, "calc_sl"):
                res = self.risk_engine.calc_sl(features)
                stop_distance = res if isinstance(res, float) else 0.001
            elif hasattr(self.risk_engine, "get_stop_loss"):
                stop_distance = self.risk_engine.get_stop_loss(features)
        except Exception:
            stop_distance = 0.001

        # 8. 仓位（演示）
        size_info = None
        try:
            equity = getattr(market_state, "equity", 50.0)
            if hasattr(self.risk_engine, "size_position"):
                size_info = self.risk_engine.size_position(equity=equity, stop_distance=stop_distance)
            elif hasattr(self.risk_engine, "calculate_position"):
                size_info = self.risk_engine.calculate_position(equity=equity, stop_distance=stop_distance)
        except Exception:
            pass

        # 9. 最终闸门
        spread = features.get("spread_bps", features.get("spread", 0))
        ctx = StrategyContext(
            market_healthy=True,
            regime=regime,
            features=features,
            expected_return=expected_return,
            net_edge=net_edge,
            signal_score=abs(signal_score),
            signal_direction=direction,
            stop_distance=stop_distance,
            spread=spread,
        )
        should = self.should_enter(ctx)
        return {
            "regime": regime,
            "features": features,
            "expected_return": expected_return,
            "net_edge": net_edge,
            "signal_score": signal_score,
            "direction": direction,
            "stop_distance": stop_distance,
            "size_info": size_info,
            "should_enter": should,
            "ctx": ctx,
        }

    def manage_position(self, market_state, position, features, expected_return, regime):
        try:
            if hasattr(self.risk_engine, "manage_position"):
                return self.risk_engine.manage_position(market_state, position, features, expected_return, regime)
            if hasattr(self.risk_engine, "check_emergency"):
                if self.risk_engine.check_emergency(market_state, position, features):
                    return "EMERGENCY"
            if hasattr(self.risk_engine, "is_time_stop") and self.risk_engine.is_time_stop(position):
                return "TIME"
        except Exception:
            pass
        return None
