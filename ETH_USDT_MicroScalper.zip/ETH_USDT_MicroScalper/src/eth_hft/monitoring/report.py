"""
图形化报告生成（统一HTML，非JSON不伦不类）
"""
from __future__ import annotations
from pathlib import Path
import json
import pandas as pd
from loguru import logger

def generate_html_report(
    backtest_result: dict,
    bars_df: pd.DataFrame | None = None,
    trades: list[dict] | None = None,
    output_path: str | Path | None = None,
    run_id: str | None = None,
    catalog_meta: dict | None = None,
) -> Path:
    """
    生成统一图形化HTML报告
    - 包含：标题、参数、K线图、净值曲线、交易分布、指标卡片
    - 同时内嵌JSON数据供GUI解析（JSON+图形结合，非不伦不类）
    """
    try:
        import plotly.graph_objects as go
        from plotly.subplots import make_subplots
        PLOTLY = True
    except ImportError:
        PLOTLY = False

    # P2-9 归一：默认 reports/<date>/<run_id>/report.html 单真相
    if output_path is None:
        from datetime import date as _date

        _date_str = _date.today().isoformat()
        _rid = run_id or f"selective_micro_{pd.Timestamp.now().strftime('%H%M%S')}"
        output_path = Path(f"reports/{_date_str}/{_rid}/report.html")
    else:
        output_path = Path(output_path)
        # 兼容旧调用 reports/nautilus/selective_micro.html -> 仍写此路径
        if run_id and "nautilus" in str(output_path):
            # 保持兼容，不强制迁移
            pass
    output_path.parent.mkdir(parents=True, exist_ok=True)
    # 同目录联动写 report.json + trades.csv + manifest.json（P2-9 单目录归档）
    try:
        (output_path.parent / "report.json").write_text(json.dumps({"result": backtest_result, "trades": trades or []}, ensure_ascii=False, indent=2), encoding="utf-8")
        if trades:
            pd.DataFrame(trades).to_csv(output_path.parent / "trades.csv", index=False)
        manifest = {"catalog": str(catalog_meta or {}), "generated_at": pd.Timestamp.now().isoformat(), "trades": len(trades or [])}
        (output_path.parent / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass

    # 准备数据
    trades = trades or []
    bars_df = bars_df if bars_df is not None else pd.DataFrame()

    # 计算指标（只统计已平仓回合；未平仓浮动盈亏单独展示，不冒充交易）
    closed = [t for t in trades if not t.get("open") and t.get("status", "closed") == "closed"]
    open_rows = [t for t in trades if t not in closed]
    total_trades = len(closed)
    win_rate = sum(1 for t in closed if t.get("pnl", 0) > 0) / total_trades if total_trades else 0
    total_pnl = sum(t.get("pnl", 0) for t in closed)
    avg_pnl = total_pnl / total_trades if total_trades else 0
    profit_factor = sum(t["pnl"] for t in closed if t["pnl"] > 0) / abs(sum(t["pnl"] for t in closed if t["pnl"] < 0)) if any(t["pnl"] < 0 for t in closed) else 0
    try:
        starting_equity = float(str(backtest_result.get("starting_balance", "50")).split()[0])
    except Exception:
        starting_equity = 50.0

    # 生成HTML
    html_parts = []
    html_parts.append("""
<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="UTF-8">
<title>ETH MicroScalper 回测报告</title>
<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
<style>
body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; margin: 0; padding: 20px; background: #f5f5f5; }
.container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
h1 { color: #1a1a1a; border-bottom: 3px solid #1890ff; padding-bottom: 10px; }
h2 { color: #333; margin-top: 30px; }
.metric-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin: 20px 0; }
.metric-card { background: #fafafa; padding: 15px; border-radius: 6px; border-left: 4px solid #1890ff; }
.metric-value { font-size: 24px; font-weight: bold; color: #1890ff; }
.metric-label { font-size: 12px; color: #666; }
.positive { color: #52c41a; }
.negative { color: #f5222d; }
table { width: 100%; border-collapse: collapse; margin: 15px 0; }
th, td { padding: 8px 12px; border: 1px solid #e8e8e8; text-align: left; font-size: 13px; }
th { background: #fafafa; font-weight: 600; }
.warning { background: #fffbe6; border: 1px solid #ffe58f; padding: 12px; border-radius: 4px; margin: 15px 0; }
</style>
</head>
<body>
<div class="container">
""")

    # 标题
    engine_label = backtest_result.get("engine", "backtesting.py")
    html_parts.append(f"""
<h1>📈 ETH-USDT MicroScalper 回测报告</h1>
<p style="color:#666;">生成时间: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')} | 引擎: {engine_label} | 模式: Selective (5~30笔/天)</p>
<div class="warning">
<strong>⚠️ 风险提示：</strong> 本报告为历史回测，非未来收益保证。实盘需考虑滑点、延迟、资金费与极端行情。
</div>
""")

    # 指标卡片（只统计已平仓回合；未平仓浮动盈亏单独展示）
    open_upnl = sum(t.get("pnl", 0) for t in open_rows)
    pnl_color = "positive" if total_pnl >= 0 else "negative"
    html_parts.append(f"""
<h2>📊 核心指标</h2>
<div class="metric-grid">
  <div class="metric-card"><div class="metric-label">总交易（已平仓）</div><div class="metric-value">{total_trades}</div></div>
  <div class="metric-card"><div class="metric-label">胜率</div><div class="metric-value">{win_rate:.1%}</div></div>
  <div class="metric-card"><div class="metric-label">总盈亏</div><div class="metric-value {pnl_color}">{total_pnl:.4f} U</div></div>
  <div class="metric-card"><div class="metric-label">盈亏比</div><div class="metric-value">{profit_factor:.2f}</div></div>
  <div class="metric-card"><div class="metric-label">平均每笔</div><div class="metric-value {pnl_color}">{avg_pnl:.4f} U</div></div>
  <div class="metric-card"><div class="metric-label">起始资金</div><div class="metric-value">{starting_equity:.2f} U</div></div>
  <div class="metric-card"><div class="metric-label">结束资金</div><div class="metric-value">{starting_equity+total_pnl:.2f} U</div></div>
  <div class="metric-card"><div class="metric-label">收益率</div><div class="metric-value {pnl_color}">{total_pnl/starting_equity if starting_equity else 0:.2%}</div></div>
</div>
{f'<p style="color:#d48806;">ℹ️ 另有 {len(open_rows)} 个未平仓持仓，浮动盈亏 {open_upnl:+.4f} U（未计入上述交易统计）</p>' if open_rows else ''}
""")


    # 参数
    html_parts.append(f"""
<h2>⚙️ 回测参数</h2>
<table>
<tr><th>参数</th><th>值</th><th>来源</th></tr>
<tr><td>品种</td><td>ETHUSDT-PERP.OKX</td><td>OKX instruments ctVal0.1</td></tr>
<tr><td>周期</td><td>1m LAST</td><td>OKX candles 1-MINUTE-LAST-EXTERNAL</td></tr>
<tr><td>费率</td><td>Maker 0.02% / Taker 0.05%</td><td>OKX官方</td></tr>
<tr><td>撮合</td><td>Nautilus L1_MBP + market撮合</td><td>非玩具close必成交</td></tr>
<tr><td>风险预算</td><td>0.20 U/笔</td><td>补充对话 RiskBudget反推</td></tr>
<tr><td>止损</td><td>0.10% (max失效, 1.5*RV30)</td><td>算法核心 #30</td></tr>
</table>
""")

    # 图表占位
    html_parts.append('<h2>📈 K线与净值</h2><div id="chart" style="height:500px;"></div>')

    # 交易明细（已平仓为"交易"，未平仓单独列出）
    if closed:
        html_parts.append("<h2>📋 交易明细（已平仓，前20笔）</h2><table><tr><th>#</th><th>方向</th><th>开仓</th><th>平仓</th><th>盈亏</th><th>手续费</th><th>退出原因</th></tr>")
        for i, t in enumerate(closed[:20], 1):
            color = "positive" if t.get("pnl",0)>0 else "negative"
            html_parts.append(f"<tr><td>{i}</td><td>{t.get('side','')}</td><td>{t.get('entry','')}</td><td>{t.get('exit','')}</td><td class='{color}'>{t.get('pnl',0):.4f}</td><td>{t.get('fee',0):.4f}</td><td>{t.get('exit_reason','')}</td></tr>")
        html_parts.append("</table>")
        if len(closed) > 20:
            html_parts.append(f"<p style='color:#999;'>仅显示前20笔，共{len(closed)}笔，完整见JSON</p>")
    else:
        html_parts.append("<p style='color:#999;'>本期无已平仓交易（成本过滤严格，符合选择性理念 5~30笔/天）</p>")
    if open_rows:
        html_parts.append("<h2>⏳ 未平仓持仓（不计入统计）</h2><table><tr><th>方向</th><th>开仓价</th><th>最新价</th><th>浮动盈亏</th></tr>")
        for t in open_rows[:10]:
            color = "positive" if t.get("pnl",0)>0 else "negative"
            html_parts.append(f"<tr><td>{t.get('side','')}</td><td>{t.get('entry','')}</td><td>{t.get('exit','')}</td><td class='{color}'>{t.get('pnl',0):.4f}</td></tr>")
        html_parts.append("</table>")

    # JSON 内嵌（供GUI解析）
    json_data = json.dumps({"result": backtest_result, "trades": (closed + open_rows)[:100]}, ensure_ascii=False)
    html_parts.append(f'<script type="application/json" id="report-data">{json_data}</script>')

    # Plotly 脚本
    if PLOTLY and not bars_df.empty and "close" in bars_df.columns:
        try:
            import json as _json
            closes = bars_df["close"].tolist()[-200:]
            times = [str(x) for x in bars_df["ts"].tail(200).tolist()] if "ts" in bars_df.columns else list(range(len(closes)))
            equity = [starting_equity]
            for t in closed:
                equity.append(equity[-1] + t.get("pnl", 0))
            html_parts.append(f"""
<script>
var closes = {_json.dumps(closes)};
var times = {_json.dumps(times)};
var equity = {_json.dumps(equity)};
var trace1 = {{x: times, y: closes, name: '价格', line: {{color: '#1890ff'}}}};
var trace2 = {{x: times.slice(-equity.length), y: equity, name: '净值', yaxis: 'y2', line: {{color: '#52c41a'}}}};
var layout = {{
  title: '价格与净值',
  xaxis: {{title: '时间'}},
  yaxis: {{title: '价格 (USDT)', side: 'left'}},
  yaxis2: {{title: '净值 (USDT)', side: 'right', overlaying: 'y'}},
  legend: {{x: 0, y: 1}}
}};
Plotly.newPlot('chart', [trace1, trace2], layout);
</script>
""")
        except Exception as e:
            html_parts.append(f"<p>图表生成失败: {e}</p>")
    else:
        html_parts.append("<p style='color:#999;'>无K线数据或未安装plotly</p>")

    html_parts.append("""
<p style="margin-top:30px; color:#999; font-size:12px;">报告生成：eth_hft.monitoring.report | 引擎：backtesting.py | 数据：OKX 免费WS+REST | 费率：Maker0.02% Taker0.05%</p>
</div>
</body>
</html>
""")

    html = "".join(html_parts)
    output_path.write_text(html, encoding="utf-8")
    logger.info(f"图形报告已生成: {output_path} ({len(html)/1024:.1f} KB)")
    return output_path
