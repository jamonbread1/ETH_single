"""风控引擎：整合 KillSwitch + 仓位 + 日损
"""
from __future__ import annotations
from .kill_switch import KillSwitch, KillConfig
from .position import IsolatedPosition
from loguru import logger

class RiskEngine:
    def __init__(self, kill_cfg: KillConfig | None = None):
        self.kill = KillSwitch(kill_cfg or KillConfig())
        self.daily_pnl = 0.0
        self.position: IsolatedPosition | None = None

    def before_entry(self, **kwargs) -> bool:
        reason = self.kill.check(**kwargs) if kwargs else None
        if reason:
            self.kill.trigger(reason)
            return False
        if self.kill.triggered:
            logger.warning(f"KillSwitch 未重置 {self.kill.triggered} 禁止开仓")
            return False
        return True

    def on_fill(self, pos: IsolatedPosition):
        self.position = pos

    def on_close(self, pnl: float):
        self.daily_pnl += pnl
        self.kill.on_trade_result(pnl)
        self.position = None
