"""KillSwitch：极端行情熔断
触发条件来自对话设计，必须可解释
"""
from __future__ import annotations
from dataclasses import dataclass
from loguru import logger
from ..core.types import KillReason

@dataclass
class KillConfig:
    atr_multiple: float = 4.0
    spread_multiple: float = 3.0
    book_collapse_pct: float = 0.7
    max_latency_ms: int = 500
    consecutive_losses: int = 5
    cooldown_losses: int = 10
    daily_loss_limit_usdt: float = 200.0

class KillSwitch:
    def __init__(self, cfg: KillConfig):
        self.cfg = cfg
        self.triggered: KillReason | None = None
        self.consec_loss = 0

    def check(self, atr: float, atr_median: float, spread_bps: float, normal_spread_bps: float, book_drop_pct: float, latency_ms: float, daily_loss: float) -> KillReason | None:
        if atr_median and atr / atr_median > self.cfg.atr_multiple:
            return KillReason.ATR
        if normal_spread_bps and spread_bps / normal_spread_bps > self.cfg.spread_multiple:
            return KillReason.SPREAD
        if book_drop_pct > self.cfg.book_collapse_pct:
            return KillReason.BOOK_COLLAPSE
        if latency_ms > self.cfg.max_latency_ms:
            return KillReason.LATENCY
        if daily_loss < -self.cfg.daily_loss_limit_usdt:
            return KillReason.DAILY_LOSS
        if self.consec_loss >= self.cfg.cooldown_losses:
            return KillReason.CONSECUTIVE_LOSS
        return None

    def on_trade_result(self, pnl: float):
        if pnl < 0:
            self.consec_loss += 1
        else:
            self.consec_loss = 0
        if self.consec_loss >= self.cfg.consecutive_losses:
            logger.warning(f"连续亏损 {self.consec_loss} 次")

    def trigger(self, reason: KillReason):
        self.triggered = reason
        logger.error(f"KillSwitch 触发 {reason}")

    def reset(self):
        self.triggered = None
        self.consec_loss = 0
        logger.info("KillSwitch 已重置")
