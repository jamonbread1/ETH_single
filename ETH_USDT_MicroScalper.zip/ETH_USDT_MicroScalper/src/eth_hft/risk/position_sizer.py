"""仓位计算器：固定风险预算反推名义价值与所需保证金
核心公式（补充对话）：
    理论名义 = RiskBudget / StopLoss%
    所需杠杆 = 名义 / 保证金
    杠杆是结果，受交易所上限约束
"""
from __future__ import annotations
from dataclasses import dataclass
from ..core.instrument import InstrumentSpec, DEFAULT_ETH_SWAP

@dataclass
class SizingResult:
    """计算结果"""
    risk_budget_usdt: float
    stop_pct: float
    price: float
    theoretical_notional: float
    size_contracts: float
    notional_usdt: float
    leverage_needed: float
    margin_needed: float
    feasible: bool
    reason: str = ""

    def to_dict(self) -> dict:
        return self.__dict__

def calc_position(
    price: float,
    stop_pct: float,
    risk_budget_usdt: float,
    spec: InstrumentSpec = DEFAULT_ETH_SWAP,
    equity_usdt: float = 50.0,
    max_leverage: float = 100.0,
    min_margin_usdt: float = 0.3,
    risk_scale: float = 1.0,
) -> SizingResult:
    """计算仓位
    参数都有来源：
    - price: 当前价格（来自行情）
    - stop_pct: 止损距离（小数，如 0.001 =0.10%，来自信号失效或 ATR）
    - risk_budget: 每笔最大亏（来自 configs strategy.position.risk_budget_usdt）
    - spec: 合约规格（来自 OKX instruments）
    - risk_scale: 极端行情缩放（1.0 正常，0.5 高波动，0 停止）
    """
    if risk_scale <= 0:
        return SizingResult(risk_budget_usdt, stop_pct, price, 0, 0, 0, 0, 0, False, "风险缩放为0，停止开仓")
    if stop_pct <= 0:
        return SizingResult(risk_budget_usdt, stop_pct, price, 0, 0, 0, 0, 0, False, "止损距离非法")
    scaled_risk = risk_budget_usdt * risk_scale
    theoretical = scaled_risk / stop_pct  # 理论名义 USDT
    # 换算：size(张) = notional / (ctVal*price)，OKX ETH-USDT-SWAP ctVal=0.1 ETH/张（唯一真源 instrument.py:58）
    raw_size = theoretical / (spec.ct_val * price) if spec.ct_val else theoretical / price
    # 按 lotSz 取整（向下）
    size = spec.round_size(raw_size)
    if not spec.is_valid_size(size):
        return SizingResult(scaled_risk, stop_pct, price, theoretical, size, 0, 0, 0, False, f"数量 {size} < minSz {spec.min_sz}")
    # 实际名义
    notional = size * spec.ct_val * price  # 真实名义 = 张数 * 面值 * 价格
    # 也可用 spec.notional(price,size) 校验
    try:
        notional_check = spec.notional(price, size)
        # 若 ctVal 不是 1，则以 check 为准
        if abs(notional_check - notional) > 1e-6 and spec.ct_val != 1:
            notional = notional_check
    except Exception:
        pass
    # 所需杠杆与保证金
    # 优先用 max_leverage 计算最小保证金
    margin_needed = notional / max_leverage
    leverage_needed = notional / margin_needed if margin_needed else 0  # 即 max_leverage
    # 若计算出的保证金 < 用户最小意愿，则说明可以更低杠杆
    if margin_needed < min_margin_usdt:
        # 约束：保证金至少 min_margin，则实际杠杆降低
        leverage_needed = notional / min_margin_usdt
        margin_needed = min_margin_usdt
        if leverage_needed > max_leverage:
            leverage_needed = max_leverage
            margin_needed = notional / max_leverage
    # 检查保证金是否超过权益
    if margin_needed > equity_usdt:
        return SizingResult(scaled_risk, stop_pct, price, theoretical, size, notional, leverage_needed, margin_needed, False, "保证金超过权益")
    # 成本预检：Maker 双边 0.04U/100U 名义，若理论净收益 <0 则不应开仓（由外层成本过滤再审）
    return SizingResult(scaled_risk, stop_pct, price, theoretical, size, notional, leverage_needed, margin_needed, True, "可行")

def expected_pnl(notional: float, move_pct: float, fee_rate: float = 0.0004) -> float:
    """预期净盈亏（USDT）= 名义*波动 - 名义*费率"""
    return notional * move_pct - notional * fee_rate
