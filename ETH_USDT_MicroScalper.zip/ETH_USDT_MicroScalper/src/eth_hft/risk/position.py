"""逐仓保证金与强平距离核算（微仓专用）
补充说明：
- 逐仓保证金 ≠ 最大亏损，实际还受维持保证金/mark/手续费影响
- 止损不保证成交价，极端行情需 KillSwitch 熔断
- 1U 保证金在 100x 下约 1% 波动即接近强平，回测作保守估计
"""
from __future__ import annotations
from dataclasses import dataclass

@dataclass
class IsolatedPosition:
    side: str  # long/short
    entry_price: float
    size_usdt: float  # 名义价值
    margin_usdt: float
    leverage: int | float = 100
    size_contracts: float = 0.0  # 合约张数，便于对账

    def liquidation_price(self) -> float:
        """简化强平价：逐仓下约 1/leverage 的不利波动即接近强平
        额外 +0.2% 缓冲模拟维持保证金与手续费
        """
        if self.leverage <= 0:
            return self.entry_price
        if self.side == "long":
            return self.entry_price * (1 - 1/self.leverage + 0.002)
        else:
            return self.entry_price * (1 + 1/self.leverage - 0.002)

    def pnl(self, mark_price: float) -> float:
        if self.side == "long":
            return (mark_price - self.entry_price) / self.entry_price * self.size_usdt
        else:
            return (self.entry_price - mark_price) / self.entry_price * self.size_usdt

    def is_liquidated(self, mark_price: float) -> bool:
        liq = self.liquidation_price()
        if self.side == "long":
            return mark_price <= liq
        else:
            return mark_price >= liq

    def distance_to_liq_bps(self, mark_price: float) -> float:
        liq = self.liquidation_price()
        return abs(mark_price - liq) / mark_price * 1e4

    def fee(self, maker: bool = True, fee_rate: float = 0.0002) -> float:
        """单边手续费"""
        return self.size_usdt * fee_rate
