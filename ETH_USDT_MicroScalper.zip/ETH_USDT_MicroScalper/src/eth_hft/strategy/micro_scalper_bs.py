"""
MicroScalper — backtesting.py 适配版（kernc/backtesting.py 专业回测引擎）

2026-09 重构：弃用项目内 Nautilus 撮合链路，回测内核更换为 GitHub 开源的
backtesting.py（>=0.6，FractionalBacktest 支持加密货币小数仓位）。

当前唯一在役策略：TrendAdaptiveBS（v2 趋势自适应 ATR）。
旧固定bps策略 MicroScalperBS 已删除（2026-09 清理，数学期望为负）。
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from backtesting import Strategy
from loguru import logger


def rolling_atr(h, l, c, n: int) -> pd.Series:
    """因果 ATR（TR 的 SMA）。warmup 必须保持 NaN——bfill 会把"未来 n 根算出的波动率"
    泄漏给当前 bar（回测前视偏差，2026-09 全项目审查发现并修复）；策略用 isfinite 守卫跳过 NaN。"""
    h, l, c = pd.Series(h), pd.Series(l), pd.Series(c)
    pc = c.shift(1)
    tr = pd.concat([h - l, (h - pc).abs(), (l - pc).abs()], axis=1).max(axis=1)
    return tr.rolling(int(n)).mean()


def rolling_vr(close, k: int, win: int) -> pd.Series:
    """因果方差比：VR>1 趋势（正自相关）、VR<1 均值回归（负自相关）、≈1 随机游走。
    warmup 必须保持 NaN（bfill=前视，审查修复）；next 中 isfinite(vr) 守卫跳过 NaN 段。"""
    s = pd.Series(close)
    r1 = s.diff()
    rk = s.diff(int(k))
    var1 = r1.rolling(int(win)).var()
    vark = rk.rolling(int(win)).var()
    return (vark / (float(k) * var1)).replace([np.inf, -np.inf], np.nan)


class TrendAdaptiveBS(Strategy):
    """v2 趋势自适应（2026-09 优化版）——修复 v1 "高频送手续费"的结构性问题

    v1 死因：TP=8bps/SL=10bps、往返成本≥4.4bps、1m bar 噪声 ≈ 单笔期望为负，
    交易越多亏越快（143笔/-25.7%）。

    v2 设计原则（每一条都针对 v1 的病根）：
    1. 让利润奔跑：不用固定小 TP，止盈放在 6×ATR 远处，靠 ATR 移动止损（chandelier）退出
    2. 波动率自适应：SL/TP/死区全部用 ATR 表达，行情大小自动缩放（不再写死 bps）
    3. 只做有趋势的行情：|SMA_f−SMA_s| > 0.25×ATR（动量强度闸）+ 价格站在长期 SMA 正确一侧（方向闸）
    4. 交易频次内建抑制：入场后冷却 cooldown_bars 根 bar 才能再入场
    5. 波动率 scaled 成本闸门：预期毛利 = tp_atr×ATR%，市场死寂时自动不交易
    6. 风险恒定：qty = risk_usdt / (stop_atr×ATR)（杠杆是结果）
    """
    # ---- 信号 ----
    fast: int = 15
    slow: int = 80
    trend_len: int = 240        # 长期趋势滤网（1m 下≈4小时）
    atr_len: int = 14
    deadzone_atr: float = 0.25  # 动量强度闸：|SMA_f−SMA_s| 需 > 0.25×ATR
    # ---- 退出（全部 ATR 自适应）----
    stop_atr: float = 2.0       # 初始止损 = 2×ATR
    trail_atr: float = 1.5      # 移动止损 = 收高/低点 ∓ 1.5×ATR
    tp_atr: float = 6.0         # 远止盈 = 6×ATR（让利润奔跑）
    # ---- 频次 ----
    cooldown_bars: int = 15     # 平仓后冷却
    atr_floor_bps: float = 1.0  # ATR% 下限：死市场不交易
    # ---- 风险/成本 ----
    risk_usdt: float = 0.20
    use_cost_gate: bool = True
    min_edge_bps: float = 1.5
    commission_bps: float = 2.0
    spread_bps: float = 0.8
    slippage_bps: float = 0.6
    buffer_bps: float = 1.0

    def init(self):
        close = self.data.Close
        self.sma_f = self.I(lambda x: pd.Series(x).rolling(int(self.fast)).mean(), close,
                            name=f"SMA{int(self.fast)}", overlay=True)
        self.sma_s = self.I(lambda x: pd.Series(x).rolling(int(self.slow)).mean(), close,
                            name=f"SMA{int(self.slow)}", overlay=True)
        self.sma_t = self.I(lambda x: pd.Series(x).rolling(int(self.trend_len)).mean(), close,
                            name=f"SMA{int(self.trend_len)}", overlay=True)

        self.atr = self.I(rolling_atr, self.data.High, self.data.Low, close, self.atr_len,
                          name="ATR", overlay=False)
        self._last_exit_bar = -(10 ** 9)
        self._had_pos = False

    def _atr_bps(self) -> float:
        a = float(self.atr[-1])
        return a / float(self.data.Close[-1]) * 1e4 if np.isfinite(a) and a > 0 else 0.0

    def next(self):
        if self.orders:
            return
        price = float(self.data.Close[-1])
        atr = float(self.atr[-1])
        if not (np.isfinite(atr) and np.isfinite(self.sma_f[-1]) and np.isfinite(self.sma_s[-1])):
            return

        # ---- 持仓管理：ATR 移动止损 + 信号反转离场（TP 远，交给 trail）----
        if self.position:
            self._had_pos = True
            tr = self.trades[0]
            if tr.is_long:
                tr.sl = max(tr.sl or -np.inf, price - float(self.trail_atr) * atr)
                if self.sma_f[-1] < self.sma_s[-1] - float(self.deadzone_atr) * atr:
                    self.position.close()
            else:
                tr.sl = min(tr.sl or np.inf, price + float(self.trail_atr) * atr)
                if self.sma_f[-1] > self.sma_s[-1] + float(self.deadzone_atr) * atr:
                    self.position.close()
            return

        # 刚平仓：记录冷却起点
        if self._had_pos:
            self._had_pos = False
            self._last_exit_bar = len(self.data) - 1
        if len(self.data) - self._last_exit_bar < int(self.cooldown_bars):
            return

        # ---- 入场过滤链 ----
        atr_bps = self._atr_bps()
        if atr_bps < float(self.atr_floor_bps):          # 1) 市场活着吗
            return
        spread = self.sma_f[-1] - self.sma_s[-1]
        if abs(spread) < float(self.deadzone_atr) * atr: # 2) 动量强度够吗
            return
        direction = 1 if spread > 0 else -1
        if direction > 0 and price <= float(self.sma_t[-1]):   # 3) 长期趋势同向吗
            return
        if direction < 0 and price >= float(self.sma_t[-1]):
            return
        # 4) 波动率 scaled 成本闸门：预期毛利(到TP) − 全成本 > min_edge
        expected_bps = float(self.tp_atr) * atr_bps
        cost_bps = 2.0 * float(self.commission_bps) + float(self.spread_bps) + float(self.slippage_bps) + float(self.buffer_bps)
        if self.use_cost_gate and (expected_bps - cost_bps) <= float(self.min_edge_bps):
            return

        # ---- 风险恒定入场 ----
        # 止损距离（价格单位）= stop_atr×ATR；qty = risk / 止损距离（单位与引擎内部尺度一致）
        stop_dist = float(self.stop_atr) * atr
        qty = int(float(self.risk_usdt) / stop_dist) if stop_dist > 0 else 0
        if qty < 1:
            return
        if direction > 0:
            self.buy(size=qty, sl=price - float(self.stop_atr) * atr, tp=price + float(self.tp_atr) * atr)
        else:
            self.sell(size=qty, sl=price + float(self.stop_atr) * atr, tp=price - float(self.tp_atr) * atr)


class RegimeAdaptiveBS(Strategy):
    """v3 状态自适应（2026-09）——针对真实数据暴露的问题重构

    真实数据诊断（用户本地回测：40笔/胜率22.5%/-5.91%，毛利≈-0.8U）：
    1m 均线动量在真实行情的震荡时段没有优势，交易被成本磨损。
    v3 让数据自己选打法，且震荡市直接不交易：

    - 状态判别：方差比 VR(k) = Var(k期收益)/(k·Var(1期收益))，滚动窗口估计
        VR > hi  → 趋势状态 → 动量跟随（v2 逻辑：SMA差 + 长期趋势同向 + 移动止盈）
        VR < lo  → 均值回归状态 → 反转交易（价格偏离 z_len 均线超过 z_in×ATR 时反向，
                   目标=回归均线，止损 mr_stop_atr×ATR）
        中间     → 震荡/噪声 → 不交易（省下手续费与磨损，直接解决"送手续费"病根）
    - 出场：趋势仓 chandelier 移动止损；回归仓括弧单（SL/TP 到均值）
    - 通用：冷却控频、ATR% 活性下限、波动率 scaled 成本闸门、风险恒定仓位
    """
    # ---- 趋势模式（沿用 v2 结构）----
    fast: int = 15
    slow: int = 80
    trend_len: int = 240
    atr_len: int = 14
    deadzone_atr: float = 0.25
    stop_atr: float = 2.0
    trail_atr: float = 1.5
    tp_atr: float = 6.0
    # ---- 均值回归模式 ----
    z_len: int = 60          # 回归基准均线
    z_in: float = 1.8        # 入场偏离阈值（ATR 倍数）
    mr_stop_atr: float = 2.5 # MR 止损距离（下限，实际=max(此值, mr_sl_mult×|dev|)）
    mr_sl_mult: float = 1.3  # MR 止损=此倍数×|dev|（<1 则风险小于目标，R:R>1——寻优维度）
    mr_tp_mult: float = 1.0  # MR 目标=均线±(此倍数-1)×|dev|（>1 则吃回归过头，寻优维度）
    capture_mult: float = 1.0  # 入场经济学：预期捕捉 ≥ 此倍数×往返成本才进场（每笔不白送手续费）
    side_mode: str = "both"   # 开仓方向：both/long/short——OOS归因实证空头腿系统性亏损，单边化入寻优
    flow_gate: float = 0.0    # 流量闸门：|taker_z|≥此值才进场（0=不启用；Rubik主动买卖比，见 data/flow.py）
    # ---- 状态判别（方差比）----
    vr_len: int = 240        # 滚动估计窗口
    vr_k: int = 30           # 聚集尺度
    vr_hi: float = 1.10
    vr_lo: float = 0.90
    # ---- 通用 ----
    cooldown_bars: int = 15
    max_hold_bars: int = 120  # 持仓周期上限（bar 数；1m 下 5bar=5min）——时间止损，寻优维度
    atr_floor_bps: float = 1.0
    risk_usdt: float = 0.20
    use_cost_gate: bool = True
    min_edge_bps: float = 1.5
    commission_bps: float = 2.0
    spread_bps: float = 0.8
    slippage_bps: float = 0.6
    buffer_bps: float = 1.0

    def init(self):
        close = self.data.Close
        self.sma_f = self.I(lambda x: pd.Series(x).rolling(int(self.fast)).mean(), close,
                            name=f"SMA{int(self.fast)}", overlay=True)
        self.sma_s = self.I(lambda x: pd.Series(x).rolling(int(self.slow)).mean(), close,
                            name=f"SMA{int(self.slow)}", overlay=True)
        self.sma_t = self.I(lambda x: pd.Series(x).rolling(int(self.trend_len)).mean(), close,
                            name=f"SMA{int(self.trend_len)}", overlay=True)
        self.sma_z = self.I(lambda x: pd.Series(x).rolling(int(self.z_len)).mean(), close,
                            name=f"SMA{int(self.z_len)}", overlay=True)

        self.atr = self.I(rolling_atr, self.data.High, self.data.Low, close, self.atr_len,
                          name="ATR", overlay=False)

        self.vr = self.I(rolling_vr, close, self.vr_k, self.vr_len, name="VR", overlay=False)
        self._last_exit_bar = -(10 ** 9)
        self._in_pos = False
        self._entry_bar = -(10 ** 9)
        self._had_pos = False
        self._mode = None  # 'mom' | 'mr'

    def _cost_bps(self) -> float:
        return 2.0 * float(self.commission_bps) + float(self.spread_bps) + float(self.slippage_bps) + float(self.buffer_bps)

    def _qty(self, stop_dist: float) -> int:
        return int(float(self.risk_usdt) / stop_dist) if stop_dist > 0 else 0

    def _flow_ok(self, direction: int, mode: str) -> bool:
        """流量闸门（默认直通；make_flow_strategy 注入 taker_z 后覆写）。
        momo=同向确认（z 与方向同号且|z|≥gate）；mr=逆向拥挤（z 与方向反号且|z|≥gate）。"""
        return True

    def next(self):
        if self.orders:
            return
        price = float(self.data.Close[-1])
        atr = float(self.atr[-1])
        if not (np.isfinite(atr) and np.isfinite(self.sma_f[-1]) and np.isfinite(self.sma_s[-1])):
            return

        # ---- 持仓管理（按入场模式）----
        if self.position:
            self._had_pos = True
            if not self._in_pos:
                self._in_pos = True
                self._entry_bar = len(self.data) - 1
            if len(self.data) - 1 - self._entry_bar >= max(1, int(self.max_hold_bars)):
                self.position.close()  # 持仓周期上限（时间止损）：1m 下 5bar=5分钟，平衡点由寻优决定
                return
            tr = self.trades[0]
            if self._mode == "mom":
                # 趋势仓：chandelier 移动止损 + 信号反转离场
                if tr.is_long:
                    tr.sl = max(tr.sl or -np.inf, price - float(self.trail_atr) * atr)
                    if self.sma_f[-1] < self.sma_s[-1] - float(self.deadzone_atr) * atr:
                        self.position.close()
                else:
                    tr.sl = min(tr.sl or np.inf, price + float(self.trail_atr) * atr)
                    if self.sma_f[-1] > self.sma_s[-1] + float(self.deadzone_atr) * atr:
                        self.position.close()
            # 回归仓：SL/TP 括弧单由引擎 bar 内自动处理，无需干预
            return

        if self._had_pos:  # 刚平仓 → 冷却
            self._had_pos = False
            self._in_pos = False
            self._mode = None
            self._last_exit_bar = len(self.data) - 1
        if len(self.data) - self._last_exit_bar < int(self.cooldown_bars):
            return

        atr_bps = atr / price * 1e4
        if atr_bps < float(self.atr_floor_bps):
            return

        vr = float(self.vr[-1]) if np.isfinite(self.vr[-1]) else np.nan
        if not np.isfinite(vr):
            return

        # ================= 趋势状态：动量跟随 =================
        if vr >= float(self.vr_hi):
            spread = self.sma_f[-1] - self.sma_s[-1]
            if abs(spread) < float(self.deadzone_atr) * atr:
                return
            direction = 1 if spread > 0 else -1
            if direction > 0 and price <= float(self.sma_t[-1]):
                return
            if direction < 0 and price >= float(self.sma_t[-1]):
                return
            expected_bps = float(self.tp_atr) * atr_bps
            if self.use_cost_gate and expected_bps < max(
                    self._cost_bps() + float(self.min_edge_bps), float(self.capture_mult) * self._cost_bps()):
                return
            if (direction < 0 and str(self.side_mode) == "long") or \
                    (direction > 0 and str(self.side_mode) == "short"):
                return  # 单边模式：方向被禁用
            if not self._flow_ok(int(direction), "mom"):
                return  # 流量闸门：主动流未同向确认
            qty = self._qty(float(self.stop_atr) * atr)
            if qty < 1:
                return
            self._mode = "mom"
            if direction > 0:
                self.buy(size=qty, sl=price - float(self.stop_atr) * atr, tp=price + float(self.tp_atr) * atr)
            else:
                self.sell(size=qty, sl=price + float(self.stop_atr) * atr, tp=price - float(self.tp_atr) * atr)
            return

        # ================= 均值回归状态：反向回归 =================
        if vr <= float(self.vr_lo):
            mean = float(self.sma_z[-1])
            dev = price - mean
            dev_atr = dev / atr
            if abs(dev_atr) < float(self.z_in):
                return
            expected_bps = abs(dev) / price * 1e4  # 预期毛利 = 回归到均线的距离
            if self.use_cost_gate and expected_bps < max(
                    self._cost_bps() + float(self.min_edge_bps), float(self.capture_mult) * self._cost_bps()):
                return
            # R:R 可调（2026-09 算法审查修复）：旧版 SL 恒 1.3×|dev| 而 TP=1.0×|dev|——
            # 风险结构性大于目标（R:R=1:0.77），胜率<57% 必亏。SL/TP 倍数均为寻优维度；
            # SL 下限仍为 mr_stop_atr×ATR；TP 可吃回归过头（mr_tp_mult>1），订单恒合法
            sl_dist = max(float(self.mr_stop_atr) * atr, float(self.mr_sl_mult) * abs(dev))
            tp = mean - (float(self.mr_tp_mult) - 1.0) * abs(dev) if dev > 0 \
                else mean + (float(self.mr_tp_mult) - 1.0) * abs(dev)
            if (dev > 0 and str(self.side_mode) == "long") or \
                    (dev < 0 and str(self.side_mode) == "short"):
                return  # 单边模式：该侧回归被禁用
            if not self._flow_ok(-1 if dev > 0 else 1, "mr"):
                return  # 流量闸门：逆向拥挤证据不足
            qty = self._qty(sl_dist)
            if qty < 1:
                return
            self._mode = "mr"
            if dev > 0:  # 偏高 → 做空回归
                self.sell(size=qty, sl=price + sl_dist, tp=tp)
            else:        # 偏低 → 做多回归
                self.buy(size=qty, sl=price - sl_dist, tp=tp)
            return

        # ================= 震荡状态：不交易 =================
        return


class FactorAlphaBS(Strategy):
    """v4 因子Alpha（2026-09）——v1「8因子」在 1m K线上的忠实移植 + v3 风控骨架

    回答「v1 8因子还有没有价值」：OBI/MPD 需要盘口tick（无该数据，剔除并按权重占比
    重归一）；CVD 用 bar 内符号成交量代理 sign(close-open)*volume 累加；
    Momentum/Intensity/VolumeRatio/RV/Position5m 全部按 v1 原公式还原
    （时间窗从秒级重解释为 bar 级：M10/M30/M60 → 1/3/5 根）。

    信号（v1/alpha.py 原权重，重归一）：
      trend_score = 0.333*z(m3) + 0.222*z(m5) + 0.278*z(cvd) + 0.167*z(intensity)
                  （原 0.30 M30 + 0.20 M60 + 0.25 CVD + 0.15 Intensity + 0.10 VolRatio，
                    VolRatio 与 intensity 共线度高，其 0.10 并入 intensity）
      mr_score    = 0.40*z(−m1) + 0.267*z(−m3) + 0.333*z(cvd)
                  （原 0.30 + 0.20 + 0.25 + [OBI 0.15 + MPD 0.10 剔除] 后重归一）
      z() 严格沿用 v1 防泄漏：shift(1).rolling(60, min20)
    状态切换沿用 v3：VR>vr_hi 趋势模式用 trend_score；VR<vr_lo 回归模式用 mr_score；震荡不交易。
    风控骨架与 v3 完全一致（ATR止损/移动止盈/冷却/成本闸门/风险恒定仓位）。
    """
    # ---- 因子参数 ----
    z_window: int = 60       # v1 zscore 窗口
    z_min: int = 20
    cvd_len: int = 30        # CVD 累加窗口（30bar）
    inten_len: int = 30      # Intensity median 窗口
    vr_len: int = 240        # 方差比窗口（状态判别）
    vr_k: int = 30
    vr_hi: float = 1.10
    vr_lo: float = 0.90
    score_thr: float = 0.8   # v1 文档建议阈值 0.5~1.0
    # ---- 趋势模式 ----
    trend_len: int = 240
    deadzone_atr: float = 0.25
    stop_atr: float = 2.0
    trail_atr: float = 1.5
    tp_atr: float = 6.0
    atr_len: int = 14
    # ---- 回归模式 ----
    z_len: int = 60
    mr_stop_atr: float = 2.5
    mr_sl_mult: float = 1.3  # MR 止损=此倍数×|dev|（R:R 维度）
    mr_tp_mult: float = 1.0  # MR 目标=均线±(此倍数-1)×|dev|
    capture_mult: float = 1.0  # 入场经济学：预期捕捉 ≥ 此倍数×往返成本
    side_mode: str = "both"   # 开仓方向：both/long/short（OOS方向归因驱动）
    flow_gate: float = 0.0    # 流量闸门：|taker_z|≥此值才进场（0=不启用）
    # ---- 通用 ----
    cooldown_bars: int = 15
    max_hold_bars: int = 120  # 持仓周期上限（bar 数；1m 下 5bar=5min）——时间止损，寻优维度
    atr_floor_bps: float = 1.0
    risk_usdt: float = 0.20
    use_cost_gate: bool = True
    min_edge_bps: float = 1.5
    commission_bps: float = 2.0
    spread_bps: float = 0.8
    slippage_bps: float = 0.6
    buffer_bps: float = 1.0

    def init(self):
        close = self.data.Close
        o = pd.Series(self.data.Open)
        h = pd.Series(self.data.High)
        l = pd.Series(self.data.Low)
        c = pd.Series(close)
        v = pd.Series(self.data.Volume)
        zw, zm = int(self.z_window), int(self.z_min)

        def zof(s: pd.Series) -> pd.Series:
            """v1 防泄漏 zscore：shift(1).rolling"""
            m = s.shift(1).rolling(zw, min_periods=zm).mean()
            sd = s.shift(1).rolling(zw, min_periods=zm).std(ddof=1).mask(lambda x: x < 1e-12)
            return ((s - m) / sd).clip(-3, 3)

        # ---- 动量（v1: M10/M30/M60 秒级 → 1/3/5 bar 重解释）----
        m1 = c.pct_change(1)
        m3 = c.pct_change(3)
        m5 = c.pct_change(5)
        # ---- CVD 代理：bar 内符号成交量（v1 需逐笔，此处 OHLCV 近似）----
        rng = (h - l)
        signed_vol = v * (2.0 * (c - o) / rng.where(rng > 0, np.nan)).fillna(0.0)
        cvd = signed_vol.rolling(int(self.cvd_len)).sum()
        cvd_z = zof(cvd / v.rolling(int(self.cvd_len)).sum().replace(0, np.nan))  # 归一为 [-1,1] 比率
        # ---- Intensity：量 / 滚动中位量（v1: V10/median）----
        intensity = v / v.rolling(int(self.inten_len)).median().replace(0, np.nan) - 1.0
        # ---- 均线/ATR ----
        self.sma_t = self.I(lambda x: pd.Series(x).rolling(int(self.trend_len)).mean(), close,
                            name=f"SMA{int(self.trend_len)}", overlay=True)
        self.sma_z = self.I(lambda x: pd.Series(x).rolling(int(self.z_len)).mean(), close,
                            name=f"SMA{int(self.z_len)}", overlay=True)

        self.atr = self.I(rolling_atr, self.data.High, self.data.Low, close, self.atr_len,
                          name="ATR", overlay=False)
        self.vr = self.I(rolling_vr, close, self.vr_k, self.vr_len, name="VR", overlay=False)

        # ---- v1 双 Alpha 分数（权重重归一）----
        trend_score = 0.333 * zof(m3) + 0.222 * zof(m5) + 0.278 * cvd_z + 0.167 * zof(intensity)
        mr_score = 0.40 * zof(-m1) + 0.267 * zof(-m3) + 0.333 * cvd_z
        # 注册为指标（便于报告叠加显示）
        self.trend_score = self.I(lambda: trend_score.fillna(0.0).values, name="TrendScore", overlay=False)
        self.mr_score = self.I(lambda: mr_score.fillna(0.0).values, name="MRScore", overlay=False)

        self._last_exit_bar = -(10 ** 9)
        self._in_pos = False
        self._entry_bar = -(10 ** 9)
        self._had_pos = False
        self._mode = None

    def _cost_bps(self) -> float:
        return 2.0 * float(self.commission_bps) + float(self.spread_bps) + float(self.slippage_bps) + float(self.buffer_bps)

    def _qty(self, stop_dist: float) -> int:
        return int(float(self.risk_usdt) / stop_dist) if stop_dist > 0 else 0

    def _flow_ok(self, direction: int, mode: str) -> bool:
        """流量闸门（默认直通；make_flow_strategy 注入 taker_z 后覆写）。
        momo=同向确认（z 与方向同号且|z|≥gate）；mr=逆向拥挤（z 与方向反号且|z|≥gate）。"""
        return True

    def next(self):
        if self.orders:
            return
        price = float(self.data.Close[-1])
        atr = float(self.atr[-1])
        if not np.isfinite(atr):
            return

        # ---- 持仓管理（按入场模式）----
        if self.position:
            self._had_pos = True
            if not self._in_pos:
                self._in_pos = True
                self._entry_bar = len(self.data) - 1
            if len(self.data) - 1 - self._entry_bar >= max(1, int(self.max_hold_bars)):
                self.position.close()  # 持仓周期上限（时间止损）：1m 下 5bar=5分钟，平衡点由寻优决定
                return
            tr = self.trades[0]
            if self._mode == "mom":
                if tr.is_long:
                    tr.sl = max(tr.sl or -np.inf, price - float(self.trail_atr) * atr)
                    if self.trend_score[-1] < -float(self.score_thr):
                        self.position.close()
                else:
                    tr.sl = min(tr.sl or np.inf, price + float(self.trail_atr) * atr)
                    if self.trend_score[-1] > float(self.score_thr):
                        self.position.close()
            return

        if self._had_pos:
            self._had_pos = False
            self._in_pos = False
            self._mode = None
            self._last_exit_bar = len(self.data) - 1
        if len(self.data) - self._last_exit_bar < int(self.cooldown_bars):
            return

        atr_bps = atr / price * 1e4
        if atr_bps < float(self.atr_floor_bps):
            return

        vr = float(self.vr[-1]) if np.isfinite(self.vr[-1]) else np.nan
        if not np.isfinite(vr):
            return
        thr = float(self.score_thr)

        # ================= 趋势状态：trend_score =================
        if vr >= float(self.vr_hi):
            sc = float(self.trend_score[-1])
            direction = 1 if sc > thr else (-1 if sc < -thr else 0)
            if direction == 0:
                return
            if direction > 0 and price <= float(self.sma_t[-1]):
                return
            if direction < 0 and price >= float(self.sma_t[-1]):
                return
            expected_bps = float(self.tp_atr) * atr_bps
            if self.use_cost_gate and expected_bps < max(
                    self._cost_bps() + float(self.min_edge_bps), float(self.capture_mult) * self._cost_bps()):
                return
            if (direction < 0 and str(self.side_mode) == "long") or \
                    (direction > 0 and str(self.side_mode) == "short"):
                return  # 单边模式：方向被禁用
            if not self._flow_ok(int(direction), "mom"):
                return  # 流量闸门：主动流未同向确认
            qty = self._qty(float(self.stop_atr) * atr)
            if qty < 1:
                return
            self._mode = "mom"
            if direction > 0:
                self.buy(size=qty, sl=price - float(self.stop_atr) * atr, tp=price + float(self.tp_atr) * atr)
            else:
                self.sell(size=qty, sl=price + float(self.stop_atr) * atr, tp=price - float(self.tp_atr) * atr)
            return

        # ================= 均值回归状态：mr_score =================
        if vr <= float(self.vr_lo):
            sc = float(self.mr_score[-1])
            direction = 1 if sc > thr else (-1 if sc < -thr else 0)
            if direction == 0:
                return
            mean = float(self.sma_z[-1])
            dev = price - mean
            expected_bps = abs(dev) / price * 1e4
            if self.use_cost_gate and expected_bps < max(
                    self._cost_bps() + float(self.min_edge_bps), float(self.capture_mult) * self._cost_bps()):
                return
            # R:R 可调（与 v3 同步；旧版风险1.3:目标1.0 结构性逆差）
            sl_dist = max(float(self.mr_stop_atr) * atr, float(self.mr_sl_mult) * abs(dev))
            tp = mean - (float(self.mr_tp_mult) - 1.0) * abs(dev) if direction < 0 \
                else mean + (float(self.mr_tp_mult) - 1.0) * abs(dev)
            if (direction < 0 and str(self.side_mode) == "long") or \
                    (direction > 0 and str(self.side_mode) == "short"):
                return  # 单边模式：该侧回归被禁用
            if not self._flow_ok(-1 if dev > 0 else 1, "mr"):
                return  # 流量闸门：逆向拥挤证据不足
            qty = self._qty(sl_dist)
            if qty < 1:
                return
            self._mode = "mr"
            if direction > 0:
                self.buy(size=qty, sl=price - sl_dist, tp=tp)
            else:
                self.sell(size=qty, sl=price + sl_dist, tp=tp)
            return

        return


# ============ 流量闸门（2026-09 最佳方案：K线毛优势不足 → Rubik 主动买卖比弹药）============
# 教训：闭包工厂类不能被 optimize 线程/进程池 pickle → 必须模块级类 + 模块级流量源
_FLOW_SRC: dict = {"df": None}


def set_flow_source(flow) -> None:
    """注入与回测数据同索引对齐的流量表（需含 taker_z 列，见 data/flow.py）。None=停用。"""
    _FLOW_SRC["df"] = flow


class FlowRegimeAdaptiveBS(RegimeAdaptiveBS):
    """v3 流量闸门版：momo=主动流同向确认 / mr=逆向拥挤；gate=0 或流量缺失直通。"""

    def init(self):
        super().init()
        self.taker_z = None
        flow = _FLOW_SRC["df"]
        if flow is not None:
            idx = pd.DatetimeIndex(self.data.index)
            arr = flow["taker_z"].reindex(idx).astype(float).values
            self.taker_z = self.I(lambda: arr, name="taker_z", overlay=False)

    def _flow_ok(self, direction: int, mode: str) -> bool:
        g = float(self.flow_gate)
        if g <= 0 or self.taker_z is None:
            return True
        z = float(self.taker_z[-1]) if np.isfinite(self.taker_z[-1]) else np.nan
        if not np.isfinite(z):
            return True  # 无流量数据时段不阻塞
        return z * direction <= -g if mode == "mr" else z * direction >= g


def make_flow_strategy(base_cls, flow):
    """兼容入口：v3 返回模块级 FlowRegimeAdaptiveBS（可 optimize）；其他类退回闭包版（仅 .run()）。"""
    set_flow_source(flow)
    if base_cls is RegimeAdaptiveBS:
        return FlowRegimeAdaptiveBS

    class FlowStrategy(base_cls):
        _flow_src = flow

        def init(self):
            super().init()
            idx = pd.DatetimeIndex(self.data.index)
            arr = self._flow_src["taker_z"].reindex(idx).astype(float).values
            self.taker_z = self.I(lambda: arr, name="taker_z", overlay=False)

        def _flow_ok(self, direction: int, mode: str) -> bool:
            g = float(self.flow_gate)
            if g <= 0:
                return True
            z = self.taker_z[-1]
            z = float(z) if np.isfinite(z) else np.nan
            if not np.isfinite(z):
                return True
            return z * direction <= -g if mode == "mr" else z * direction >= g

    FlowStrategy.__name__ = f"Flow{base_cls.__name__}"
    return FlowStrategy
