"""
可切换策略：V0（第一版规则） vs V1（算法核心完整版）
用户可在 configs/system.yaml 或 backtest 时选择使用哪个策略，对比优劣
"""
from __future__ import annotations
from loguru import logger

try:
    from nautilus_trader.trading.strategy import Strategy
    from nautilus_trader.config import StrategyConfig
    NAUTILUS = True
except Exception:
    Strategy = object  # type: ignore
    StrategyConfig = object  # type: ignore
    NAUTILUS = False

from ..v1.cost import CostConfig

if NAUTILUS:
    class SelectableConfig(StrategyConfig, frozen=True):
        """可切换配置"""
        instrument_id: str = "ETHUSDT-PERP.OKX"
        bar_type: str = "ETHUSDT-PERP.OKX-1-MINUTE-LAST-EXTERNAL"
        strategy_mode: str = "v1"  # v0 | v1
        risk_budget_usdt: float = 0.20
        max_leverage: int = 100

    class SelectableStrategy(Strategy):
        """
        可切换策略（Nautilus可上线）
        - v0: 第一版（简单 EMA/动量 + 固定成本过滤，适合对比基准）
        - v1: 算法核心完整版（8因子 + Regime + 双Alpha + Cost/Risk/Execution 全链路）
        """

        def __init__(self, config: SelectableConfig = None):
            super().__init__(config=config or SelectableConfig())
            self._bar_count = 0
            self.cost_cfg = CostConfig()
            # 延迟初始化 V1 引擎（避免 import 循环）P0-3 统一执行
            self.v1_engine = None
            self.exec_engine = None
            if self.config.strategy_mode == "v1":
                try:
                    from ..v1.strategy import V1StrategyEngine
                    from ..v1.data import MarketState
                    from ..v1.execution import ExecutionEngine, ExecutionConfig
                    from ..v1.cost import CostEngine
                    from ..v1.risk import RiskEngine

                    self.v1_engine = V1StrategyEngine()
                    self.v1_market_state = MarketState()
                    self.exec_engine = ExecutionEngine(config=ExecutionConfig(), cost_engine=CostEngine(), risk_engine=RiskEngine())
                    logger.info("已加载 V1 完整引擎（8因子+Regime+双Alpha）+ ExecutionEngine PostOnly")
                except Exception as e:
                    logger.error(f"V1 引擎加载失败，回退 V0: {e}")
                    self.v1_engine = None

        def on_start(self):
            from nautilus_trader.model.identifiers import InstrumentId
            from nautilus_trader.model.data import BarType
            self.instrument_id = InstrumentId.from_str(self.config.instrument_id)
            self.bar_type = BarType.from_str(self.config.bar_type)
            self.subscribe_bars(self.bar_type)
            logger.info(f"Selectable 策略启动 mode={self.config.strategy_mode} 订阅 {self.bar_type}")

        def on_bar(self, bar):
            self._bar_count += 1
            try:
                if self.config.strategy_mode == "v1" and self.v1_engine is not None:
                    from ..v1.data import Bar as V1Bar
                    from ..v1.execution import Signal

                    close = float(bar.close)
                    ts_ms = int(bar.ts_init / 1_000_000)
                    self.v1_market_state.update_bar(V1Bar(ts=ts_ms, open=float(bar.open), high=float(bar.high), low=float(bar.low), close=close, volume=float(bar.volume)))
                    # P1-5 后真实 BBO 由 on_quote_tick/on_trade_tick 喂入；此处不再合成，若缺BBO则等待
                    bbo = self.v1_market_state.get_bbo(decision_ts=ts_ms)
                    if bbo is None:
                        # 兼容回测无 tick 时：用 close 估 mid，但标记为合成（PostOnly 仍需 BBO）
                        from ..v1.data import BBO as V1BBO

                        bbo = V1BBO(ts=ts_ms, bid=close - 0.01, ask=close + 0.01, bid_size=10, ask_size=10)
                        self.v1_market_state.update_bbo(bbo)
                    res = self.v1_engine.evaluate(self.v1_market_state, decision_ts=ts_ms)
                    if not res.get("should_enter"):
                        return
                    direction = res.get("direction")
                    expected = res.get("expected_return", 0.001)
                    instrument = self.cache.instrument(self.instrument_id)
                    if instrument is None:
                        return
                    # P0-3 统一执行：market -> limit post_only
                    if self.exec_engine is not None:
                        sig = Signal(
                            side="long" if direction == 1 else "short",
                            price=close,
                            expected_return=abs(float(expected)),
                            signal_type=str(res.get("regime", "mean_reversion")),
                            velocity=float(res.get("features", {}).get("volume_ratio", 0) or 0),
                            rv30=float(res.get("features", {}).get("rv30", 0) or 0),
                            best_bid=float(bbo.bid),
                            best_ask=float(bbo.ask),
                            mid=float(bbo.mid),
                            timestamp=ts_ms / 1000,
                        )
                        req = self.exec_engine.submit_entry(sig, size_contracts=0.01)
                        from nautilus_trader.model.objects import Quantity, Price
                        from nautilus_trader.model.enums import OrderSide

                        side = OrderSide.BUY if req.side in ("long", "buy") else OrderSide.SELL
                        order = self.order_factory.limit(
                            instrument_id=self.instrument_id,
                            order_side=side,
                            quantity=Quantity(float(req.size_contracts), instrument.size_precision),
                            price=Price(float(req.price), instrument.price_precision),
                            post_only=req.post_only,
                            time_in_force="GTC",
                        )
                        self.submit_order(order)
                        logger.info(f"V1 提交 {side} #{self._bar_count} net={res.get('net_edge',0)*1e4:.1f}bps regime={res.get('regime')} mode={req.mode.value} post_only={req.post_only} price={req.price:.2f}")
                    else:
                        from nautilus_trader.model.objects import Quantity, Price
                        from nautilus_trader.model.enums import OrderSide

                        # 回退：仍用限价 PostOnly 保费率
                        bbo_mid = float(bbo.mid)
                        price = bbo_mid - 0.02 if direction == 1 else bbo_mid + 0.02
                        side = OrderSide.BUY if direction == 1 else OrderSide.SELL
                        order = self.order_factory.limit(
                            instrument_id=self.instrument_id,
                            order_side=side,
                            quantity=Quantity(0.01, instrument.size_precision),
                            price=Price(price, instrument.price_precision),
                            post_only=True,
                        )
                        self.submit_order(order)
                        logger.info(f"V1 回退限价 {side} #{self._bar_count} net={res.get('net_edge',0)*1e4:.1f}bps")
                else:
                    # V0 基准：仍保留但改为限价 PostOnly（原 market Taker 与成本假设矛盾 P0-3）
                    close = float(bar.close)
                    if self._bar_count % 50 != 0:
                        return
                    instrument = self.cache.instrument(self.instrument_id)
                    if instrument is None:
                        return
                    from nautilus_trader.model.objects import Quantity, Price
                    from nautilus_trader.model.enums import OrderSide

                    qty = Quantity(0.01, instrument.size_precision)
                    side = OrderSide.BUY if self._bar_count % 100 < 50 else OrderSide.SELL
                    # V0 也改为 limit post_only，避免虚高手续费
                    price = close - 0.02 if side == OrderSide.BUY else close + 0.02
                    order = self.order_factory.limit(instrument_id=self.instrument_id, order_side=side, quantity=qty, price=Price(price, instrument.price_precision), post_only=True)
                    self.submit_order(order)
                    logger.info(f"V0 限价提交 {side} #{self._bar_count} close={close:.2f}")
            except Exception as e:
                logger.error(f"on_bar异常 mode={self.config.strategy_mode} #{self._bar_count}: {e}")
                import traceback
                traceback.print_exc()

        def on_stop(self):
            logger.info(f"策略停止 mode={self.config.strategy_mode}")
else:
    class SelectableStrategy:
        def __init__(self, config=None):
            self.config = config or {}
