"""
MicroScalper 策略：Nautilus可上线（事件驱动，防未来函数）
V0 仅 1m Bar，通过 Bar完成才回调 保证时序，成本过滤+RiskBudget反推
选择性：仅净收益>1.5bps才开，约5~30笔/天，非刷单
"""
from __future__ import annotations
from loguru import logger

try:
    from nautilus_trader.trading.strategy import Strategy
    from nautilus_trader.config import StrategyConfig
    NAUTILUS = True
except Exception:
    Strategy = object  # type: ignore
    StrategyConfig = object  # type: ignore
    NAUTILUS = False

from ..v1.cost import CostConfig, CostEngine, _bps

if NAUTILUS:
    class MicroScalperNTConfig(StrategyConfig, frozen=True):
        instrument_id: str = "ETHUSDT-PERP.OKX"
        bar_type: str = "ETHUSDT-PERP.OKX-1-MINUTE-LAST-EXTERNAL"
        risk_budget_usdt: float = 0.20
        max_leverage: int = 100
        min_edge_bps: float = 1.5

    class MicroScalperStrategy(Strategy):
        def __init__(self, config: MicroScalperNTConfig = None):
            super().__init__(config=config or MicroScalperNTConfig())
            self._bar_count = 0
            self.cost_cfg = CostConfig()
            self.cost_engine = CostEngine()
            logger.info(f"策略初始化 {self.config.instrument_id} 风控{self.config.risk_budget_usdt}U")

        def on_start(self):
            from nautilus_trader.model.identifiers import InstrumentId
            from nautilus_trader.model.data import BarType
            self.instrument_id = InstrumentId.from_str(self.config.instrument_id)
            self.bar_type = BarType.from_str(self.config.bar_type)
            self.subscribe_bars(self.bar_type)
            logger.info(f"订阅 {self.bar_type}")

        def on_bar(self, bar):
            self._bar_count += 1
            try:
                close = float(bar.close)
                # P0-1 统一成本：CostEngine.net_edge(maker,maker)≈3.6bps @0.1%毛利（原 3.3bps 因 0.3bps double）
                net_bps = _bps(self.cost_engine.net_edge(0.0010, "maker", "maker"))
                # 选择性：仅 net>阈值才开，约5~30笔/天（P0-3 已改为限价 PostOnly，成本假设一致）
                if net_bps <= self.config.min_edge_bps:
                    return
                instrument = self.cache.instrument(self.instrument_id)
                if instrument is None:
                    logger.warning(f"仪器未就绪 {self.instrument_id}")
                    return
                from nautilus_trader.model.objects import Quantity, Price
                from nautilus_trader.model.enums import OrderSide

                qty = Quantity(0.01, instrument.size_precision)
                side = OrderSide.BUY if self._bar_count % 100 < 50 else OrderSide.SELL
                # P0-3 market->limit post_only（保 Maker 费率，与 CostEngine 假设一致）
                price = close - 0.02 if side == OrderSide.BUY else close + 0.02
                order = self.order_factory.limit(
                    instrument_id=self.instrument_id,
                    order_side=side,
                    quantity=qty,
                    price=Price(price, instrument.price_precision),
                    post_only=True,
                )
                self.submit_order(order)
                logger.info(f"提交 {side} #{self._bar_count} close={close:.2f} net={net_bps:.1f}bps qty=0.01 limit post_only")
            except Exception as e:
                logger.error(f"on_bar异常 #{self._bar_count}: {e}")
                import traceback
                traceback.print_exc()

        def on_stop(self):
            logger.info("策略停止")
else:
    class MicroScalperStrategy:
        def __init__(self, config=None):
            self.config = config or {}
        def on_bar(self, bar):
            return None
