"""存储：Parquet 数据湖，统一读写
为什么用 Parquet：列存 + 压缩，高频数据友好
"""
from __future__ import annotations
from pathlib import Path
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from loguru import logger

def save_parquet(df: pd.DataFrame, path: str | Path) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    table = pa.Table.from_pandas(df, preserve_index=False)
    pq.write_table(table, str(p), compression="zstd")
    logger.info(f"已保存 {len(df)} 行 -> {p}")

def load_parquet(path: str | Path) -> pd.DataFrame:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(p)
    return pq.read_table(str(p)).to_pandas()

def save_candles_parquet(df: pd.DataFrame, root: str | Path, inst_id: str, bar: str) -> Path:
    """按日分区示例：data/parquet/candles/ETH-USDT-SWAP/1m/2024-01-01.parquet"""
    if df.empty:
        raise ValueError("空 DataFrame 不保存")
    day = df["ts"].dt.date.iloc[0].isoformat()
    p = Path(root) / "candles" / inst_id / bar / f"{day}.parquet"
    save_parquet(df, p)
    return p
