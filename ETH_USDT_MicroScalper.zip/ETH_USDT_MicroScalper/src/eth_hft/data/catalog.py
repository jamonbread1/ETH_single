"""
数据编目：Nautilus ParquetDataCatalog 封装（可信回放唯一真相）
设计：所有历史数据必须经 Catalog 落盘、再经 BacktestEngine 回放，禁止脚本直连 REST 绕过存储
V0 仅 1m Bar，后续可扩展 TradeTick / OrderBookDelta
"""
from __future__ import annotations
from pathlib import Path
import pandas as pd
from loguru import logger

# 尝试导入 Nautilus，若失败则回退为 Lite（保证家用机可跑）
try:
    from nautilus_trader.persistence.catalog import ParquetDataCatalog
    from nautilus_trader.model.identifiers import InstrumentId, Symbol, Venue
    from nautilus_trader.model.data import Bar, BarType, BarSpecification
    from nautilus_trader.model.enums import PriceType, AggregationSource
    from nautilus_trader.model.objects import Price, Quantity
    NAUTILUS_AVAILABLE = True
except Exception as e:
    ParquetDataCatalog = None  # type: ignore
    NAUTILUS_AVAILABLE = False
    logger.warning(f"Nautilus 未可用，回退 Lite Catalog: {e}")

# 固定品种映射（OKX ↔ Nautilus）
# Nautilus InstrumentId 格式：ETHUSDT-PERP.OKX  （symbol-venue）
OKX_INST = "ETH-USDT-SWAP"
NT_INSTRUMENT_ID_STR = "ETHUSDT-PERP.OKX"
NT_BAR_SPEC_1M = None  # 延迟初始化

def _ensure_bar_spec():
    """1分钟 Bar 规格：1-MINUTE-LAST"""
    global NT_BAR_SPEC_1M
    if NT_BAR_SPEC_1M is not None:
        return NT_BAR_SPEC_1M
    if not NAUTILUS_AVAILABLE:
        return None
    from nautilus_trader.model.data import BarSpecification
    from nautilus_trader.model.enums import BarAggregation, PriceType
    NT_BAR_SPEC_1M = BarSpecification(step=1, aggregation=BarAggregation.MINUTE, price_type=PriceType.LAST)
    return NT_BAR_SPEC_1M

def okx_candles_to_pandas_bars(df_okx: pd.DataFrame) -> pd.DataFrame:
    """
    OKX REST candles → 标准化 pandas (ts, open, high, low, close, volume)
    输入 df_okx 需含 ts, open, high, low, close, vol
    """
    df = df_okx.copy()
    # 统一列名
    rename = {"vol": "volume", "volCcy": "volume_quote"}
    df = df.rename(columns={k: v for k, v in rename.items() if k in df.columns})
    # 时间戳统一 UTC
    if "ts" in df.columns:
        df["ts"] = pd.to_datetime(df["ts"], utc=True)
    # 数值
    for c in ["open", "high", "low", "close", "volume"]:
        if c in df.columns:
            df[c] = df[c].astype(float)
    return df.sort_values("ts").reset_index(drop=True)

class DataCatalog:
    """统一编目（Nautilus 优先，Lite 回退）P1-5 / P2-8 归一：canonical data/catalog/data/bar"""

    CANONICAL_ROOT = Path("data/catalog")

    def __init__(self, path: str | Path | None = None):
        # P0-4 单一配置入口：默认读 system.yaml data_root，否则 canonical
        if path is None:
            try:
                from eth_hft.config.loader import load_system_config  # type: ignore

                raw = load_system_config()
                path = raw.get("data_root", str(self.CANONICAL_ROOT))
            except Exception:
                path = str(self.CANONICAL_ROOT)
        self.path = Path(path)
        # 重定向 legacy data/parquet -> data/catalog
        if "parquet" in str(self.path) and not str(self.path).endswith("catalog"):
            logger.warning(f"Catalog path {self.path} 非 canonical，已重定向至 {self.CANONICAL_ROOT}")
            self.path = self.CANONICAL_ROOT
        self.path.mkdir(parents=True, exist_ok=True)
        self._nt_catalog = None
        if NAUTILUS_AVAILABLE:
            try:
                self._nt_catalog = ParquetDataCatalog(str(self.path))
                logger.info(f"Nautilus Catalog 已初始化: {self.path}")
            except Exception as e:
                logger.warning(f"Nautilus Catalog 初始化失败，回退 Lite: {e}")
                self._nt_catalog = None

    def write_bars(self, df: pd.DataFrame, bar_type_str: str = "ETHUSDT-PERP.OKX-1-MINUTE-LAST-EXTERNAL") -> Path:
        """
        写入 1m Bar 到编目
        df 需含 ts, open, high, low, close, volume
        返回写入路径
        """
        df_std = okx_candles_to_pandas_bars(df)
        if self._nt_catalog is not None:
            # Nautilus 路径：按 instrument / bar_type 分区
            try:
                # 构造 Nautilus Bar 对象列表
                from nautilus_trader.model.data import Bar, BarType
                bar_type = BarType.from_str(bar_type_str)
                bars = []
                for _, row in df_std.iterrows():
                    # Nautilus 1.231 Bar 不再接收 instrument_id，由 bar_type 隐含
                    ts_ns = int(row["ts"].timestamp() * 1_000_000_000)
                    bar = Bar(
                        bar_type=bar_type,
                        open=Price(row["open"], precision=2),
                        high=Price(row["high"], precision=2),
                        low=Price(row["low"], precision=2),
                        close=Price(row["close"], precision=2),
                        volume=Quantity(row["volume"], precision=4),
                        ts_event=ts_ns,
                        ts_init=ts_ns,
                    )
                    bars.append(bar)
                self._nt_catalog.write_data(bars)
                logger.info(f"已写入 Nautilus Catalog {len(bars)} bars -> {self.path}")
                return self.path
            except Exception as e:
                logger.warning(f"Nautilus 写入失败，回退 Lite: {e}")

        # Lite 回退：归一至 Nautilus 同分区 data/bar（P2-8 单真相）
        out = self.path / "data" / "bar" / bar_type_str / f"{df_std['ts'].dt.date.iloc[0]}.parquet"
        out.parent.mkdir(parents=True, exist_ok=True)
        df_std.to_parquet(out, compression="zstd")
        logger.info(f"已写入 Lite Catalog {len(df_std)} bars -> {out} (归一分区)")
        return out

    # --- P1-5 Trade/BBO 扩展（Nautilus TradeTick/QuoteTick + Lite 回退） ---
    @staticmethod
    def _normalize_trades(df: pd.DataFrame) -> pd.DataFrame:
        d = df.copy()
        # 兼容 OKX 字段：ts/px/sz/side/tradeId 或 ts/price/qty
        if "px" in d.columns and "price" not in d.columns:
            d = d.rename(columns={"px": "price"})
        if "sz" in d.columns and "qty" not in d.columns:
            d = d.rename(columns={"sz": "qty"})
        if "ts" in d.columns:
            d["ts"] = pd.to_datetime(d["ts"], utc=True, errors="coerce")
        return d.sort_values("ts").reset_index(drop=True)

    def write_trades(self, df: pd.DataFrame) -> Path:
        """写入逐笔 TradeTick（OKX trades 落盘，P1-5）"""
        df_std = self._normalize_trades(df)
        if self._nt_catalog is not None:
            try:
                from nautilus_trader.model.data import TradeTick  # type: ignore
                from nautilus_trader.model.identifiers import InstrumentId  # type: ignore
                from nautilus_trader.model.enums import AggressorSide  # type: ignore
                from nautilus_trader.model.objects import Price, Quantity  # type: ignore

                iid = InstrumentId.from_str(NT_INSTRUMENT_ID_STR)
                ticks = []
                for _, r in df_std.iterrows():
                    if pd.isna(r["ts"]):
                        continue
                    ts_ns = int(r["ts"].timestamp() * 1_000_000_000)
                    side = str(r.get("side", "unknown")).lower()
                    aggr = AggressorSide.BUYER if side == "buy" else AggressorSide.SELLER if side == "sell" else AggressorSide.NO_AGGRESSOR
                    ticks.append(
                        TradeTick(
                            instrument_id=iid,
                            price=Price(float(r.get("price", r.get("px", 0))), 2),
                            size=Quantity(float(r.get("qty", r.get("sz", 0))), 4),
                            aggressor_side=aggr,
                            trade_id=str(r.get("tradeId", r.get("trade_id", ts_ns))),
                            ts_event=ts_ns,
                            ts_init=ts_ns,
                        )
                    )
                if ticks:
                    self._nt_catalog.write_data(ticks)
                    logger.info(f"已写入 Nautilus TradeTick {len(ticks)} -> {self.path}")
                    return self.path
            except Exception as e:
                logger.warning(f"Nautilus trades 写入回退 Lite: {e}")
        # Lite 回退：按日分区
        if df_std.empty:
            return self.path
        out = self.path / "ticks" / "ETHUSDT-PERP.OKX" / f"{df_std['ts'].dt.date.iloc[0]}.parquet"
        out.parent.mkdir(parents=True, exist_ok=True)
        df_std.to_parquet(out, compression="zstd")
        logger.info(f"已写入 Lite ticks {len(df_std)} -> {out}")
        return out

    def write_bbos(self, df: pd.DataFrame) -> Path:
        """写入 BBO/QuoteTick（bbo-tbt 落盘，P1-5），df 需含 ts,bid,ask,bid_size,ask_size"""
        df_std = df.copy()
        if "ts" in df_std.columns:
            df_std["ts"] = pd.to_datetime(df_std["ts"], utc=True, errors="coerce")
        df_std = df_std.sort_values("ts").reset_index(drop=True)
        if self._nt_catalog is not None:
            try:
                from nautilus_trader.model.data import QuoteTick  # type: ignore
                from nautilus_trader.model.identifiers import InstrumentId  # type: ignore
                from nautilus_trader.model.objects import Price, Quantity  # type: ignore

                iid = InstrumentId.from_str(NT_INSTRUMENT_ID_STR)
                ticks = []
                for _, r in df_std.iterrows():
                    if pd.isna(r["ts"]):
                        continue
                    ts_ns = int(r["ts"].timestamp() * 1_000_000_000)
                    ticks.append(
                        QuoteTick(
                            instrument_id=iid,
                            bid_price=Price(float(r.get("bid", r.get("bidPx", 0))), 2),
                            ask_price=Price(float(r.get("ask", r.get("askPx", 0))), 2),
                            bid_size=Quantity(float(r.get("bid_size", r.get("bidSz", 0))), 4),
                            ask_size=Quantity(float(r.get("ask_size", r.get("askSz", 0))), 4),
                            ts_event=ts_ns,
                            ts_init=ts_ns,
                        )
                    )
                if ticks:
                    self._nt_catalog.write_data(ticks)
                    logger.info(f"已写入 Nautilus QuoteTick {len(ticks)} -> {self.path}")
                    return self.path
            except Exception as e:
                logger.warning(f"Nautilus quotes 写入回退 Lite: {e}")
        if df_std.empty:
            return self.path
        out = self.path / "quotes" / "ETHUSDT-PERP.OKX" / f"{df_std['ts'].dt.date.iloc[0]}.parquet"
        out.parent.mkdir(parents=True, exist_ok=True)
        df_std.to_parquet(out, compression="zstd")
        logger.info(f"已写入 Lite quotes {len(df_std)} -> {out}")
        return out

    def list_bars(self) -> list[Path]:
        """列出已落盘的 bar 文件（P2-8 归一：仅 canonical data/bar，去重 legacy bars/）"""
        canon = list((self.path / "data").rglob("*.parquet"))
        legacy = list((self.path / "bars").rglob("*.parquet")) if (self.path / "bars").exists() else []
        if legacy:
            logger.warning(f"发现 {len(legacy)} 个 legacy bars/ 文件，请运行 scripts/migrate_catalog.py 迁移至 data/bar")
        # 去重：canonical 优先
        if not canon and legacy:
            return legacy
        return canon

    def read_bars_pandas(self, bar_type_str: str = "ETHUSDT-PERP.OKX-1-MINUTE-LAST-EXTERNAL") -> pd.DataFrame:
        """读回 pandas（用于自检/非 Nautilus 回测）P2-8 解码 Nautilus bytes→float"""
        # 优先尝试 Nautilus 原生查询（正确解码 Price/Quantity）
        if self._nt_catalog is not None:
            try:
                from nautilus_trader.model.identifiers import InstrumentId  # type: ignore

                iid = InstrumentId.from_str(NT_INSTRUMENT_ID_STR)
                # ParquetDataCatalog.bars(...) 在不同版本命名不同，兼容尝试
                for method in ("bars", "query_bars", "read_bars"):
                    if hasattr(self._nt_catalog, method):
                        try:
                            bars = getattr(self._nt_catalog, method)(instrument_id=iid)  # type: ignore
                            if bars:
                                import pandas as pd  # type: ignore

                                df = pd.DataFrame(
                                    [
                                        {
                                            "ts": pd.to_datetime(b.ts_event, unit="ns", utc=True),
                                            "open": float(b.open),
                                            "high": float(b.high),
                                            "low": float(b.low),
                                            "close": float(b.close),
                                            "volume": float(b.volume),
                                        }
                                        for b in bars
                                    ]
                                )
                                return df.sort_values("ts").reset_index(drop=True)
                        except Exception:
                            continue
            except Exception:
                pass
        files = self.list_bars()
        if not files:
            return pd.DataFrame()
        dfs = []
        for f in files:
            try:
                df_tmp = pd.read_parquet(f)
                # 检测 Nautilus bytes 列（open 为 bytes）
                if not df_tmp.empty and "open" in df_tmp.columns and isinstance(df_tmp["open"].iloc[0], (bytes, bytearray)):
                    # 尝试用 Nautilus Price 解码：bytes -> int -> Price
                    try:
                        from nautilus_trader.model.objects import Price  # type: ignore

                        def _decode_price(b: bytes) -> float:
                            # Nautilus Price 存储为 8 字节原始值，需经 Price.from_raw 解码；回退为 0
                            try:
                                return float(Price.from_raw(int.from_bytes(b, "little")).as_double())  # type: ignore
                            except Exception:
                                try:
                                    return float(int.from_bytes(b, "little")) / 1e9
                                except Exception:
                                    return 0.0

                        for col in ["open", "high", "low", "close"]:
                            if col in df_tmp.columns:
                                df_tmp[col] = df_tmp[col].apply(lambda x: _decode_price(x) if isinstance(x, (bytes, bytearray)) else float(x))
                        if "volume" in df_tmp.columns:
                            df_tmp["volume"] = df_tmp["volume"].apply(lambda x: _decode_price(x) if isinstance(x, (bytes, bytearray)) else float(x))
                        df_tmp["ts"] = pd.to_datetime(df_tmp["ts_event"], unit="ns", utc=True)
                        df_tmp = df_tmp[["ts", "open", "high", "low", "close", "volume"]]
                    except Exception:
                        continue
                dfs.append(df_tmp)
            except Exception:
                try:
                    import pyarrow.parquet as pq  # type: ignore

                    dfs.append(pq.read_table(str(f)).to_pandas())
                except Exception:
                    continue
        if not dfs:
            return pd.DataFrame()
        df = pd.concat(dfs, ignore_index=True)
        if "ts" in df.columns:
            df["ts"] = pd.to_datetime(df["ts"], utc=True, errors="coerce")
            df = df.sort_values("ts").reset_index(drop=True)
        elif "ts_event" in df.columns:
            df["ts"] = pd.to_datetime(df["ts_event"], unit="ns", utc=True)
            df = df.sort_values("ts").reset_index(drop=True)
        return df
