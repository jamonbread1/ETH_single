"""订单簿重建：增量 + seqId 校验（OKX 2026-06 后）
依据：OKX 已废弃 checksum，改用 seqId/prevSeqId 连续性校验
"""
from __future__ import annotations
from dataclasses import dataclass, field
from loguru import logger

@dataclass
class OrderBook:
    """本地订单簿（简化版，支持 L2 校验）"""
    bids: dict[float, float] = field(default_factory=dict)  # price -> size
    asks: dict[float, float] = field(default_factory=dict)
    last_seq: int | None = None

    def apply_snapshot(self, bids: list[list[str]], asks: list[list[str]], seq_id: int) -> None:
        self.bids = {float(p): float(s) for p,s,s,_ in bids} if bids and len(bids[0])==4 else {float(p): float(s) for p,s,_ in [b[:3] for b in bids] } if False else {float(p): float(s) for p,s in [(b[0], b[1]) for b in bids]}
        self.asks = {float(p): float(s) for p,s in [(a[0], a[1]) for a in asks]}
        self.last_seq = seq_id
        # 兼容不同长度
        # 实际上 OKX bids/asks 元素为 [price, size, _, _] 或 [price, size]
        # 上行已做兼容，下行再修正一次
        try:
            self.bids = {float(b[0]): float(b[1]) for b in bids}
            self.asks = {float(a[0]): float(a[1]) for a in asks}
        except Exception:
            pass
        logger.debug(f"快照 seq={seq_id} bids={len(self.bids)} asks={len(self.asks)}")

    def apply_update(self, bids: list[list[str]], asks: list[list[str]], seq_id: int, prev_seq_id: int) -> bool:
        """增量更新，返回是否连续（True 连续，False 断档需重建）"""
        if self.last_seq is not None and prev_seq_id != self.last_seq:
            logger.warning(f"seq 断档 prev={prev_seq_id} last={self.last_seq} -> 需重新快照")
            return False
        for b in bids:
            p, s = float(b[0]), float(b[1])
            if s == 0:
                self.bids.pop(p, None)
            else:
                self.bids[p] = s
        for a in asks:
            p, s = float(a[0]), float(a[1])
            if s == 0:
                self.asks.pop(p, None)
            else:
                self.asks[p] = s
        self.last_seq = seq_id
        return True

    def best_bid_ask(self) -> tuple[float | None, float | None]:
        bid = max(self.bids) if self.bids else None
        ask = min(self.asks) if self.asks else None
        return bid, ask

    def spread_bps(self) -> float | None:
        bid, ask = self.best_bid_ask()
        if bid is None or ask is None:
            return None
        mid = (bid + ask) / 2
        return (ask - bid) / mid * 1e4

    def obi(self, depth: int = 5) -> float | None:
        """订单簿失衡 OBI = (bidVol - askVol)/(bidVol+askVol)"""
        if not self.bids or not self.asks:
            return None
        b_sorted = sorted(self.bids.items(), key=lambda x: -x[0])[:depth]
        a_sorted = sorted(self.asks.items(), key=lambda x: x[0])[:depth]
        bv = sum(v for _, v in b_sorted)
        av = sum(v for _, v in a_sorted)
        if bv + av == 0:
            return None
        return (bv - av) / (bv + av)

    def microprice(self) -> float | None:
        bid, ask = self.best_bid_ask()
        if bid is None or ask is None:
            return None
        bs = self.bids.get(bid, 0)
        as_ = self.asks.get(ask, 0)
        if bs + as_ == 0:
            return None
        # 微观价格 = (ask*bs + bid*as)/(bs+as)
        return (ask * bs + bid * as_) / (bs + as_)

    def depth_total(self, side: str = "bid", depth: int = 5) -> float:
        book = self.bids if side=="bid" else self.asks
        sorted_items = sorted(book.items(), key=lambda x: -x[0] if side=="bid" else x[0])[:depth]
        return sum(v for _, v in sorted_items)
