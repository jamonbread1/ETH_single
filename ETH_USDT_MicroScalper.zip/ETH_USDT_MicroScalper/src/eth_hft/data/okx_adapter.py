"""
OKX 适配：REST 分页 + 归一化为 Nautilus Bar
职责：仅负责“拉取→归一化→交 Catalog”，不直接参与策略
"""
from __future__ import annotations
import time
from pathlib import Path
import pandas as pd
from loguru import logger
from .okx_rest import fetch_candles as okx_fetch_candles
from .catalog import DataCatalog, okx_candles_to_pandas_bars

def ingest_okx_to_catalog(
    catalog: DataCatalog,
    inst_id: str = "ETH-USDT-SWAP",
    bar: str = "1m",
    limit_per_request: int = 100,
    total_limit: int = 300,
    after: str | None = None,
) -> Path | None:
    """
    分页拉取 OKX 1m → 写入 Catalog
    - OKX 单次最多 300（实际 100 稳定），通过 after 分页
    - 含 rate_limit 间隔 200ms
    """
    all_dfs = []
    fetched = 0
    cur_after = after
    while fetched < total_limit:
        need = min(limit_per_request, total_limit - fetched)
        try:
            df = okx_fetch_candles(inst_id=inst_id, bar=bar, limit=need, after=cur_after)
        except Exception as e:
            logger.error(f"拉取失败: {e}")
            break
        if df.empty:
            break
        all_dfs.append(df)
        fetched += len(df)
        # OKX 返回倒序，最早的 ts 作为下一次 after
        # fetch_candles 已按 ts 升序，取最后一行 ts
        last_ts_ms = int(df["ts"].max().timestamp() * 1000)
        cur_after = str(last_ts_ms)
        logger.info(f"已拉取 {fetched}/{total_limit} 行，游标 {cur_after}")
        if len(df) < need:
            break
        time.sleep(0.2)  # 限频

    if not all_dfs:
        logger.warning("未拉取到任何数据")
        return None

    merged = pd.concat(all_dfs, ignore_index=True).drop_duplicates(subset=["ts"]).sort_values("ts")
    # 写入编目
    path = catalog.write_bars(merged)
    logger.info(f"入库完成 {len(merged)} bars -> {path}")
    return path

if __name__ == "__main__":
    cat = DataCatalog("data/catalog")
    ingest_okx_to_catalog(cat, total_limit=300)
    print(cat.list_bars()[:3])
