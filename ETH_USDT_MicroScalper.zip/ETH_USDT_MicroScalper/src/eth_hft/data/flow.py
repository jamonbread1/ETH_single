"""流量数据层（OKX 交易大数据 Rubik + 资金费率，公开接口无需鉴权）

背景（2026-09）：2万根实证 K线衍生信号毛优势 ≈1.2bps/笔 < 成本 6~10bps —— 信号端
需要新弹药。主动买卖量比（taker flow）是方向压力的最直接证据：
- momo（趋势跟随）：主动流同向确认（买压强→做多可信）
- mr（逆向回归）：逆向拥挤（卖压极端→反弹做多）

官方口径（docs-v5 Trading Statistics，2026-09 复核修正）：
- GET /api/v5/rubik/stat/taker-volume-contract（限速 5次/2s，IP+instId）
  instId 必填（仅 FUTURES/SWAP）；period [5m/15m/30m/1H/2H/4H]+更长周期，默认 5m；
  unit：0=币 1=张 2=U（默认1）⚠️ 不是 "ccy"（51000 Parameter unit error 的元凶）；
  begin=返回更新于该ts的记录、end=早于该ts；limit≤100
  窗口限制（ccy级惯例）：5m≈近2天、1H≈30天、1D≈180天（15m/30m 受限时自动降级1H）
  返回 data: [[ts, sellVol, buyVol], ...]
- GET /api/v5/rubik/stat/contracts/open-interest-history  instId+period+begin/end+limit≤100
  返回 data: [[ts, oi(张), oiUsd(美元), oiCcy(币)], ...]（4列；旧文档3列写法已过时——
  2026-09-01 实测 "3 columns passed, passed data had 4 columns" 事故后修正）
- GET /api/v5/public/funding-rate-history  instId+after(fundingTime 更旧)+limit≤100（近3个月）
  返回 data: [{fundingRate, fundingTime, method, ...}]
所有 Rubik 响应必须校验 code=="0"（_get 对非0仅告警返回——静默空数据的事故来源）。
"""
from __future__ import annotations

import time
from pathlib import Path

import numpy as np
import pandas as pd
from loguru import logger

from .okx_rest import _get

FLOW_DIR = Path("data/flow")
CCY = "ETH"


def _ms(ts) -> int:
    return int(pd.Timestamp(ts).timestamp() * 1000)


def _rubik_get(path: str, params: dict) -> list:
    """Rubik/公共接口请求：code != "0" 直接抛错（官方 code 表；51000=Parameter xxx error）。"""
    j = _get(path, params)
    if str(j.get("code")) != "0":
        raise RuntimeError(f"OKX {path} code={j.get('code')} msg={j.get('msg')} params={params}")
    return j.get("data") or []


TAKER_FALLBACK = ["5m", "15m", "1H", "1D"]  # 官方 period 支持集（2026-09 核对）


def fetch_taker_volume(inst_id: str, begin_ms: int, end_ms: int, period: str = "15m",
                       progress=None) -> pd.DataFrame:
    """合约主动买卖量（Rubik）。unit=0（币量，买卖比值与单位无关）。
    period 从首选粒度开始；受限（51000/空数据）自动沿 5m→15m→1H→1D 降级。"""
    chain = TAKER_FALLBACK[TAKER_FALLBACK.index(period):] if period in TAKER_FALLBACK else ["1H", "1D"]
    rows: list[list] = []
    used = None
    for p in chain:
        try:
            probe = _rubik_get("/api/v5/rubik/stat/taker-volume-contract",
                               {"instId": inst_id, "period": p, "begin": str(begin_ms),
                                "end": str(end_ms), "unit": "0", "limit": "2"})
            if probe:
                used = p
                break
            logger.warning(f"taker-volume-contract period={p} 返回空（窗口受限？），降级重试")
        except RuntimeError as e:
            logger.warning(f"taker-volume-contract period={p} 不可用: {e}，降级重试")
    if used is None:
        raise RuntimeError(f"taker-volume-contract 全部粒度不可用（{chain}），请检查网络/窗口")
    logger.info(f"taker 粒度采用 {used}（首选 {period}）")
    cursor = begin_ms
    pages = 0
    while cursor < end_ms and pages < 500:
        data = _rubik_get("/api/v5/rubik/stat/taker-volume-contract",
                          {"instId": inst_id, "period": used, "begin": str(cursor),
                           "end": str(end_ms), "unit": "0", "limit": "100"})
        if not data:
            break
        rows.extend(data)
        pages += 1
        last_ts = int(data[-1][0])
        if len(data) < 2 or last_ts <= cursor:  # 到边界 / 游标无进展（防死循环）
            break
        cursor = last_ts
        time.sleep(0.5)  # 限速 5次/2s（官方），0.5s = 4次/2s 留余量
        if progress:
            progress(len(rows), cursor)
    if pages >= 500:
        logger.warning("taker 翻页达 500 页上限，提前截断")
    period = used
    norm = [r[:3] for r in rows]  # 官方 [ts, sellVol, buyVol]；防御多余列
    df = pd.DataFrame(norm, columns=["ts", "sell_vol", "buy_vol"])
    if df.empty:
        return df
    df["ts"] = pd.to_datetime(df["ts"].astype("int64"), unit="ms", utc=True)
    df = df[df["ts"] <= pd.to_datetime(end_ms, unit="ms", utc=True)]  # 防御性裁剪（真实API会honor end）
    for c in ("sell_vol", "buy_vol"):
        df[c] = pd.to_numeric(df[c], errors="coerce")
    return df.drop_duplicates("ts").sort_values("ts").reset_index(drop=True)


def fetch_oi_history(inst_id: str, begin_ms: int, end_ms: int, period: str = "1H",
                     progress=None) -> pd.DataFrame:
    """合约持仓量历史（张/币）。"""
    rows: list[list] = []
    cursor = begin_ms
    pages = 0
    while cursor < end_ms and pages < 500:
        data = _rubik_get("/api/v5/rubik/stat/contracts/open-interest-history",
                          {"instId": inst_id, "period": period, "begin": str(cursor),
                           "end": str(end_ms), "limit": "100"})
        if not data:
            break
        rows.extend(data)
        pages += 1
        last_ts = int(data[-1][0])
        if len(data) < 2 or last_ts <= cursor:  # 到边界 / 游标无进展
            break
        cursor = last_ts
        time.sleep(0.5)  # Rubik 限速 5次/2s
        if progress:
            progress(len(rows), cursor)
    n = len(rows[0]) if rows else 3
    cols = ["ts", "oi_ct", "oi_usd", "oi_ccy"][:max(n, 2)]  # 官方4列 [ts,oi,oiUsd,oiCcy]
    df = pd.DataFrame([r[:len(cols)] for r in rows], columns=cols)
    if df.empty:
        return df
    df["ts"] = pd.to_datetime(df["ts"].astype("int64"), unit="ms", utc=True)
    for c in df.columns[1:]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    return df.drop_duplicates("ts").sort_values("ts").reset_index(drop=True)


def fetch_funding_history(inst_id: str, begin_ms: int, max_pages: int = 12,
                          progress=None) -> pd.DataFrame:
    """资金费率历史（近3个月，8H 结算）。after=请求此时间之前（更旧）。"""
    rows: list[dict] = []
    after: str | None = str(end_ms := 2 ** 62)  # 从最新往回翻
    del end_ms
    for _ in range(max_pages):
        params = {"instId": inst_id, "limit": "100"}
        if after:
            params["after"] = after
        data = _rubik_get("/api/v5/public/funding-rate-history", params)
        if not data:
            break
        rows.extend(data)
        oldest = int(data[-1]["fundingTime"])
        if oldest <= begin_ms:
            break
        after = str(oldest)
        time.sleep(0.5)
        if progress:
            progress(len(rows), oldest)
    df = pd.DataFrame(rows)
    if df.empty:
        return df
    out = pd.DataFrame({
        "ts": pd.to_datetime(df["fundingTime"].astype("int64"), unit="ms", utc=True),
        "funding_rate": pd.to_numeric(df["fundingRate"], errors="coerce"),
    })
    return out.drop_duplicates("ts").sort_values("ts").reset_index(drop=True)


def _causal_z(s: pd.Series, win: int = 240, minp: int = 60) -> pd.Series:
    """因果 z 分数（均值/方差均用 shift(1) 前窗，防前视）。"""
    m = s.shift(1).rolling(win, min_periods=minp).mean()
    sd = s.shift(1).rolling(win, min_periods=minp).std(ddof=1).mask(lambda x: x < 1e-12)
    return ((s - m) / sd).clip(-4, 4)


def build_flow_1m(bar_index: pd.DatetimeIndex, inst_id: str = "ETH-USDT-SWAP",
                  taker_period: str = "15m") -> pd.DataFrame:
    """拉取三类流量数据并对齐到 1m 回测索引（前向填充），输出因果 z 分数。

    taker_buy_ratio = buy/(buy+sell) ∈ [0,1]；funding 前向填充（8H 结算）；
    oi 同步前向填充。z 分数滚动窗口 240 根（≈4小时），warmup 段为 NaN（不阻塞交易）。
    """
    b0, b1 = _ms(bar_index.min()), _ms(bar_index.max()) + 60_000
    logger.info(f"流量数据窗口: {bar_index.min()} -> {bar_index.max()}（taker 粒度 {taker_period}）")

    tk = fetch_taker_volume(inst_id, b0, b1, period=taker_period)
    tot = (tk["buy_vol"] + tk["sell_vol"]).replace(0, np.nan)
    tk = tk.assign(taker_buy_ratio=(tk["buy_vol"] / tot)).set_index("ts")
    fu = fetch_funding_history(inst_id, b0).set_index("ts")
    oi = fetch_oi_history(inst_id, b0, b1, period=taker_period).set_index("ts")

    idx = pd.DatetimeIndex(bar_index)
    f = pd.DataFrame(index=idx)
    f["taker_buy_ratio"] = tk["taker_buy_ratio"].reindex(idx, method="ffill")
    f["funding_rate"] = fu["funding_rate"].reindex(idx, method="ffill")
    oi_col = "oi_ccy" if "oi_ccy" in oi.columns else ("oi_ct" if "oi_ct" in oi.columns else None)
    f["oi"] = oi[oi_col].reindex(idx, method="ffill") if oi_col else np.nan
    f["taker_z"] = _causal_z(f["taker_buy_ratio"])
    f["funding_z"] = _causal_z(f["funding_rate"])
    f["oi_z"] = _causal_z(f["oi"].pct_change())
    f["coverage_pct"] = round(float(f["taker_buy_ratio"].notna().mean() * 100), 1)
    if f["coverage_pct"] < 50:
        logger.error(f"taker 覆盖率仅 {f['coverage_pct']}%（<50%）：流量闸门基本失效，"
                     f"请检查 24_fetch_flow 输出或网络后重拉（--refresh）")
    logger.info(f"流量对齐完成: taker 覆盖 {f['coverage_pct']}%（粒度 {taker_period} 前向填充到 1m）")
    return f


def load_or_fetch_flow(bar_index: pd.DatetimeIndex, inst_id: str = "ETH-USDT-SWAP",
                       refresh: bool = False) -> pd.DataFrame:
    """优先读缓存 data/flow/flow_1m.parquet，区间不足或 refresh 时重拉。"""
    FLOW_DIR.mkdir(parents=True, exist_ok=True)
    cache = FLOW_DIR / "flow_1m.parquet"
    if cache.exists() and not refresh:
        try:
            f = pd.read_parquet(cache)
            f.index = pd.DatetimeIndex(f.index)
            if f.index.min() <= bar_index.min() and f.index.max() >= bar_index.max():
                logger.info(f"流量缓存命中: {cache}")
                return f.reindex(pd.DatetimeIndex(bar_index), method="ffill")
            logger.info("流量缓存区间不足，重新拉取")
        except Exception as e:
            logger.warning(f"流量缓存读取失败: {e}")
    span_min = (bar_index.max() - bar_index.min()).total_seconds() / 60
    period = "5m" if span_min <= 2 * 24 * 60 else "15m"  # 受限时自动降级 1H/1D（fetch 内置 fallback）
    f = build_flow_1m(bar_index, inst_id, taker_period=period)
    f.to_parquet(cache)
    logger.info(f"流量数据已缓存 -> {cache}")
    return f