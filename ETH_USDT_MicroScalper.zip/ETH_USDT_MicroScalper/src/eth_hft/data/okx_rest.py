"""OKX REST 数据采集：K线、逐笔、资金费率、合约规格
依据：OKX API v5 公开接口，无需鉴权即可采公开数据

网络说明（2026-09）：
- 主机自动回退：www.okx.com → aws.okx.com（AWS 全球接入点，部分地区可达性更好）
- 代理支持：设环境变量 OKX_PROXY（优先）或标准 HTTPS_PROXY/HTTP_PROXY，
  例如 export OKX_PROXY=http://127.0.0.1:7890
"""
from __future__ import annotations
import os
import time
import requests
import pandas as pd
from loguru import logger

BASES = ["https://www.okx.com", "https://aws.okx.com"]

def _proxies() -> dict | None:
    p = os.environ.get("OKX_PROXY") or os.environ.get("HTTPS_PROXY") or os.environ.get("https_proxy") or os.environ.get("HTTP_PROXY") or os.environ.get("http_proxy")
    return {"https": p, "http": p} if p else None

def _get(path: str, params: dict | None = None) -> dict:
    proxies = _proxies()
    last_err: Exception | None = None
    for i in range(4):
        base = BASES[min(i // 2, len(BASES) - 1)]  # 前两次主域，后两次备用域
        url = base + path
        try:
            r = requests.get(url, params=params, timeout=10, proxies=proxies)
            r.raise_for_status()
            j = r.json()
            if j.get("code") != "0":
                logger.warning(f"OKX 返回非0 code: {j}")
            return j
        except Exception as e:
            last_err = e
            logger.warning(f"请求失败 {i+1}/4 {url} {e}")
            time.sleep(1.2 * (i + 1))
    raise RuntimeError(f"请求失败（含备用域） {path}: {last_err}")

# ============ 官方口径（https://www.okx.com/docs-v5/zh/ 行情数据，2026-09 核对）============
# GET /api/v5/market/candles：每个粒度最多可获取最近 1,440 条；限速 40次/2s（按IP）；
#   limit 最大 300（默认100）；after=更旧分页，before=更新分页
# GET /api/v5/market/history-candles：可回溯最近数年（1s K线仅近3个月）；限速 20次/2s（按IP）；
#   limit 最大 300（默认100）
# 注意：行情数据多服务独立缓存，相邻两次请求可能乱序/来自不同缓存 → 调用方须 sort+去重
# 返回列顺序：ts, o, h, l, c, vol(张), volCcy(币), volCcyQuote(计价货币), confirm(1=完结)
# WS 实时增量：wss://ws.okx.com:8443/ws/v5/public 频道 candle1m（实盘推送用，见 docs）
CANDLES_PAGE_MAX = 300
HISTORY_PAGE_MAX = 300  # 官方上限即 300（勿再降，影响翻页速度）

def _candles_page(inst_id: str, bar: str, limit: int, after: str | None, history: bool) -> list[list]:
    """单页拉取：history=False 用 /market/candles（仅最近1440条，页上限300，限速40/2s），
    history=True 用 /market/history-candles（可回溯数年，页上限300，限速20/2s）"""
    path = "/api/v5/market/history-candles" if history else "/api/v5/market/candles"
    params = {"instId": inst_id, "bar": bar, "limit": str(limit)}
    if after:
        params["after"] = after
    j = _get(path, params)
    return j.get("data", []) or []

def fetch_candles(inst_id: str = "ETH-USDT-SWAP", bar: str = "1m", limit: int = 100, after: str | None = None, before: str | None = None, progress=None) -> pd.DataFrame:
    """获取K线

    - limit <= 300：单次请求
    - limit > 300：自动翻页（`after` 游标向更早），并做**双接口接力**：
      /market/candles 的 1m 数据只保留最近约1440根（1天），退到保留边界后
      自动切换 /market/history-candles 继续回溯（单页100根，可达数月）
    - 过滤未收线的最后一根（confirm=0），避免未完成 Bar 影响回放
    - progress(done, total, mode)：每页回调一次，done=已拉根数（去重前），
      total=目标根数，mode="recent"| "history"；供上层显示进度条
    """
    cols = ["ts", "open", "high", "low", "close", "vol", "volCcy", "volCcyQuote", "confirm"]
    rows: list[list] = []

    if limit <= CANDLES_PAGE_MAX or before:
        # 单页场景（显式 before 区间查询保持单次语义，不自动翻页）
        params = {"instId": inst_id, "bar": bar, "limit": str(min(limit, CANDLES_PAGE_MAX))}
        if after:
            params["after"] = after
        if before:
            params["before"] = before
        j = _get("/api/v5/market/candles", params)
        rows = j.get("data", []) or []
        if progress:
            progress(len(rows), limit, "recent")
    else:
        remaining = int(limit)
        cursor = after
        history_mode = False
        while remaining > 0:
            page_max = HISTORY_PAGE_MAX if history_mode else CANDLES_PAGE_MAX
            page = min(remaining, page_max)
            data = _candles_page(inst_id, bar, page, cursor, history=history_mode)
            if not data:
                if not history_mode:
                    history_mode = True  # 近期接口到保留边界 → 切历史接口继续回溯
                    continue
                break  # 历史接口也无数据：真正到底
            rows.extend(data)
            remaining -= len(data)
            if progress:
                progress(len(rows), limit, "history" if history_mode else "recent")
            cursor = data[-1][0]  # 本页最早一根的 ts（先推进游标，短页切换时防重叠）
            if len(data) < page:
                if not history_mode:
                    history_mode = True  # 本页不满 = 近期接口已见底 → 切历史接口
                    continue
                break  # 历史接口页不满：到底
            if history_mode:
                time.sleep(0.11)  # history-candles 限速 20次/2s（0.11s ≈ 18次/2s，留安全余量）

    if not rows:
        return pd.DataFrame(columns=cols)
    df = pd.DataFrame(rows, columns=cols[: len(rows[0])])
    # 剔除未收线（confirm=0）的最新一根，保证回放 bar 完整
    if "confirm" in df.columns:
        df = df[df["confirm"] == "1"]
    if df.empty:
        return pd.DataFrame(columns=cols)
    df["ts"] = pd.to_datetime(df["ts"].astype(int), unit="ms", utc=True)
    # 翻页去重保险（游标边界理论上无重叠，双保险）
    df = df.drop_duplicates(subset=["ts"], keep="first")
    for c in ["open", "high", "low", "close", "vol", "volCcy"]:
        if c in df.columns:
            df[c] = df[c].astype(float)
    df = df.sort_values("ts").tail(limit).reset_index(drop=True)
    return df

def fetch_trades(inst_id: str = "ETH-USDT-SWAP", limit: int = 100) -> pd.DataFrame:
    j = _get("/api/v5/market/trades", {"instId": inst_id, "limit": str(limit)})
    data = j.get("data", [])
    df = pd.DataFrame(data)
    if not df.empty:
        df["ts"] = pd.to_datetime(df["ts"].astype(int), unit="ms", utc=True)
        if "sz" in df.columns:
            df["sz"] = df["sz"].astype(float)
        if "px" in df.columns:
            df["px"] = df["px"].astype(float)
    return df

def fetch_funding_rate(inst_id: str = "ETH-USDT-SWAP") -> dict:
    j = _get("/api/v5/public/funding-rate", {"instId": inst_id})
    return j.get("data", [{}])[0] if j.get("data") else {}

def fetch_instruments(inst_type: str = "SWAP", inst_id: str | None = "ETH-USDT-SWAP") -> list[dict]:
    """获取合约规格（公开）
    返回原始字典列表，含 ctVal/lotSz/minSz/tickSz/lever
    """
    params = {"instType": inst_type}
    if inst_id:
        params["instId"] = inst_id
    j = _get("/api/v5/public/instruments", params)
    return j.get("data", [])

def fetch_ticker(inst_id: str = "ETH-USDT-SWAP") -> dict:
    j = _get("/api/v5/market/ticker", {"instId": inst_id})
    return j.get("data", [{}])[0] if j.get("data") else {}
