"""OKX REST 数据采集：K线、逐笔、资金费率、合约规格
依据：OKX API v5 公开接口，无需鉴权即可采公开数据
"""
from __future__ import annotations
import time
import requests
import pandas as pd
from loguru import logger

BASE = "https://www.okx.com"

def _get(path: str, params: dict | None = None) -> dict:
    url = BASE + path
    for i in range(3):
        try:
            r = requests.get(url, params=params, timeout=10)
            r.raise_for_status()
            j = r.json()
            if j.get("code") != "0":
                logger.warning(f"OKX 返回非0 code: {j}")
            return j
        except Exception as e:
            logger.warning(f"请求失败 {i+1}/3 {url} {e}")
            time.sleep(1.5 * (i+1))
    raise RuntimeError(f"请求失败 {url}")

def fetch_candles(inst_id: str = "ETH-USDT-SWAP", bar: str = "1m", limit: int = 100, after: str | None = None, before: str | None = None) -> pd.DataFrame:
    """获取K线"""
    params = {"instId": inst_id, "bar": bar, "limit": str(limit)}
    if after:
        params["after"] = after
    if before:
        params["before"] = before
    j = _get("/api/v5/market/candles", params)
    data = j.get("data", [])
    cols = ["ts", "open", "high", "low", "close", "vol", "volCcy", "volCcyQuote", "confirm"]
    df = pd.DataFrame(data, columns=cols[:len(data[0])] if data else cols)
    if df.empty:
        return df
    df["ts"] = pd.to_datetime(df["ts"].astype(int), unit="ms", utc=True)
    for c in ["open","high","low","close","vol","volCcy"]:
        if c in df.columns:
            df[c] = df[c].astype(float)
    df = df.sort_values("ts").reset_index(drop=True)
    return df

def fetch_trades(inst_id: str = "ETH-USDT-SWAP", limit: int = 100) -> pd.DataFrame:
    j = _get("/api/v5/market/trades", {"instId": inst_id, "limit": str(limit)})
    data = j.get("data", [])
    df = pd.DataFrame(data)
    if not df.empty:
        df["ts"] = pd.to_datetime(df["ts"].astype(int), unit="ms", utc=True)
        if "sz" in df.columns:
            df["sz"] = df["sz"].astype(float)
        if "px" in df.columns:
            df["px"] = df["px"].astype(float)
    return df

def fetch_funding_rate(inst_id: str = "ETH-USDT-SWAP") -> dict:
    j = _get("/api/v5/public/funding-rate", {"instId": inst_id})
    return j.get("data", [{}])[0] if j.get("data") else {}

def fetch_instruments(inst_type: str = "SWAP", inst_id: str | None = "ETH-USDT-SWAP") -> list[dict]:
    """获取合约规格（公开）
    返回原始字典列表，含 ctVal/lotSz/minSz/tickSz/lever
    """
    params = {"instType": inst_type}
    if inst_id:
        params["instId"] = inst_id
    j = _get("/api/v5/public/instruments", params)
    return j.get("data", [])

def fetch_ticker(inst_id: str = "ETH-USDT-SWAP") -> dict:
    j = _get("/api/v5/market/ticker", {"instId": inst_id})
    return j.get("data", [{}])[0] if j.get("data") else {}
