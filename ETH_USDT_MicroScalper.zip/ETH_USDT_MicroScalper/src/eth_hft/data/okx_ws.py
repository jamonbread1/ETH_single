"""OKX WebSocket 客户端（公共频道）
支持 books / bbo-tbt / trades，含自动重连与 seqId 校验
作者注：VIP4 以下无法订阅 books-l2-tbt，已做降级提示
"""
from __future__ import annotations
import json
import asyncio
import websockets
from loguru import logger
from .orderbook import OrderBook

WS_PUBLIC = "wss://ws.okx.com:8443/ws/v5/public"

class OKXPublicWS:
    def __init__(self, inst_id: str = "ETH-USDT-SWAP", catalog=None, market_state=None):
        self.inst_id = inst_id
        self.book = OrderBook()
        self._running = False
        # P1-5 数据闭环：落盘与 MarketState 同步（实盘）或批量回放（回测）
        self.catalog = catalog
        self.market_state = market_state
        self._trade_buf: list[dict] = []
        self._bbo_buf: list[dict] = []
        if catalog is None:
            try:
                from .catalog import DataCatalog  # type: ignore

                self.catalog = DataCatalog()
            except Exception:
                self.catalog = None

    async def subscribe(self, channels: list[str] | None = None):
        channels = channels or ["books", "trades", "bbo-tbt"]
        # 提示 VIP 限制
        if any("l2-tbt" in c for c in channels):
            logger.warning("books-l2-tbt 需 VIP4+，否则订阅会被拒，建议先用 books")
        args = [{"channel": c, "instId": self.inst_id} for c in channels]
        self._running = True
        backoff = 1
        while self._running:
            try:
                async with websockets.connect(WS_PUBLIC, ping_interval=20) as ws:
                    await ws.send(json.dumps({"op": "subscribe", "args": args}))
                    logger.info(f"已订阅 {args}")
                    backoff = 1
                    async for msg in ws:
                        data = json.loads(msg)
                        await self._handle(data)
            except Exception as e:
                logger.error(f"WS 断开 {e}，{backoff}s 后重连")
                await asyncio.sleep(backoff)
                backoff = min(backoff*2, 30)

    async def _handle(self, data: dict):
        if "data" not in data:
            return
        arg = data.get("arg", {})
        ch = arg.get("channel")
        if ch == "books":
            for item in data["data"]:
                bids = item.get("bids", [])
                asks = item.get("asks", [])
                seq = int(item.get("seqId", 0))
                prev = int(item.get("prevSeqId", 0))
                # 首次用快照
                if self.book.last_seq is None:
                    self.book.apply_snapshot(bids, asks, seq)
                else:
                    ok = self.book.apply_update(bids, asks, seq, prev)
                    if not ok:
                        # 断档则清空等待下一次快照（简化）
                        self.book.last_seq = None
        elif ch == "trades":
            import time as _time
            import pandas as pd  # type: ignore

            for t in data.get("data", []):
                # 同步 MarketState（实盘秒级因子）
                if self.market_state is not None:
                    try:
                        from .catalog import NT_INSTRUMENT_ID_STR  # type: ignore
                        from ..v1.data import Trade as V1Trade  # type: ignore

                        self.market_state.update_trade(
                            V1Trade(ts=int(t.get("ts", _time.time() * 1000)), price=float(t.get("px", 0)), qty=float(t.get("sz", 0)), side=str(t.get("side", "unknown")).lower() if str(t.get("side", "unknown")).lower() in ("buy", "sell") else "unknown")  # type: ignore
                        )
                    except Exception:
                        pass
                self._trade_buf.append(t)
                if len(self._trade_buf) >= 500:
                    try:
                        import pandas as pd  # type: ignore

                        df = pd.DataFrame(self._trade_buf)
                        if self.catalog is not None:
                            self.catalog.write_trades(df)
                    except Exception as e:
                        logger.warning(f"TradeTick 落盘失败: {e}")
                    self._trade_buf.clear()
        elif ch == "bbo-tbt":
            for q in data.get("data", []):
                if self.market_state is not None:
                    try:
                        from ..v1.data import BBO as V1BBO  # type: ignore

                        ts_val = int(q.get("ts", q.get("seqId", 0)) or 0)
                        if ts_val == 0:
                            import time as _t

                            ts_val = int(_t.time() * 1000)
                        self.market_state.update_bbo(
                            V1BBO(
                                ts=ts_val,
                                bid=float(q.get("bidPx", q.get("bid", 0))),
                                ask=float(q.get("askPx", q.get("ask", 0))),
                                bid_size=float(q.get("bidSz", q.get("bid_sz", 10))),
                                ask_size=float(q.get("askSz", q.get("ask_sz", 10))),
                            )
                        )
                    except Exception:
                        pass
                self._bbo_buf.append(q)
                if len(self._bbo_buf) >= 500:
                    try:
                        import pandas as pd  # type: ignore

                        df = pd.DataFrame(self._bbo_buf)
                        if self.catalog is not None:
                            self.catalog.write_bbos(df)
                    except Exception as e:
                        logger.warning(f"BBO 落盘失败: {e}")
                    self._bbo_buf.clear()
        # 调试：打印 microprice / spread
        # logger.debug(f"spread={self.book.spread_bps()} obi={self.book.obi()}")

    def stop(self):
        self._running = False
