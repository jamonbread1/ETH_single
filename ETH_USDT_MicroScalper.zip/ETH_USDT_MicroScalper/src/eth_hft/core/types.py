"""类型定义：避免重复定义
"""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum

class Side(str, Enum):
    LONG = "long"
    SHORT = "short"

class Regime(str, Enum):
    """市场状态（与对话中 6 档对应）"""
    LOW_VOL = "low_vol"
    NORMAL = "normal"
    TREND_START = "trend_start"
    STRONG_TREND = "strong_trend"
    EXTREME = "extreme"
    LIQUIDITY_COLLAPSE = "liquidity_collapse"

class KillReason(str, Enum):
    ATR = "atr"
    SPREAD = "spread"
    BOOK_COLLAPSE = "book_collapse"
    LATENCY = "latency"
    CONSECUTIVE_LOSS = "consecutive_loss"
    DAILY_LOSS = "daily_loss"

@dataclass
class CostEstimate:
    """成本估计（bps 为基点，1bps=0.01%）"""
    fee_bps: float
    spread_bps: float
    slippage_bps: float
    buffer_bps: float

    @property
    def total_bps(self) -> float:
        return self.fee_bps + self.spread_bps + self.slippage_bps + self.buffer_bps
