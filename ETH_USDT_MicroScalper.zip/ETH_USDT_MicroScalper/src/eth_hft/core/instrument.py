"""合约规格：从 OKX instruments 解析 lotSz/minSz/tickSz
拒绝猜测，一切以接口返回为准
唯一真源：所有 Nautilus Instrument 必须经 `to_nautilus_instrument(spec)` 派生，禁止在 backtests/ 硬编码 multiplier/lot_size
"""
from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal
import math

@dataclass
class InstrumentSpec:
    """OKX 合约规格"""
    inst_id: str
    ct_val: float          # 合约面值
    ct_val_ccy: str        # 计价币
    lot_sz: float          # 数量精度
    min_sz: float          # 最小数量
    tick_sz: float         # 价格精度
    lever_max: float       # 最大杠杆

    def round_size(self, size: float) -> float:
        """按 lotSz 向下取整"""
        if self.lot_sz <= 0:
            return size
        # 避免浮点误差
        steps = math.floor(size / self.lot_sz + 1e-9)
        return steps * self.lot_sz

    def round_price(self, price: float) -> float:
        if self.tick_sz <= 0:
            return price
        steps = round(price / self.tick_sz)
        return steps * self.tick_sz

    def is_valid_size(self, size: float) -> bool:
        return size + 1e-9 >= self.min_sz

    def notional(self, price: float, size: float) -> float:
        """名义价值（USDT），ETH-USDT-SWAP ctVal 通常为 1 张对应多少 ETH"""
        # OKX SWAP: size 单位是张或币，需看 ctVal
        # 简化：若 ctVal 是 0.1 ETH，则 notional = size * ctVal * price
        # 若不确定，调用方应自行用 price*size 校验
        return size * self.ct_val * price

    @classmethod
    def from_okx_raw(cls, raw: dict) -> "InstrumentSpec":
        return cls(
            inst_id=raw.get("instId", ""),
            ct_val=float(raw.get("ctVal", "0.1") or 0.1),
            ct_val_ccy=raw.get("ctValCcy", "ETH"),
            lot_sz=float(raw.get("lotSz", "0.1") or 0.1),
            min_sz=float(raw.get("minSz", "0.1") or 0.1),
            tick_sz=float(raw.get("tickSz", "0.1") or 0.1),
            lever_max=float(raw.get("lever", "100") or 100),
        )

def _precision_from_increment(inc: float) -> int:
    """由增量反推精度：0.01->2, 0.1->1, 1->0"""
    s = format(Decimal(str(inc)).normalize(), "f")
    return 0 if "." not in s else len(s.split(".")[1].rstrip("0") or "")


def to_nautilus_instrument(spec: InstrumentSpec, ts_ns: int = 0):  # type: ignore
    """由 InstrumentSpec 派生 Nautilus CryptoPerpetual（P0-2 唯一真源）

    关键修正：multiplier=ct_val(0.1) 而非 1，lot_size=lot_sz(0.01) 而非 1，否则名义×10。
    notional = qty * multiplier * price 与 spec.notional(price,size) 一致。
    """
    try:
        from nautilus_trader.model.identifiers import InstrumentId, Symbol  # type: ignore
        from nautilus_trader.model.instruments import CryptoPerpetual  # type: ignore
        from nautilus_trader.model.currencies import ETH, USDT  # type: ignore
        from nautilus_trader.model.objects import Price, Quantity  # type: ignore
    except Exception as e:  # pragma: no cover
        raise ImportError(f"nautilus_trader 未安装，无法创建 Instrument: {e}") from e

    size_prec = _precision_from_increment(spec.lot_sz)
    price_prec = _precision_from_increment(spec.tick_sz)
    ct_prec = _precision_from_increment(spec.ct_val)

    return CryptoPerpetual(
        instrument_id=InstrumentId.from_str("ETHUSDT-PERP.OKX"),
        raw_symbol=Symbol("ETHUSDT"),
        base_currency=ETH,
        quote_currency=USDT,
        settlement_currency=USDT,
        is_inverse=False,
        price_precision=price_prec,
        size_precision=size_prec,
        price_increment=Price(float(spec.tick_sz), price_prec),
        size_increment=Quantity(float(spec.lot_sz), size_prec),
        multiplier=Quantity(float(spec.ct_val), ct_prec),  # 0.1 关键（原 1 导致×10）
        lot_size=Quantity(float(spec.lot_sz), size_prec),  # 0.01 关键（原 1 概念错误）
        max_quantity=Quantity(1000, 0),
        min_quantity=Quantity(float(spec.min_sz), size_prec),
        max_price=Price(100000, price_prec),
        min_price=Price(float(spec.tick_sz), price_prec),
        margin_init=Decimal("0.01"),
        margin_maint=Decimal("0.005"),
        maker_fee=Decimal("0.0002"),
        taker_fee=Decimal("0.0005"),
        ts_event=ts_ns,
        ts_init=ts_ns,
    )


# 本地兜底（当 API 不可用时，用于回测演示）
DEFAULT_ETH_SWAP = InstrumentSpec(
    inst_id="ETH-USDT-SWAP",
    ct_val=0.1,          # 真实 OKX：1 张 = 0.1 ETH
    ct_val_ccy="ETH",
    lot_sz=0.01,         # 真实最小精度 0.01 张
    min_sz=0.01,         # 真实最小 0.01 张 ≈ 2.4U 名义(2444*0.001)
    tick_sz=0.01,
    lever_max=100,
)
