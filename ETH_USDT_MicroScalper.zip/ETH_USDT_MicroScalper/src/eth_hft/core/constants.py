"""常量：所有魔法数字的唯一来源注释
"""
# OKX 费率（官方普通用户，与 docs/03 一致）
OKX_MAKER_FEE = 0.0002  # 0.02%
OKX_TAKER_FEE = 0.0005  # 0.05%

# 合约
DEFAULT_INST_ID = "ETH-USDT-SWAP"

# 数据
PARQUET_COMPRESSION = "zstd"
