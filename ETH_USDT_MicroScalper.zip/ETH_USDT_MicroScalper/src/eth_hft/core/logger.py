"""日志模块：统一封装，中文注释
来源逻辑：所有关键路径必须落日志，避免拍脑子排错
"""
from __future__ import annotations
import sys
from pathlib import Path
from loguru import logger

def setup_logger(log_dir: str | Path = "logs", level: str = "INFO") -> None:
    """初始化日志，同时输出到控制台和文件（修复Windows GBK乱码）"""
    # 修复Windows控制台 GBK 乱码：强制UTF-8
    try:
        if hasattr(sys.stdout, "reconfigure"):
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        if hasattr(sys.stderr, "reconfigure"):
            sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    # 设置环境变量确保子进程也用UTF-8
    import os
    os.environ["PYTHONIOENCODING"] = "utf-8"

    log_path = Path(log_dir)
    log_path.mkdir(parents=True, exist_ok=True)
    logger.remove()
    # 控制台：关闭colorize避免ANSI在GBK下乱码，使用utf-8 errors=replace
    try:
        logger.add(sys.stderr, level=level, colorize=False, backtrace=False, diagnose=False, enqueue=True)
    except Exception:
        logger.add(sys.stderr, level=level, colorize=False, backtrace=False, diagnose=False)
    logger.add(str(log_path / "eth_hft_{time:YYYY-MM-DD}.log"), level=level, rotation="00:00", retention="30 days", encoding="utf-8", enqueue=True)
    logger.info("Logger initialized | 日志系统已初始化 (UTF-8)")

__all__ = ["logger", "setup_logger"]
