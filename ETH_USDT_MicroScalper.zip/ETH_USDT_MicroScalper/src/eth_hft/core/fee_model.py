"""成本模型（规范模块，2026-09 审查后由 v1/cost 收编为唯一实现）

口径（OKX ETH-USDT-SWAP 普通用户费率）：
- maker 0.02% / taker 0.05%（单边）
- spread_cost：点差成本 0.8bps；slippage：maker 0.6bps / taker 1.5bps；safety_buffer：1.0bps
- 往返手续费：双 maker 0.04% / 一 maker 一 taker 0.07% / 双 taker 0.10%
"""
from __future__ import annotations

from dataclasses import dataclass

DEFAULT_MAKER_FEE = 0.0002
DEFAULT_TAKER_FEE = 0.0005
DEFAULT_SPREAD_COST = 0.00008
DEFAULT_SLIPPAGE_MAKER = 0.00006
DEFAULT_SLIPPAGE_TAKER = 0.00015
DEFAULT_SAFETY_BUFFER = 0.00010


def _bps(x: float) -> float:
    return float(x) * 1e4


def _from_bps(x: float) -> float:
    return float(x) / 1e4


@dataclass
class FeeConfig:
    maker: float = DEFAULT_MAKER_FEE
    taker: float = DEFAULT_TAKER_FEE
    spread_cost: float = DEFAULT_SPREAD_COST
    slippage_maker: float = DEFAULT_SLIPPAGE_MAKER
    slippage_taker: float = DEFAULT_SLIPPAGE_TAKER
    safety_buffer: float = DEFAULT_SAFETY_BUFFER
    min_net_edge: float = 0.00015  # 最低净边际 1.5bps


def round_trip_fee(entry_maker: bool, exit_maker: bool, cfg: FeeConfig | None = None) -> float:
    """往返手续费率（仅交易所费用，不含点差/滑点/缓冲）"""
    c = cfg or FeeConfig()
    f1 = c.maker if entry_maker else c.taker
    f2 = c.maker if exit_maker else c.taker
    return f1 + f2


def round_trip_fee_usdt(notional: float, entry_maker: bool, exit_maker: bool, cfg: FeeConfig | None = None) -> float:
    """往返手续费 USDT 值（用于微仓算账）"""
    return float(notional) * round_trip_fee(entry_maker, exit_maker, cfg)


def total_cost(entry_maker: bool, exit_maker: bool, cfg: FeeConfig | None = None) -> float:
    """往返总成本 = 手续费 + 点差 + 滑点（按两侧口径）+ 安全缓冲"""
    c = cfg or FeeConfig()
    slip = c.slippage_maker if entry_maker else c.slippage_taker
    slip2 = c.slippage_maker if exit_maker else c.slippage_taker
    return round_trip_fee(entry_maker, exit_maker, c) + c.spread_cost + slip + slip2 + c.safety_buffer


def expected_net_edge(expected_gross_return: float, entry_maker: bool, exit_maker: bool, cfg: FeeConfig) -> float:
    return float(expected_gross_return) - total_cost(entry_maker, exit_maker, cfg)


def passes_cost_filter(expected_gross_return: float, entry_maker: bool, exit_maker: bool,
                       cfg: FeeConfig, min_edge_bps: float = 1.5) -> bool:
    net = expected_net_edge(expected_gross_return, entry_maker, exit_maker, cfg)
    return _bps(net) > min_edge_bps


def required_gross_return(entry_maker: bool, exit_maker: bool, cfg: FeeConfig, min_edge_bps: float = 1.5) -> float:
    return total_cost(entry_maker, exit_maker, cfg) + _from_bps(min_edge_bps)


def required_move_usdt(notional: float, entry_maker: bool, exit_maker: bool, cfg: FeeConfig, min_edge_bps: float = 1.5) -> float:
    """需要多少 USDT 的价格移动才覆盖成本"""
    return float(notional) * required_gross_return(entry_maker, exit_maker, cfg, min_edge_bps)
