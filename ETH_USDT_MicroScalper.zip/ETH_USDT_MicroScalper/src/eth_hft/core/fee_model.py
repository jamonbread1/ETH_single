"""DEPRECATED shim 2026-09-01: 已合并至 src/eth_hft/v1/cost.py
P0-1 审计：原 total_cost 含 slippage += maker/2 导致多算 0.3bps，已在 CostEngine 修正。
请迁移：from eth_hft.v1.cost import CostConfig, CostEngine
保留本文件仅为兼容旧导入，2个迭代后删除。
"""
from __future__ import annotations

import warnings

warnings.warn("eth_hft.core.fee_model 已废弃，请迁移至 eth_hft.v1.cost", DeprecationWarning, stacklevel=2)

from eth_hft.v1.cost import CostConfig as FeeConfig  # type: ignore
from eth_hft.v1.cost import CostEngine, _bps, _from_bps  # type: ignore
from eth_hft.v1.cost import DEFAULT_MAKER_FEE, DEFAULT_TAKER_FEE  # type: ignore

_ENGINE = CostEngine()

def round_trip_fee(entry_maker: bool, exit_maker: bool, cfg: FeeConfig | None = None) -> float:  # type: ignore
    return _ENGINE.round_trip_fee("maker" if entry_maker else "taker", "maker" if exit_maker else "taker")

def round_trip_fee_usdt(notional: float, entry_maker: bool, exit_maker: bool, cfg: FeeConfig | None = None) -> float:  # type: ignore
    """往返手续费 USDT 值（用于微仓算账）"""
    return float(notional) * round_trip_fee(entry_maker, exit_maker, cfg)

def total_cost(entry_maker: bool, exit_maker: bool, cfg: FeeConfig | None = None) -> float:  # type: ignore
    if cfg is None:
        return _ENGINE.total_cost("maker" if entry_maker else "taker", "maker" if exit_maker else "taker")
    # cfg 为 shim FeeConfig(CostConfig) 时，映射字段（兼容 FeeConfig.maker/taker/spread_bps 与 CostConfig.maker_fee 等）
    maker = getattr(cfg, "maker", getattr(cfg, "maker_fee", DEFAULT_MAKER_FEE))
    taker = getattr(cfg, "taker", getattr(cfg, "taker_fee", DEFAULT_TAKER_FEE))
    spread_bps = getattr(cfg, "spread_bps", None)
    spread_cost = _from_bps(spread_bps) if spread_bps is not None else getattr(cfg, "spread_cost", 0.00008)
    sm_bps = getattr(cfg, "slippage_maker_bps", None)
    st_bps = getattr(cfg, "slippage_taker_bps", None)
    sm = _from_bps(sm_bps) if sm_bps is not None else getattr(cfg, "slippage_maker", 0.00006)
    st = _from_bps(st_bps) if st_bps is not None else getattr(cfg, "slippage_taker", 0.00015)
    buf_bps = getattr(cfg, "safety_buffer_bps", None)
    buf = _from_bps(buf_bps) if buf_bps is not None else getattr(cfg, "safety_buffer", 0.00010)
    eng = CostEngine(
        maker_fee=maker,
        taker_fee=taker,
        spread_cost=spread_cost,
        slippage_maker=sm,
        slippage_taker=st,
        safety_buffer=buf,
    )
    return eng.total_cost("maker" if entry_maker else "taker", "maker" if exit_maker else "taker")

def expected_net_edge(expected_gross_return: float, entry_maker: bool, exit_maker: bool, cfg: FeeConfig) -> float:
    return expected_gross_return - total_cost(entry_maker, exit_maker, cfg)

def passes_cost_filter(expected_gross_return: float, entry_maker: bool, exit_maker: bool, cfg: FeeConfig, min_edge_bps: float = 1.5) -> bool:
    net = expected_net_edge(expected_gross_return, entry_maker, exit_maker, cfg)
    return _bps(net) > min_edge_bps

def required_gross_return(entry_maker: bool, exit_maker: bool, cfg: FeeConfig, min_edge_bps: float = 1.5) -> float:
    return total_cost(entry_maker, exit_maker, cfg) + _from_bps(min_edge_bps)

def required_move_usdt(notional: float, entry_maker: bool, exit_maker: bool, cfg: FeeConfig, min_edge_bps: float = 1.5) -> float:
    """需要多少 USDT 的价格移动才覆盖成本"""
    return notional * required_gross_return(entry_maker, exit_maker, cfg)
