"""时间工具"""
from __future__ import annotations
import pandas as pd

def to_utc_ms(ts: pd.Timestamp) -> int:
    return int(ts.tz_convert("UTC").timestamp() * 1000) if ts.tzinfo else int(pd.Timestamp(ts, tz="UTC").timestamp()*1000)
