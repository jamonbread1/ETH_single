"""DEPRECATED shim 2026-09-01: 已合并至 src/eth_hft/v1/features.py（P1-7）
P1-7 归一：v1/features.py 为唯一真相（8因子+FeatureRecord审计）。本文件仅保留 shim 供旧脚本兼容，下版本删除。
新增代码请用：from eth_hft.v1.features import FeatureEngine
所有滚动已 shift(1) 防未来函数（见 docs/07）
"""
from __future__ import annotations

import warnings

import numpy as np
import pandas as pd

warnings.warn("eth_hft.features.microstructure 已废弃，请迁移至 eth_hft.v1.features", DeprecationWarning, stacklevel=2)

def obi_from_book(bids: list[tuple[float,float]], asks: list[tuple[float,float]], depth: int = 5) -> float:
    """OBI = (bidVol-askVol)/(bidVol+askVol)，BBO 版 depth=1 即可"""
    bv = sum(v for _, v in bids[:depth])
    av = sum(v for _, v in asks[:depth])
    if bv + av == 0:
        return 0.0
    return (bv - av) / (bv + av)

def microprice_deviation(bid: float, ask: float, bid_sz: float, ask_sz: float) -> float:
    """microprice 与 mid 偏离（bps），正值买压强"""
    mid = (bid + ask) / 2
    micro = (ask * bid_sz + bid * ask_sz) / (bid_sz + ask_sz) if (bid_sz+ask_sz)!=0 else mid
    return (micro - mid) / mid * 1e4

def cvd(trades: pd.DataFrame, window: str = "5s") -> pd.Series:
    """累计成交量差 CVD = sum(buyVol - sellVol)，window=5s/30s/60s
    需 trades 含 ts, side(buy/sell), sz
    """
    if trades.empty:
        return pd.Series(dtype=float)
    df = trades.copy()
    df["signed"] = np.where(df["side"]=="buy", df["sz"], -df["sz"])
    df = df.set_index("ts").sort_index()
    return df["signed"].rolling(window).sum()

def add_basic_features(df: pd.DataFrame) -> pd.DataFrame:
    """给 OHLC 增加基础特征（已 shift 防泄露）
    ret 使用 pct_change(1) 天然基于已完成 bar
    vol/atr 使用 shift(1).rolling 防止包含当前 bar 未来
    """
    out = df.copy()
    # 收益基于已完成 close，无泄露
    out["ret_1"] = out["close"].pct_change(1)
    out["ret_5"] = out["close"].pct_change(5)
    out["ret_30"] = out["close"].pct_change(30)
    # 波动率等滚动必须 shift(1)，否则当前 bar 的 ret 会提前参与
    out["vol_20"] = out["ret_1"].shift(1).rolling(20).std()
    out["atr_14"] = (out["high"] - out["low"]).shift(1).rolling(14).mean()
    # BBO 相关（若有）也需 shift
    if "spread_bps" in out.columns:
        out["spread_bps"] = out["spread_bps"].shift(1)
    return out

def volume_features(df: pd.DataFrame) -> pd.DataFrame:
    """成交量结构（第二优先级，免费且有效）"""
    out = df.copy()
    out["vol_ma_20"] = out["vol"].shift(1).rolling(20).mean()
    out["vol_z"] = (out["vol"] - out["vol_ma_20"]) / out["vol"].shift(1).rolling(20).std()
    return out
