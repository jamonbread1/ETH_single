"""DEPRECATED shim 2026-09-01: 已合并至 src/eth_hft/v1/regime.py（P1-7）
P1-7 归一：v1/regime.py 为唯一真相（RANGE/TREND/EXTREME/LOCKED）。本文件仅保留兼容，下版本删除。
请迁移：from eth_hft.v1.regime import Regime, detect_regime, is_tradeable
"""
from __future__ import annotations

import warnings

import numpy as np
import pandas as pd

warnings.warn("eth_hft.features.regime 已废弃，请迁移至 eth_hft.v1.regime", DeprecationWarning, stacklevel=2)

from ..core.types import Regime as _LegacyRegime  # noqa: F401
from ..v1.regime import Regime as _V1Regime  # noqa: F401
from ..core.types import Regime

def detect_regime(row: pd.Series, atr_median: float) -> Regime:
    """单行判断（示例逻辑，需用历史分位数标定）"""
    atr = row.get("atr_14", np.nan)
    vol = row.get("vol_20", np.nan)
    spread_bps = row.get("spread_bps", 1.0)
    # 简化阈值（可在 configs 中覆盖）
    if pd.isna(atr) or pd.isna(atr_median) or atr_median==0:
        return Regime.NORMAL
    atr_ratio = atr / atr_median
    if atr_ratio > 4:
        return Regime.EXTREME
    if atr_ratio > 2.5:
        return Regime.STRONG_TREND
    if atr_ratio > 1.5:
        return Regime.TREND_START
    if spread_bps > 3.0:
        return Regime.LIQUIDITY_COLLAPSE
    if vol < 0.0005:
        return Regime.LOW_VOL
    return Regime.NORMAL

def regime_allows_trading(regime: Regime, direction: str | None = None) -> bool:
    """不同状态下的交易许可"""
    if regime in (Regime.EXTREME, Regime.LIQUIDITY_COLLAPSE):
        return False
    # 强趋势下禁止逆势由上层策略决定，这里仅做基础过滤
    return True
