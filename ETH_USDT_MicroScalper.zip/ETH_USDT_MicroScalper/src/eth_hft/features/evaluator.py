"""因子评估：IC / After-Cost IC / 分Regime IC
时序版，严格区分 feature(≤t) 与 label(t→t+h)（见 docs/07）
"""
from __future__ import annotations
import pandas as pd
import numpy as np
from scipy.stats import spearmanr
from ..research.integrity import assert_feature_uses_past_only

def forward_return(close: pd.Series, horizon: int = 5) -> pd.Series:
    """未来收益 label：(close_{t+h}/close_t -1)，仅训练时可用，决策时禁止访问"""
    return close.shift(-horizon) / close - 1

def ic(series: pd.Series, fwd: pd.Series, method: str = "spearman") -> tuple[float, float]:
    df = pd.DataFrame({"f": series, "r": fwd}).dropna()
    if len(df) < 20:
        return np.nan, np.nan
    if method == "spearman":
        corr, p = spearmanr(df["f"], df["r"])
    else:
        corr = df["f"].corr(df["r"])
        p = np.nan
    return float(corr), float(p)

def after_cost_return(fwd: pd.Series, fee_cost: float) -> pd.Series:
    return fwd - fee_cost

def evaluate_factor(df: pd.DataFrame, factor_col: str, horizons: list[int] = [5,30,60], fee: float = 0.0004) -> pd.DataFrame:
    """多 horizon 评估，df 需已保证 factor 来自 ≤t，fwd 来自 >t"""
    rows = []
    for h in horizons:
        fwd = forward_return(df["close"], h)
        ic_raw, p = ic(df[factor_col], fwd)
        ic_net, p2 = ic(df[factor_col], after_cost_return(fwd, fee))
        rows.append({"horizon": h, "IC": ic_raw, "p": p, "AfterCost_IC": ic_net, "AfterCost_p": p2, "fee": fee})
    return pd.DataFrame(rows)
